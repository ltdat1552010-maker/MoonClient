package night.modules.api;

public interface IFastClimbModule {
   boolean isToggled();

   float getSpeedValue();
}
