package night.modules.api;

public interface IFreecamModule {
   boolean isToggled();

   boolean isRotate();

   void onMouseTurn(double var1, double var3);

   float getFreeYaw();

   float getFreePitch();

   double getFreeX();

   double getFreeY();

   double getFreeZ();
}
