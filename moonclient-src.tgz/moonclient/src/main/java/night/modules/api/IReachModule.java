package night.modules.api;

public interface IReachModule {
   boolean isToggled();

   double getAmountValue();
}
