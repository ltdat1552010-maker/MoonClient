package night.modules.api;

public interface IPatchModule {
   boolean isToggled();

   boolean isGrimAttackVelocity();
}
