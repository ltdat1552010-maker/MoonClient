package night.modules.impl.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.InterpolationHandler;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.WorldUtils;

@RegisterModule(
   name = "CombatPlace",
   description = "Automatically places blocks in front of moving targets to block them.",
   category = Module.Category.COMBAT,
   proxyEnhanced = true
)
public class CombatPlace extends Module {
   public BooleanSetting flatten = new BooleanSetting("Flatten", "Place blocks under the target.", true);
   public ModeSetting mode = new ModeSetting("Mode", "Prediction mode.", "Two", new String[]{"None", "One", "Two", "Three"});
   public ModeSetting targetPriority = new ModeSetting("Priority", "Target selection priority.", "Closest", new String[]{"Closest", "Health"});
   public NumberSetting predictTicks = new NumberSetting("PredictTicks", "Prediction scale.", 2, 1, 8);
   public NumberSetting minKmh = new NumberSetting("MinKMH", "Min speed to trigger blocker.", 20, 1, 40);
   public NumberSetting limit = new NumberSetting("Limit", "The maximum number of blocks that can be placed per tick.", 4, 1, 20);
   public NumberSetting delay = new NumberSetting("Delay", "The delay in ticks between placements.", 0, 0, 20);
   public BooleanSetting strict = new BooleanSetting("Strict", "Prevent placement if entities intersect.", true);
   public BooleanSetting safety = new BooleanSetting("Safety", "Prevent trapping yourself.", true);
   public NumberSetting range = new NumberSetting("Range", "The maximum range at which blocks will be placed.", 5.0, 0.0, 12.0);
   public BooleanSetting rotate = new BooleanSetting("Rotate", "Sends a packet rotation whenever placing a block.", true);
   public BooleanSetting crystalDestruction = new BooleanSetting("CrystalDestruction", "Destroys any crystals that interfere with block placement.", true);
   private int delayTicks = 0;

   @Override
   public void onEnable() {
      this.delayTicks = 0;
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (!this.shouldRunOnProxy()) {
         if (!this.getNull()) {
            Player target = this.findTarget();
            if (target != null) {
               if (this.delayTicks < this.delay.getValue().intValue()) {
                  this.delayTicks++;
               } else {
                  List<BlockPos> blocksToPlace = this.getPlacePositions(target);
                  if (!blocksToPlace.isEmpty()) {
                     double rangeSq = Math.pow(this.range.getValue().doubleValue(), 2.0);
                     blocksToPlace.removeIf(pos -> mc.player.getEyePosition().distanceToSqr(Vec3.atCenterOf(pos)) > rangeSq);
                     if (!blocksToPlace.isEmpty()) {
                        this.placeBlocks(blocksToPlace);
                        this.delayTicks = 0;
                     }
                  }
               }
            }
         }
      }
   }

   private void placeBlocks(List<BlockPos> positions) {
      if (mc.player != null) {
         int blockSlot = InventoryUtils.findHardestBlock(0, 8);
         if (blockSlot != -1) {
            int previousSlot = mc.player.getInventory().getSelectedSlot();
            InventoryUtils.switchSlot("Silent", blockSlot, previousSlot);
            int placed = 0;

            for (BlockPos position : positions) {
               if (placed >= this.limit.getValue().intValue()) {
                  break;
               }

               Direction direction = WorldUtils.getDirection(position, false);
               if (direction != null) {
                  WorldUtils.placeBlock(position, direction, InteractionHand.MAIN_HAND, this.rotate.getValue(), this.crystalDestruction.getValue(), false);
                  placed++;
               }
            }

            InventoryUtils.switchBack("Silent", blockSlot, previousSlot);
         }
      }
   }

   private List<BlockPos> getPlacePositions(Player target) {
      List<BlockPos> positions = new ArrayList<>();
      if (this.flatten.getValue()) {
         BlockPos under = BlockPos.containing(target.position()).below();
         if (this.isValidSpot(under)) {
            positions.add(under);
         }
      }

      String currentMode = this.mode.getValue();
      if (!currentMode.equals("None")) {
         double speedKmh = EntityUtils.getSpeed(target, EntityUtils.SpeedUnit.KILOMETERS);
         if (speedKmh >= this.minKmh.getValue().doubleValue()) {
            InterpolationHandler interpolation = target.getInterpolation();
            Vec3 lerpTarget = interpolation != null ? interpolation.position() : target.position();
            double targetX = lerpTarget.x;
            double targetZ = lerpTarget.z;
            double dx = targetX - target.getX();
            double dz = targetZ - target.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len > 0.001) {
               double dirX = dx / len;
               double dirZ = dz / len;
               double tickSpeed = Math.sqrt(Math.pow(target.getX() - target.xo, 2.0) + Math.pow(target.getZ() - target.zo, 2.0));
               double scale = this.predictTicks.getValue().doubleValue();
               BlockPos feetPos = BlockPos.containing(targetX + dirX * tickSpeed * scale, target.getY(), targetZ + dirZ * tickSpeed * scale);
               if (this.isValidSpot(feetPos)) {
                  positions.add(feetPos);
                  if (currentMode.equals("Two") || currentMode.equals("Three")) {
                     BlockPos headPos = feetPos.above();
                     if (this.isValidSpot(headPos)) {
                        positions.add(headPos);
                     }
                  }

                  if (currentMode.equals("Three")) {
                     BlockPos topPos = feetPos.above(2);
                     if (this.isValidSpot(topPos)) {
                        positions.add(topPos);
                     }
                  }
               }
            }
         }
      }

      return positions;
   }

   private boolean isValidSpot(BlockPos pos) {
      if (mc.level == null) {
         return false;
      } else if (mc.level.isOutsideBuildHeight(pos)) {
         return false;
      } else if (!mc.level.getBlockState(pos).canBeReplaced()) {
         return false;
      } else {
         if (this.strict.getValue()) {
            AABB box = new AABB(pos);
            if (mc.level.getEntities((Entity)null, box, e -> true).stream().anyMatch(e -> e instanceof Player)) {
               return false;
            }
         }

         return !this.safety.getValue() || mc.player == null || !mc.player.getBoundingBox().intersects(new AABB(pos));
      }
   }

   private Player findTarget() {
      return mc.level != null && mc.player != null
         ? mc.level
            .players()
            .stream()
            .filter(p -> p != mc.player && !p.isRemoved() && !Night.FRIEND_MANAGER.contains(p.getName().getString()))
            .filter(p -> mc.player.distanceTo(p) <= this.range.getValue().doubleValue() + 4.0)
            .min(this.getComparator())
            .orElse(null)
         : null;
   }

   private Comparator<Player> getComparator() {
      return this.targetPriority.getValue().equals("Health")
         ? Comparator.comparingDouble(p -> p.getHealth() + p.getAbsorptionAmount())
         : Comparator.comparingDouble(p -> mc.player != null ? mc.player.distanceTo(p) : 0.0);
   }
}
