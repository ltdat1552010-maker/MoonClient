package night.modules.impl.combat;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.movement.HitboxDesyncModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.PositionUtils;
import night.utils.minecraft.WorldUtils;
import night.utils.system.ThreadExecutor;

@RegisterModule(
   name = "OpponentScaffold",
   description = "Automatically places blocks under non-friended players to prevent them from falling.",
   category = Module.Category.COMBAT,
   proxyEnhanced = true
)
public class OpponentScaffold extends Module {
   public ModeSetting autoSwitch = new ModeSetting(
      "Switch", "The mode that will be used for automatically switching to necessary items.", "Silent", InventoryUtils.SWITCH_MODES
   );
   public BooleanSetting asynchronous = new BooleanSetting("Asynchronous", "Performs calculations on separate threads.", true);
   public NumberSetting limit = new NumberSetting("Limit", "The number of blocks that can be placed per tick.", 4, 1, 20);
   public NumberSetting delay = new NumberSetting("Delay", "The amount of ticks that have to be waited for between placements.", 0, 0, 20);
   public NumberSetting range = new NumberSetting("Range", "The maximum range at which blocks will be placed at.", 5.0, 0.0, 12.0);
   public NumberSetting enemyRange = new NumberSetting("EnemyRange", "The maximum distance at which the target should be at.", 10.0F, 0.0F, 20.0F);
   public NumberSetting extrapolation = new NumberSetting("Extrapolation", "Extrapolates the target's position to predict where they will move.", 0, 0, 20);
   public BooleanSetting await = new BooleanSetting("Await", "Waits for blocks to be registered by the client before placing on them.", false);
   public BooleanSetting rotate = new BooleanSetting("Rotate", "Whether or not you should rotate when you place blocks.", true);
   public BooleanSetting strictDirection = new BooleanSetting("StrictDirection", "Only places using directions that face you.", false);
   public BooleanSetting crystalDestruction = new BooleanSetting("CrystalDestruction", "Destroys any crystals that interfere with block placement.", true);
   public BooleanSetting whileEating = new BooleanSetting("WhileEating", "Places blocks normally while eating.", true);
   public BooleanSetting selfDisable = new BooleanSetting("SelfDisable", "Toggles off the module once it is finished with placing.", false);
   public BooleanSetting itemDisable = new BooleanSetting("ItemDisable", "Toggles off the module whenever you run out of items to place with.", true);
   public BooleanSetting render = new BooleanSetting("Render", "Whether or not to render the place position.", true);
   private List<BlockPos> positions = new ArrayList<>();
   private int ticks = 0;
   private int blocksPlaced = 0;

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (!this.shouldRunOnProxy()) {
         if (mc.player != null && mc.level != null) {
            if (this.whileEating.getValue() || !EntityUtils.isEating()) {
               List<AbstractClientPlayer> players = mc.level.players();
               if (players != null && !players.isEmpty()) {
                  Runnable runnable = () -> {
                     if (mc.player != null && mc.level != null) {
                        this.blocksPlaced = 0;
                        if (this.ticks < this.delay.getValue().intValue()) {
                           this.ticks++;
                        } else if (!this.autoSwitch.getValue().equalsIgnoreCase("None")
                           || mc.player.getMainHandItem() != null && mc.player.getMainHandItem().getItem() instanceof BlockItem) {
                           int slot = InventoryUtils.findHardestBlock(
                              0, !this.autoSwitch.getValue().equalsIgnoreCase("AltSwap") && !this.autoSwitch.getValue().equalsIgnoreCase("AltPickup") ? 8 : 35
                           );
                           int previousSlot = mc.player.getInventory() != null ? mc.player.getInventory().getSelectedSlot() : 0;
                           if (slot == -1) {
                              if (this.itemDisable.getValue()) {
                                 Night.CHAT_MANAGER.tagged("No blocks could be found in your hotbar.", this.getName());
                                 this.setToggled(false);
                              }

                              this.positions = new ArrayList<>();
                           } else {
                              OpponentScaffold.Target target = this.getTarget(players);
                              if (target == null) {
                                 if (this.selfDisable.getValue()) {
                                    this.setToggled(false);
                                 }

                                 this.positions = new ArrayList<>();
                              } else {
                                 this.positions = target.positions();
                                 Night.ROTATION_MANAGER.beginBatchRotation();

                                 try {
                                    InventoryUtils.switchSlot(this.autoSwitch.getValue(), slot, previousSlot);
                                    List<BlockPos> placedPositions = new ArrayList<>();

                                    for (BlockPos position : this.positions) {
                                       if (this.blocksPlaced >= this.limit.getValue().intValue()) {
                                          break;
                                       }

                                       Direction direction = WorldUtils.getDirection(position, placedPositions, this.strictDirection.getValue());
                                       if (direction == null) {
                                          BlockPos supportPosition = position.offset(0, -1, 0);
                                          if (!WorldUtils.isPlaceable(supportPosition)) {
                                             continue;
                                          }

                                          Direction supportDirection = WorldUtils.getDirection(
                                             supportPosition, placedPositions, this.strictDirection.getValue()
                                          );
                                          if (supportDirection == null) {
                                             continue;
                                          }

                                          WorldUtils.placeBlock(
                                             supportPosition,
                                             supportDirection,
                                             InteractionHand.MAIN_HAND,
                                             this.rotate.getValue(),
                                             this.crystalDestruction.getValue(),
                                             this.render.getValue()
                                          );
                                          placedPositions.add(supportPosition);
                                          this.blocksPlaced++;
                                          if (this.blocksPlaced >= this.limit.getValue().intValue()) {
                                             break;
                                          }

                                          if (this.await.getValue()) {
                                             continue;
                                          }

                                          direction = WorldUtils.getDirection(position, placedPositions, this.strictDirection.getValue());
                                          if (direction == null) {
                                             continue;
                                          }
                                       }

                                       WorldUtils.placeBlock(
                                          position,
                                          direction,
                                          InteractionHand.MAIN_HAND,
                                          this.rotate.getValue(),
                                          this.crystalDestruction.getValue(),
                                          this.render.getValue()
                                       );
                                       placedPositions.add(position);
                                       this.blocksPlaced++;
                                    }

                                    InventoryUtils.switchBack(this.autoSwitch.getValue(), slot, previousSlot);
                                 } finally {
                                    Night.ROTATION_MANAGER.endBatchRotation();
                                 }

                                 this.ticks = 0;
                              }
                           }
                        } else {
                           if (this.itemDisable.getValue()) {
                              Night.CHAT_MANAGER.tagged("You are currently not holding any blocks.", this.getName());
                              this.setToggled(false);
                           }

                           this.positions = new ArrayList<>();
                        }
                     }
                  };
                  if (this.asynchronous.getValue()) {
                     ThreadExecutor.execute(runnable);
                  } else {
                     runnable.run();
                  }
               }
            }
         }
      }
   }

   @Override
   public void onEnable() {
      if (mc.player == null || mc.level == null) {
         this.setToggled(false);
      }
   }

   @Override
   public void onDisable() {
      this.positions = new ArrayList<>();
   }

   @Override
   public String getMetaData() {
      return String.valueOf(this.positions.size());
   }

   private OpponentScaffold.Target getTarget(List<AbstractClientPlayer> players) {
      if (mc.player == null) {
         return null;
      } else {
         Player closest = null;
         double closestDistance = Double.MAX_VALUE;

         for (AbstractClientPlayer player : players) {
            if (player != mc.player && !player.isInvisible() && !Night.FRIEND_MANAGER.contains(player.getName().getString()) && !(player.getHealth() <= 0.0F)) {
               double distance = mc.player.distanceToSqr(player);
               if (!(distance > Mth.square(this.enemyRange.getValue().floatValue())) && distance < closestDistance) {
                  closestDistance = distance;
                  closest = player;
               }
            }
         }

         if (closest == null) {
            return null;
         } else {
            BlockPos basePos = this.getTargetPosition(closest);
            if (basePos == null) {
               return null;
            } else {
               HitboxDesyncModule module = Night.MODULE_MANAGER.getModule(HitboxDesyncModule.class);
               List<BlockPos> targetPositions = new ArrayList<>();
               BlockPos underPlayer = basePos.below();
               boolean hitboxEnabled = module != null && module.isToggled() && !Boolean.TRUE.equals(module.close.getValue());
               if (WorldUtils.isPlaceable(underPlayer, hitboxEnabled)) {
                  double distToPlayer = mc.player.distanceToSqr(Vec3.atCenterOf(underPlayer));
                  if (distToPlayer <= Mth.square(this.range.getValue().doubleValue())) {
                     targetPositions.add(underPlayer);
                  }
               }

               return targetPositions.isEmpty() ? null : new OpponentScaffold.Target(closest, targetPositions);
            }
         }
      }
   }

   private BlockPos getTargetPosition(Player player) {
      if (player == null) {
         return null;
      } else {
         int extrapolationTicks = this.extrapolation.getValue().intValue();
         if (extrapolationTicks > 0) {
            double deltaX = player.getX() - player.xo;
            double deltaZ = player.getZ() - player.zo;
            double predictedX = player.getX() + deltaX * extrapolationTicks;
            double predictedZ = player.getZ() + deltaZ * extrapolationTicks;
            return new BlockPos((int)Math.floor(predictedX), (int)Math.floor(player.getY()), (int)Math.floor(predictedZ));
         } else {
            return PositionUtils.getFlooredPosition(player);
         }
      }
   }

   private record Target(Player player, List<BlockPos> positions) {
   }
}
