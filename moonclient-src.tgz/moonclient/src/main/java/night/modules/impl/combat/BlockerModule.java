package night.modules.impl.combat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerMineEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.player.SpeedMineModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.HoleUtils;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.WorldUtils;
import night.utils.system.ThreadExecutor;
import night.utils.system.Timer;

@RegisterModule(
   name = "Blocker",
   description = "Places blocks to stop enemies from placing crystals.",
   category = Module.Category.COMBAT,
   proxyEnhanced = true
)
public class BlockerModule extends Module {
   public ModeSetting autoSwitch = new ModeSetting(
      "Switch", "The mode that will be used for automatically switching to necessary items.", "Silent", InventoryUtils.SWITCH_MODES
   );
   public BooleanSetting asynchronous = new BooleanSetting("Asynchronous", "Performs calculations on separate threads.", true);
   public NumberSetting limit = new NumberSetting("Limit", "The number of blocks that can be placed per tick.", 4, 1, 20);
   public NumberSetting delay = new NumberSetting("Delay", "The amount of ticks that have to be waited for between placements.", 0, 0, 20);
   public NumberSetting range = new NumberSetting("Range", "The maximum range at which the blocks will be placed at.", 5.0, 0.0, 12.0);
   public BooleanSetting rotate = new BooleanSetting("Rotate", "Sends a packet rotation whenever placing a block.", true);
   public BooleanSetting strictDirection = new BooleanSetting("StrictDirection", "Only places using directions that face you.", false);
   public BooleanSetting crystalDestruction = new BooleanSetting("CrystalDestruction", "Destroys any crystals that interfere with block placement.", true);
   public BooleanSetting whileEating = new BooleanSetting("WhileEating", "Places blocks normally while eating.", true);
   public BooleanSetting feet = new BooleanSetting("Feet", "Places on feet level blocks.", true);
   public BooleanSetting head = new BooleanSetting("Head", "Places on head level blocks.", true);
   public BooleanSetting render = new BooleanSetting("Render", "Whether or not to render the place position.", true);
   private final CopyOnWriteArrayList<BlockerModule.Position> targetPositions = new CopyOnWriteArrayList<>();
   private BlockerModule.Mine mine = null;
   private int ticks = 0;

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (!this.shouldRunOnProxy()) {
         if (this.whileEating.getValue() || !EntityUtils.isEating()) {
            Runnable runnable = () -> {
               if (mc.player != null && mc.level != null) {
                  SpeedMineModule module = Night.MODULE_MANAGER.getModule(SpeedMineModule.class);
                  if ((this.mine == null || module.getPrimary() == null || !this.mine.position().equals(module.getPrimary().getPosition()))
                     && (module.getSecondary() == null || !this.mine.position().equals(module.getSecondary().getPosition()))) {
                     int blocksPlaced = 0;
                     if (this.ticks < this.delay.getValue().intValue()) {
                        this.ticks++;
                     } else {
                        HashSet<BlockPos> feetPositions = HoleUtils.getFeetPositions(mc.player, true, false, false);
                        List<BlockPos> insidePositions = HoleUtils.getInsidePositions(mc.player);
                        if (this.mine != null && this.mine.timer().hasTimeElapsed(Math.max(this.mine.breakTime() - 200.0F, 0.0F))) {
                           BlockPos position = this.mine.position();
                           if (this.mine.type() == BlockerModule.MineType.FEET && this.feet.getValue()) {
                              if (feetPositions.contains(this.mine.position())) {
                                 this.targetPositions.add(new BlockerModule.Position(position, position.above()));

                                 for (Direction direction : Direction.values()) {
                                    if (direction.getAxis().isHorizontal()) {
                                       this.targetPositions.add(new BlockerModule.Position(position, position.relative(direction)));
                                    }
                                 }
                              }

                              this.mine = null;
                           } else if ((this.mine.type() == BlockerModule.MineType.HEAD || this.mine.type() == BlockerModule.MineType.SIDE)
                              && this.head.getValue()) {
                              if (this.mine.type() == BlockerModule.MineType.HEAD && insidePositions.contains(this.mine.position().below().below())
                                 || this.mine.type() == BlockerModule.MineType.SIDE && feetPositions.contains(this.mine.position().below())) {
                                 this.targetPositions.add(new BlockerModule.Position(position, position.above()));
                              }

                              this.mine = null;
                           }
                        }

                        this.targetPositions.removeIf(position -> !WorldUtils.isPlaceable(position.position()));
                        this.targetPositions
                           .removeIf(
                              position -> mc.player.distanceToSqr(Vec3.atCenterOf(position.position())) > Mth.square(this.range.getValue().doubleValue())
                           );
                        this.targetPositions
                           .removeIf(
                              position -> !feetPositions.contains(position.original())
                                 && !feetPositions.contains(position.original().below())
                                 && !insidePositions.contains(position.original().below().below())
                           );
                        if (!this.targetPositions.isEmpty()) {
                           int slot = InventoryUtils.findHardestBlock(
                              0, !this.autoSwitch.getValue().equalsIgnoreCase("AltSwap") && !this.autoSwitch.getValue().equalsIgnoreCase("AltPickup") ? 8 : 35
                           );
                           int previousSlot = mc.player.getInventory().getSelectedSlot();
                           if (slot == -1) {
                              this.targetPositions.clear();
                           } else {
                              Night.ROTATION_MANAGER.beginBatchRotation();

                              try {
                                 InventoryUtils.switchSlot(this.autoSwitch.getValue(), slot, previousSlot);

                                 for (BlockerModule.Position position : new ArrayList<>(this.targetPositions)) {
                                    if (blocksPlaced >= this.limit.getValue().intValue()) {
                                       break;
                                    }

                                    Direction directionx = WorldUtils.getDirection(position.position(), null, this.strictDirection.getValue());
                                    if (directionx != null) {
                                       WorldUtils.placeBlock(
                                          position.position(),
                                          directionx,
                                          InteractionHand.MAIN_HAND,
                                          this.rotate.getValue(),
                                          this.crystalDestruction.getValue(),
                                          this.render.getValue()
                                       );
                                       this.targetPositions.remove(position);
                                       blocksPlaced++;
                                    }
                                 }

                                 InventoryUtils.switchBack(this.autoSwitch.getValue(), slot, previousSlot);
                              } finally {
                                 Night.ROTATION_MANAGER.endBatchRotation();
                              }

                              this.ticks = 0;
                           }
                        }
                     }
                  } else {
                     this.mine = null;
                  }
               }
            };
            if (this.asynchronous.getValue()) {
               ThreadExecutor.execute(runnable);
            } else {
               runnable.run();
            }
         }
      }
   }

   @SubscribeEvent
   public void onPlayerMine(PlayerMineEvent event) {
      if (!this.shouldRunOnProxy()) {
         if (mc.player != null && mc.level != null) {
            if (this.mine == null || !this.mine.position().equals(event.getPosition())) {
               SpeedMineModule module = Night.MODULE_MANAGER.getModule(SpeedMineModule.class);
               if ((module.getPrimary() == null || !event.getPosition().equals(module.getPrimary().getPosition()))
                  && (module.getSecondary() == null || !event.getPosition().equals(module.getSecondary().getPosition()))) {
                  Entity entity = mc.level.getEntity(event.getActorID());
                  if (entity != mc.player) {
                     if (entity instanceof Player player) {
                        if (!Night.FRIEND_MANAGER.contains(player.getName().getString())) {
                           HashSet<BlockPos> feetPositions = HoleUtils.getFeetPositions(mc.player, true, false, false);
                           List<BlockPos> insidePositions = HoleUtils.getInsidePositions(mc.player);
                           if (this.feet.getValue() && feetPositions.contains(event.getPosition())) {
                              this.mine = new BlockerModule.Mine(
                                 event.getPosition(),
                                 new Timer(),
                                 WorldUtils.getBreakTime(player, mc.level.getBlockState(event.getPosition())),
                                 BlockerModule.MineType.FEET
                              );
                           } else {
                              if (this.head.getValue()) {
                                 if (feetPositions.contains(event.getPosition().below())) {
                                    this.mine = new BlockerModule.Mine(
                                       event.getPosition(),
                                       new Timer(),
                                       WorldUtils.getBreakTime(player, mc.level.getBlockState(event.getPosition())),
                                       BlockerModule.MineType.SIDE
                                    );
                                 }

                                 if (insidePositions.contains(event.getPosition().below().below())) {
                                    this.mine = new BlockerModule.Mine(
                                       event.getPosition(),
                                       new Timer(),
                                       WorldUtils.getBreakTime(player, mc.level.getBlockState(event.getPosition())),
                                       BlockerModule.MineType.HEAD
                                    );
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   public void onDisable() {
      this.targetPositions.clear();
   }

   @Override
   public String getMetaData() {
      return this.targetPositions == null ? "0" : String.valueOf(this.targetPositions.size());
   }

   private record Mine(BlockPos position, Timer timer, float breakTime, BlockerModule.MineType type) {
   }

   private static enum MineType {
      FEET,
      HEAD,
      SIDE;
   }

   private record Position(BlockPos original, BlockPos position) {
   }
}
