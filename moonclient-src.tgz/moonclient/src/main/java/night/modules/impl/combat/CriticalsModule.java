package night.modules.impl.combat;

import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.AttackEntityEvent;
import night.events.impl.PacketSendEvent;
import night.mixins.accessors.ClientPlayerEntityAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.pingbypass.server.ProxyServerTickListener;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;

@RegisterModule(
   name = "Criticals",
   description = "Changes player movement for always landing critical hits.",
   category = Module.Category.COMBAT,
   proxyEnhanced = true
)
public class CriticalsModule extends Module {
   public ModeSetting mode = new ModeSetting(
      "Mode", "The method that will be used to achieve critical hits.", "Packet", new String[]{"Packet", "Grim", "GrimNew"}
   );
   public BooleanSetting onlyPhased = new BooleanSetting(
      "OnlyPhased", "Only crits when you are phased into blocks.", new ModeSetting.Visibility(this.mode, "Grim", "GrimNew"), true
   );
   public BooleanSetting onlyStandingStill = new BooleanSetting(
      "OnlyStandingStill", "Only crits when you are standing still.", new ModeSetting.Visibility(this.mode, "Grim", "GrimNew"), true
   );
   public BooleanSetting onlyWhenHeadCovered = new BooleanSetting(
      "HeadCovered", "Only crits when there is a block covering your head.", new ModeSetting.Visibility(this.mode, "Grim", "GrimNew"), true
   );
   private long lastCritTime = 0L;

   @SubscribeEvent
   public void onAttackEntity(AttackEntityEvent event) {
      if (!this.shouldRunOnProxy()) {
         if (mc.player != null && mc.level != null) {
            if (!mc.player.isFallFlying()
               && !mc.player.isInWater()
               && !mc.player.isInLava()
               && !mc.player.isSuppressingSlidingDownLadder()
               && !mc.player.hasEffect(MobEffects.BLINDNESS)) {
               Entity target = event.getTarget();
               if (target instanceof LivingEntity living && living.isAlive() && !(target instanceof EndCrystal) && !(target instanceof ItemFrame)) {
                  if (mc.player.isHandsBusy()) {
                     this.ridingAttack(target);
                  } else {
                     this.onGroundAttack();
                     mc.player.crit(target);
                  }
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketSendEvent event) {
      if (!this.shouldRunOnProxy()) {
         if (event.getPacket() instanceof ServerboundAttackPacket) {
            long now = System.currentTimeMillis();
            if (now - this.lastCritTime < 50L) {
               return;
            }

            if (mc.player == null || mc.level == null) {
               return;
            }

            if (mc.player.isFallFlying()
               || mc.player.isInWater()
               || mc.player.isInLava()
               || mc.player.isSuppressingSlidingDownLadder()
               || mc.player.hasEffect(MobEffects.BLINDNESS)) {
               return;
            }

            this.onGroundAttack();
         }
      }
   }

   private void ridingAttack(Entity target) {
      if (this.mode.getValue().equalsIgnoreCase("Packet")) {
         for (int i = 0; i < 5; i++) {
            mc.getConnection().send(new ServerboundAttackPacket(target.getId()));
            mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
         }
      }
   }

   private void onGroundAttack() {
      this.lastCritTime = System.currentTimeMillis();
      double x = mc.player.getX();
      double y = mc.player.getY();
      double z = mc.player.getZ();
      ProxyServerTickListener.allowSend(() -> {
         String s0$ = this.mode.getValue();
         switch (s0$) {
            case "Packet":
               this.packetCrit(x, y, z);
               break;
            case "Grim":
               this.grimCrit(x, y, z);
               break;
            case "GrimNew":
               this.grimNewCrit(x, y, z);
         }
      });
      ((ClientPlayerEntityAccessor)mc.player).setLastOnGround(false);
   }

   private void packetCrit(double x, double y, double z) {
      if (mc.player.onGround()) {
         mc.getConnection().send(new Pos(x, y + 0.0625, z, false, mc.player.horizontalCollision));
         mc.getConnection().send(new Pos(x, y, z, false, mc.player.horizontalCollision));
      }
   }

   private void grimCrit(double x, double y, double z) {
      if (mc.player.onGround()) {
         if (!this.onlyPhased.getValue() || this.isPhased(mc.player)) {
            if (!this.onlyStandingStill.getValue()
               || !(Math.abs(mc.player.getDeltaMovement().x) > 0.01)
                  && !(Math.abs(mc.player.getDeltaMovement().y) > 0.01)
                  && !(Math.abs(mc.player.getDeltaMovement().z) > 0.01)) {
               if (this.onlyWhenHeadCovered.getValue()) {
                  BlockPos pos = mc.player.blockPosition();
                  BlockPos target = mc.player.isVisuallyCrawling() ? pos.above(1) : pos.above(2);
                  if (mc.level.getBlockState(target).isAir()) {
                     return;
                  }
               }

               float yaw = Night.ROTATION_MANAGER.getServerYaw();
               float pitch = Night.ROTATION_MANAGER.getServerPitch();
               mc.getConnection().send(new PosRot(x, y + 0.0625, z, yaw, pitch, false, mc.player.horizontalCollision));
               mc.getConnection().send(new PosRot(x, y + 0.0625013579, z, yaw, pitch, false, mc.player.horizontalCollision));
               mc.getConnection().send(new PosRot(x, y + 1.3579E-6, z, yaw, pitch, false, mc.player.horizontalCollision));
            }
         }
      }
   }

   private void grimNewCrit(double x, double y, double z) {
      if (mc.player.onGround()) {
         if (!this.onlyPhased.getValue() || this.isPhased(mc.player) && this.eyesPhased(mc.player)) {
            if (!this.onlyStandingStill.getValue()
               || !(Math.abs(mc.player.getDeltaMovement().x) > 0.01)
                  && !(Math.abs(mc.player.getDeltaMovement().y) > 0.01)
                  && !(Math.abs(mc.player.getDeltaMovement().z) > 0.01)) {
               if (this.onlyWhenHeadCovered.getValue()) {
                  BlockPos pos = mc.player.blockPosition();
                  BlockPos target = mc.player.isVisuallyCrawling() ? pos.above(1) : pos.above(2);
                  if (mc.level.getBlockState(target).isAir()) {
                     return;
                  }
               }

               float yaw = Night.ROTATION_MANAGER.getServerYaw();
               float pitch = Night.ROTATION_MANAGER.getServerPitch();
               float f = (float)((Math.random() * 2.0 - 1.0) * 0.001F);
               float f2 = Mth.clamp(pitch + f, -90.0F, 90.0F);
               mc.getConnection().send(new PosRot(x, y + 0.0626, z, yaw, f2, false, mc.player.horizontalCollision));
               mc.getConnection().send(new PosRot(x, y + 0.0455, z, yaw, f2, false, mc.player.horizontalCollision));
            }
         }
      }
   }

   private boolean isPhased(Entity e) {
      if (e != null && mc.level != null) {
         AABB box = e.getBoundingBox();
         int minX = Mth.floor(box.minX);
         int maxX = Mth.ceil(box.maxX);
         int minY = Mth.floor(box.minY);
         int maxY = Mth.ceil(box.maxY);
         int minZ = Mth.floor(box.minZ);
         int maxZ = Mth.ceil(box.maxZ);

         for (int x = minX; x < maxX; x++) {
            for (int y = minY; y < maxY; y++) {
               for (int z = minZ; z < maxZ; z++) {
                  BlockPos pos = new BlockPos(x, y, z);
                  VoxelShape shape = mc.level.getBlockState(pos).getCollisionShape(mc.level, pos);
                  if (!shape.isEmpty() && shape.bounds().move(pos).intersects(box)) {
                     return true;
                  }
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean eyesPhased(Player player) {
      Vec3 eyePos = player.getEyePosition();
      BlockPos pos = BlockPos.containing(eyePos);
      BlockState state = mc.level.getBlockState(pos);
      if (state.isAir()) {
         return false;
      } else {
         VoxelShape shape = state.getCollisionShape(mc.level, pos);
         if (shape.isEmpty()) {
            return false;
         } else {
            for (AABB box : shape.toAabbs()) {
               if (box.move(pos).contains(eyePos)) {
                  return true;
               }
            }

            return false;
         }
      }
   }

   @Override
   public String getMetaData() {
      return this.mode.getValue();
   }
}
