package night.modules.impl.combat;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerPopEvent;
import night.events.impl.PlayerUpdateEvent;
import night.mixins.accessors.ClientPlayerInteractionManagerAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.miscellaneous.FakePlayerModule;
import night.pingbypass.PingBypassFlags;
import night.settings.impl.BooleanSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.InventoryUtils;

@RegisterModule(
   name = "Mainhand",
   description = "Automatically manages totems and golden apples in your mainhand.",
   category = Module.Category.COMBAT
)
public class MainhandModule extends Module {
   public NumberSetting slot = new NumberSetting("Slot", "The hotbar slot (1-9) to keep a totem in.", 1, 1, 9);
   public NumberSetting delay = new NumberSetting("Delay", "Delay (ms) before refilling a totem to hotbar.", 0, 0, 2000);
   public BooleanSetting useGapple = new BooleanSetting("UseGapple", "Switches to golden apple when right clicking while holding a totem in mainhand.", true);
   public BooleanSetting lethalOverride = new BooleanSetting(
      "LethalOverride",
      "Allows eating a golden apple regardless of health when no enemies are in visual range.",
      new BooleanSetting.Visibility(this.useGapple, true),
      false
   );
   public NumberSetting health = new NumberSetting("Health", "The health at which a totem will be prioritized.", 16, 0, 36);
   public BooleanSetting elytraCheck = new BooleanSetting("ElytraCheck", "Prioritizes a totem whenever you're wearing an elytra.", true);
   public NumberSetting fallDistance = new NumberSetting("FallDistance", "The fall distance at which the module will prioritize a totem.", 20.0F, 0.0F, 80.0F);
   public BooleanSetting antiMace = new BooleanSetting("AntiMace", "Switches to a totem if a player near you is trying to smash attack you with a mace.", false);
   public NumberSetting maceRange = new NumberSetting(
      "MaceRange",
      "The distance at which an enemy has to be in with a mace in order to swap to a totem.",
      new BooleanSetting.Visibility(this.antiMace, true),
      12.0F,
      0.0F,
      24.0F
   );
   private long pendingRefillTime = 0L;
   private boolean eatingHotbar = false;
   private int previousHotbarSlot = -1;
   private boolean eatingInventory = false;
   private int swappedInvSlot = -1;
   private int swappedHotbarSlot = -1;
   public static volatile boolean hidingLegitInventory = false;

   @Override
   public void onEnable() {
      this.pendingRefillTime = 0L;
   }

   @SubscribeEvent(
      priority = Integer.MAX_VALUE
   )
   public void onPlayerPop(PlayerPopEvent event) {
      if (!PingBypassFlags.isPingBypassActive()) {
         if (event.getPlayer() == mc.player && !Night.MODULE_MANAGER.getModule(SuicideModule.class).isToggled()) {
            if (this.isToggled()) {
               mc.execute(() -> {
                  if (mc.player != null && mc.level != null) {
                     int targetSlot = this.slot.getValue().intValue() - 1;
                     long d = this.delay.getValue().longValue();
                     if (d <= 0L) {
                        this.refill(targetSlot);
                     } else {
                        this.pendingRefillTime = System.currentTimeMillis() + d;
                     }
                  }
               });
            }
         }
      }
   }

   private void refill(int targetHotbarSlot) {
      if (mc.player != null && mc.level != null) {
         if (!PingBypassFlags.isPingBypassActive()) {
            Screen currentScreen = mc.gui.screen();
            if (!(currentScreen instanceof AbstractContainerScreen)
               || currentScreen instanceof InventoryScreen
               || mc.player.containerMenu.getCarried().isEmpty()) {
               if (mc.player.getInventory().getItem(targetHotbarSlot).getItem() != Items.TOTEM_OF_UNDYING) {
                  int totemSlot = this.findRefillTotem(targetHotbarSlot);
                  if (totemSlot != -1) {
                     InventoryUtils.swap("Swap", totemSlot, targetHotbarSlot);
                  }
               }
            }
         }
      }
   }

   public boolean legitOwnsTotems() {
      return this.isToggled();
   }

   @SubscribeEvent(
      priority = Integer.MAX_VALUE
   )
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      this.updateMainhand();
   }

   private void updateMainhand() {
      if (mc.player != null && mc.level != null) {
         if (!PingBypassFlags.isPingBypassActive()) {
            Screen currentScreen = mc.gui.screen();
            boolean isContainerScreen = currentScreen instanceof AbstractContainerScreen && !(currentScreen instanceof InventoryScreen);
            if (!isContainerScreen || mc.player.containerMenu.getCarried().isEmpty()) {
               boolean isUsing = mc.options.keyUse.isDown() || mc.player.isUsingItem();
               if (this.eatingHotbar) {
                  if (!isUsing) {
                     if (this.previousHotbarSlot != -1) {
                        mc.player.getInventory().setSelectedSlot(this.previousHotbarSlot);
                        ((ClientPlayerInteractionManagerAccessor)mc.gameMode).invokeSyncSelectedSlot();
                     }

                     this.eatingHotbar = false;
                     this.previousHotbarSlot = -1;
                  }
               } else if (this.eatingInventory) {
                  if (!isUsing) {
                     if (this.swappedInvSlot != -1 && this.swappedHotbarSlot != -1) {
                        InventoryUtils.swap("Swap", this.swappedInvSlot, this.swappedHotbarSlot);
                     }

                     this.eatingInventory = false;
                     this.swappedInvSlot = -1;
                     this.swappedHotbarSlot = -1;
                  }
               } else {
                  boolean canGapple = !this.needsTotem() || this.lethalOverride.getValue() && !this.hasEnemyInVisualRange();
                  if (this.useGapple.getValue() && mc.options.keyUse.isDown() && mc.player.getMainHandItem().is(Items.TOTEM_OF_UNDYING) && canGapple) {
                     int hotbarGapple = this.findGappleHotbar();
                     if (hotbarGapple != -1) {
                        this.previousHotbarSlot = mc.player.getInventory().getSelectedSlot();
                        mc.player.getInventory().setSelectedSlot(hotbarGapple);
                        ((ClientPlayerInteractionManagerAccessor)mc.gameMode).invokeSyncSelectedSlot();
                        this.eatingHotbar = true;
                        return;
                     }

                     int invGapple = this.findGappleInventory();
                     if (invGapple != -1) {
                        this.swappedInvSlot = invGapple;
                        this.swappedHotbarSlot = mc.player.getInventory().getSelectedSlot();
                        InventoryUtils.swap("Swap", invGapple, this.swappedHotbarSlot);
                        this.eatingInventory = true;
                        return;
                     }
                  }

                  int targetSlot = this.slot.getValue().intValue() - 1;
                  long now = System.currentTimeMillis();
                  if (this.pendingRefillTime > 0L) {
                     if (now >= this.pendingRefillTime) {
                        this.pendingRefillTime = 0L;
                        this.refill(targetSlot);
                     }
                  } else {
                     boolean needRefill = mc.player.getInventory().getItem(targetSlot).getItem() != Items.TOTEM_OF_UNDYING;
                     if (needRefill) {
                        long d = this.delay.getValue().longValue();
                        if (d <= 0L) {
                           this.refill(targetSlot);
                        } else {
                           this.pendingRefillTime = now + d;
                        }
                     }
                  }

                  if (this.needsTotem()) {
                     int currentSelected = mc.player.getInventory().getSelectedSlot();
                     boolean slotHasTotem = mc.player.getInventory().getItem(targetSlot).getItem() == Items.TOTEM_OF_UNDYING;
                     if (currentSelected != targetSlot || !slotHasTotem) {
                        if (slotHasTotem) {
                           mc.player.getInventory().setSelectedSlot(targetSlot);
                           ((ClientPlayerInteractionManagerAccessor)mc.gameMode).invokeSyncSelectedSlot();
                        } else {
                           int anyHotbarTotem = InventoryUtils.find(Items.TOTEM_OF_UNDYING, InventoryUtils.HOTBAR_START, InventoryUtils.HOTBAR_END);
                           if (anyHotbarTotem != -1 && currentSelected != anyHotbarTotem) {
                              mc.player.getInventory().setSelectedSlot(anyHotbarTotem);
                              ((ClientPlayerInteractionManagerAccessor)mc.gameMode).invokeSyncSelectedSlot();
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private int findRefillTotem(int target) {
      int invTotem = InventoryUtils.findInventory(Items.TOTEM_OF_UNDYING);
      if (invTotem != -1) {
         return invTotem;
      } else {
         for (int i = InventoryUtils.HOTBAR_START; i <= InventoryUtils.HOTBAR_END; i++) {
            if (i != target && mc.player.getInventory().getItem(i).getItem() == Items.TOTEM_OF_UNDYING) {
               return i;
            }
         }

         return -1;
      }
   }

   private int findGappleHotbar() {
      int egap = InventoryUtils.find(Items.ENCHANTED_GOLDEN_APPLE, InventoryUtils.HOTBAR_START, InventoryUtils.HOTBAR_END);
      return egap != -1 ? egap : InventoryUtils.find(Items.GOLDEN_APPLE, InventoryUtils.HOTBAR_START, InventoryUtils.HOTBAR_END);
   }

   private int findGappleInventory() {
      int egap = InventoryUtils.find(Items.ENCHANTED_GOLDEN_APPLE, InventoryUtils.INVENTORY_START, InventoryUtils.INVENTORY_END);
      return egap != -1 ? egap : InventoryUtils.find(Items.GOLDEN_APPLE, InventoryUtils.INVENTORY_START, InventoryUtils.INVENTORY_END);
   }

   public boolean shouldLockSlot() {
      if (!this.isToggled()) {
         return false;
      } else if (mc.player == null) {
         return false;
      } else if (!this.eatingHotbar && !this.eatingInventory) {
         return InventoryUtils.find(Items.TOTEM_OF_UNDYING) == -1 ? false : this.needsTotem();
      } else {
         return false;
      }
   }

   private boolean needsTotem() {
      if (Night.MODULE_MANAGER.getModule(SuicideModule.class).isToggled() && Night.MODULE_MANAGER.getModule(SuicideModule.class).offhandOverride.getValue()) {
         return false;
      } else if (mc.player.getHealth() + mc.player.getAbsorptionAmount() <= this.health.getValue().floatValue()) {
         return true;
      } else if (mc.player.fallDistance > this.fallDistance.getValue().floatValue()) {
         return true;
      } else {
         return this.elytraCheck.getValue() && mc.player.getItemBySlot(EquipmentSlot.CHEST).getItem() == Items.ELYTRA
            ? true
            : this.antiMace.getValue()
               && mc.level
                  .players()
                  .stream()
                  .anyMatch(
                     entity -> entity != mc.player
                        && !Night.FRIEND_MANAGER.contains(entity.getName().getString())
                        && mc.player.distanceToSqr(entity) <= Mth.square(this.maceRange.getValue().floatValue())
                        && entity.fallDistance >= 1.5
                        && entity.getMainHandItem().getItem().equals(Items.MACE)
                  );
      }
   }

   private boolean hasEnemyInVisualRange() {
      if (mc.level != null && mc.player != null) {
         FakePlayerModule fakePlayer = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(FakePlayerModule.class) : null;
         return mc.level
            .players()
            .stream()
            .anyMatch(
               player -> player != mc.player
                  && !player.isDeadOrDying()
                  && !EntityUtils.isGhost(player)
                  && (fakePlayer == null || !fakePlayer.isToggled() || player != fakePlayer.getPlayer())
                  && !Night.FRIEND_MANAGER.contains(player.getName().getString())
            );
      } else {
         return false;
      }
   }

   @Override
   public void onDisable() {
      if (this.eatingHotbar && mc.player != null && this.previousHotbarSlot != -1) {
         mc.player.getInventory().setSelectedSlot(this.previousHotbarSlot);
         ((ClientPlayerInteractionManagerAccessor)mc.gameMode).invokeSyncSelectedSlot();
      }

      if (this.eatingInventory && mc.player != null && this.swappedInvSlot != -1 && this.swappedHotbarSlot != -1) {
         InventoryUtils.swap("Swap", this.swappedInvSlot, this.swappedHotbarSlot);
      }

      this.eatingHotbar = false;
      this.previousHotbarSlot = -1;
      this.eatingInventory = false;
      this.swappedInvSlot = -1;
      this.swappedHotbarSlot = -1;
      this.pendingRefillTime = 0L;
   }

   @Override
   public String getMetaData() {
      return "Slot " + this.slot.getValue().intValue();
   }
}
