package night.gui.api;

import java.util.List;

public interface ExpandableRow {
   String getRowName();

   boolean isOpen();

   float getOpenAmount();

   List<Button> getButtons();

   void setRevealHeight(int var1);

   void setSearchQuery(String var1);
}
