package night.managers;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.ComponentRenderUtils;
import net.minecraft.client.multiplayer.chat.GuiMessage;
import net.minecraft.client.multiplayer.chat.GuiMessageSource;
import net.minecraft.client.multiplayer.chat.GuiMessageTag;
import net.minecraft.client.multiplayer.chat.GuiMessage.Line;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.TickEvent;
import night.mixins.accessors.ChatHudAccessor;
import night.modules.impl.core.CommandsModule;
import night.modules.impl.miscellaneous.BetterChatModule;
import night.utils.IMinecraft;
import night.utils.chat.ChatUtils;
import night.utils.mixins.IChatHudLine;
import night.utils.mixins.IChatHudLineVisible;
import night.utils.text.FormattingUtils;

public class ChatManager implements IMinecraft {
   public static boolean isInsideHudExtractChat = false;
   private final List<String> awaitMessages = new ArrayList<>();

   public ChatManager() {
      Night.EVENT_HANDLER.subscribe(this);
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.gui != null) {
         if (!this.awaitMessages.isEmpty()) {
            for (String message : new ArrayList<>(this.awaitMessages)) {
               this.addMessage(message);
               this.awaitMessages.remove(message);
            }
         }
      }
   }

   public void message(String message) {
      if (mc.player != null && mc.gui != null) {
         this.addMessage(this.getWatermark() + " " + ChatUtils.getSecondary() + message);
      }
   }

   public void message(String message, String identifier) {
      if (mc.player != null && mc.gui != null) {
         deleteMessage(identifier);
         this.addMessage(this.getWatermark() + " " + ChatUtils.getSecondary() + message, identifier);
      }
   }

   public void tagged(String message, String tag) {
      if (mc.player != null && mc.gui != null) {
         this.addMessage(
            this.getWatermark()
               + ChatFormatting.DARK_AQUA
               + " ["
               + ChatFormatting.AQUA
               + tag
               + ChatFormatting.DARK_AQUA
               + "]: "
               + ChatUtils.getSecondary()
               + message
         );
      }
   }

   public void tagged(String message, String tag, String identifier) {
      if (mc.player != null && mc.gui != null) {
         deleteMessage(identifier);
         this.addMessage(
            this.getWatermark()
               + ChatFormatting.DARK_AQUA
               + " ["
               + ChatFormatting.AQUA
               + tag
               + ChatFormatting.DARK_AQUA
               + "]: "
               + ChatUtils.getSecondary()
               + message,
            identifier
         );
      }
   }

   public void info$await(String message) {
      this.awaitMessages
         .add(
            this.getWatermark()
               + ChatFormatting.DARK_BLUE
               + " ["
               + ChatFormatting.BLUE
               + "?"
               + ChatFormatting.DARK_BLUE
               + "] "
               + ChatUtils.getSecondary()
               + message
         );
   }

   public void info(String message) {
      if (mc.player != null && mc.gui != null) {
         this.addMessage(
            this.getWatermark()
               + ChatFormatting.DARK_BLUE
               + " ["
               + ChatFormatting.BLUE
               + "?"
               + ChatFormatting.DARK_BLUE
               + "] "
               + ChatUtils.getSecondary()
               + message
         );
      }
   }

   public void warn$await(String message) {
      this.awaitMessages
         .add(this.getWatermark() + ChatFormatting.GOLD + " [" + ChatFormatting.YELLOW + "!" + ChatFormatting.GOLD + "] " + ChatUtils.getSecondary() + message);
   }

   public void warn(String message) {
      if (mc.player != null && mc.gui != null) {
         this.addMessage(
            this.getWatermark() + ChatFormatting.GOLD + " [" + ChatFormatting.YELLOW + "!" + ChatFormatting.GOLD + "] " + ChatUtils.getSecondary() + message
         );
      }
   }

   public void error$await(String message) {
      this.awaitMessages
         .add(
            this.getWatermark()
               + ChatFormatting.DARK_RED
               + " ["
               + ChatFormatting.RED
               + "!!"
               + ChatFormatting.DARK_RED
               + "] "
               + ChatUtils.getSecondary()
               + message
         );
   }

   public void error(String message) {
      if (mc.player != null && mc.gui != null) {
         this.addMessage(
            this.getWatermark()
               + ChatFormatting.DARK_RED
               + " ["
               + ChatFormatting.RED
               + "!!"
               + ChatFormatting.DARK_RED
               + "] "
               + ChatUtils.getSecondary()
               + message
         );
      }
   }

   public void await(String message) {
      this.awaitMessages.add(this.getWatermark() + " " + ChatUtils.getSecondary() + message);
   }

   public void await(String message, String tag) {
      this.awaitMessages
         .add(
            this.getWatermark()
               + ChatFormatting.DARK_AQUA
               + " ["
               + ChatFormatting.AQUA
               + tag
               + ChatFormatting.DARK_AQUA
               + "]: "
               + ChatUtils.getSecondary()
               + message
         );
   }

   public void addMessage(String message) {
      this.addTextMessage(Component.literal(message), "");
   }

   public void addMessage(String message, String identifier) {
      this.addTextMessage(Component.literal(message), identifier);
   }

   public void addMessage(Component message) {
      this.addTextMessage(message, "");
   }

   public void addMessage(Component message, String identifier) {
      this.addTextMessage(message, identifier);
   }

   private void addTextMessage(Component message, String identifier) {
      if (!mc.isSameThread()) {
         mc.execute(() -> this.addTextMessage(message, identifier));
      } else {
         GuiMessage line = new GuiMessage(mc.gui.hud.getGuiTicks(), message, null, GuiMessageSource.SYSTEM_CLIENT, GuiMessageTag.system());
         ((IChatHudLine)line).night$setClientMessage(true);
         ((IChatHudLine)line).night$setClientIdentifier(identifier);
         ((ChatHudAccessor)mc.gui.hud.getChat()).invokeLogChatMessage(line);
         ((ChatHudAccessor)mc.gui.hud.getChat()).invokeAddMessage(line);
         List<FormattedCharSequence> list = ComponentRenderUtils.wrapComponents(
            line.content(),
            Mth.floor(((ChatHudAccessor)mc.gui.hud.getChat()).invokeGetWidth() / ((ChatHudAccessor)mc.gui.hud.getChat()).invokeGetScale()),
            mc.font
         );

         for (int j = 0; j < list.size(); j++) {
            FormattedCharSequence orderedText = list.get(j);
            if (mc.gui.hud.getChat().isChatFocused() && ((ChatHudAccessor)mc.gui.hud.getChat()).getScrolledLines() > 0) {
               ((ChatHudAccessor)mc.gui.hud.getChat()).setHasUnreadNewMessages(true);
               mc.gui.hud.getChat().scrollChat(1);
            }

            boolean bl2 = j == list.size() - 1;
            Line visible = new Line(line, orderedText, bl2);
            ((IChatHudLineVisible)visible).night$setClientMessage(true);
            ((IChatHudLineVisible)visible).night$setClientIdentifier(identifier);
            ((ChatHudAccessor)mc.gui.hud.getChat()).getVisibleMessages().addFirst(visible);
            if (Night.MODULE_MANAGER.getModule(BetterChatModule.class).isToggled()
               && Night.MODULE_MANAGER.getModule(BetterChatModule.class).animation.getValue()) {
               Night.MODULE_MANAGER.getModule(BetterChatModule.class).getAnimationMap().put(visible, System.currentTimeMillis());
            }
         }

         while (((ChatHudAccessor)mc.gui.hud.getChat()).getVisibleMessages().size() > 100) {
            ((ChatHudAccessor)mc.gui.hud.getChat()).getVisibleMessages().removeLast();
         }
      }
   }

   public static void deleteMessage(String identifier) {
      try {
         ArrayList<GuiMessage> removedLines = new ArrayList<>();

         for (GuiMessage message : ((ChatHudAccessor)mc.gui.hud.getChat()).getMessages()) {
            if (((IChatHudLine)message).night$isClientMessage()
               && !((IChatHudLine)message).night$getClientIdentifier().isEmpty()
               && ((IChatHudLine)message).night$getClientIdentifier().equals(identifier)) {
               removedLines.add(message);
            }
         }

         ArrayList<Line> removedVisibleLines = new ArrayList<>();

         for (Line messagex : ((ChatHudAccessor)mc.gui.hud.getChat()).getVisibleMessages()) {
            if (((IChatHudLineVisible)messagex).night$isClientMessage()
               && !((IChatHudLineVisible)messagex).night$getClientIdentifier().isEmpty()
               && ((IChatHudLineVisible)messagex).night$getClientIdentifier().equals(identifier)) {
               removedVisibleLines.add(messagex);
            }
         }

         ((ChatHudAccessor)mc.gui.hud.getChat()).getMessages().removeAll(removedLines);
         ((ChatHudAccessor)mc.gui.hud.getChat()).getVisibleMessages().removeAll(removedVisibleLines);
      } catch (Exception var5) {
         var5.printStackTrace();
      }
   }

   private String getWatermark() {
      return this.getWatermark(null);
   }

   private String getWatermark(String text) {
      return !Night.MODULE_MANAGER.getModule(CommandsModule.class).watermark.getValue()
         ? ""
         : FormattingUtils.getFormatting(Night.MODULE_MANAGER.getModule(CommandsModule.class).secondaryWatermarkColor.getValue())
            + Night.MODULE_MANAGER.getModule(CommandsModule.class).opening.getValue()
            + FormattingUtils.getFormatting(Night.MODULE_MANAGER.getModule(CommandsModule.class).primaryWatermarkColor.getValue())
            + (text == null ? Night.MODULE_MANAGER.getModule(CommandsModule.class).watermarkText.getValue() : text)
            + FormattingUtils.getFormatting(Night.MODULE_MANAGER.getModule(CommandsModule.class).secondaryWatermarkColor.getValue())
            + Night.MODULE_MANAGER.getModule(CommandsModule.class).closing.getValue();
   }
}
