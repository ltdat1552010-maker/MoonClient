package night.managers;

import java.awt.Color;
import java.util.ArrayList;
import lombok.Generated;
import night.Night;
import night.modules.impl.core.FriendModule;
import night.modules.impl.core.PingBypassModule;
import night.pingbypass.PingBypassFlags;

public class FriendManager {
   private final ArrayList<String> friends = new ArrayList<>();

   public boolean contains(String name) {
      return this.getFriendFire() ? false : this.friends.stream().anyMatch(name::equalsIgnoreCase);
   }

   public void add(String name) {
      if (!this.contains(name)) {
         this.friends.add(name);
         this.syncToProxy();
      }
   }

   public void remove(String name) {
      this.friends.removeIf(name::equalsIgnoreCase);
      this.syncToProxy();
   }

   public void clear() {
      this.friends.clear();
      this.syncToProxy();
   }

   private void syncToProxy() {
      if (PingBypassFlags.proxyForwardingActive && Night.PINGBYPASS_CONFIG != null && !Night.PINGBYPASS_CONFIG.isServer()) {
         PingBypassModule pingBypass = Night.MODULE_MANAGER.getModule(PingBypassModule.class);
         if (pingBypass != null) {
            pingBypass.syncFriendsToProxy();
         }
      }
   }

   public boolean getFriendFire() {
      if (Night.MODULE_MANAGER == null) {
         return false;
      } else {
         FriendModule module = Night.MODULE_MANAGER.getModule(FriendModule.class);
         return module != null && module.friendlyFire != null && module.friendlyFire.getValue();
      }
   }

   public void sendFriendMessage(String name) {
      if (Night.MODULE_MANAGER != null) {
         FriendModule module = Night.MODULE_MANAGER.getModule(FriendModule.class);
         if (module != null) {
            module.sendFriendMessage(name);
         }
      }
   }

   public Color getDefaultFriendColor() {
      return this.getDefaultFriendColor(255);
   }

   public Color getDefaultFriendColor(int alpha) {
      return new Color(85, 255, 255, alpha);
   }

   @Generated
   public ArrayList<String> getFriends() {
      return this.friends;
   }
}
