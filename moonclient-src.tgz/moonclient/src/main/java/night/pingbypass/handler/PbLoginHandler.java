package night.pingbypass.handler;

import com.mojang.authlib.GameProfile;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.util.Random;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.Connection;
import net.minecraft.network.DisconnectionDetails;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.configuration.ConfigurationProtocols;
import net.minecraft.network.protocol.cookie.ServerboundCookieResponsePacket;
import net.minecraft.network.protocol.login.ClientboundHelloPacket;
import net.minecraft.network.protocol.login.ClientboundLoginDisconnectPacket;
import net.minecraft.network.protocol.login.ClientboundLoginFinishedPacket;
import net.minecraft.network.protocol.login.ServerLoginPacketListener;
import net.minecraft.network.protocol.login.ServerboundCustomQueryAnswerPacket;
import net.minecraft.network.protocol.login.ServerboundHelloPacket;
import net.minecraft.network.protocol.login.ServerboundKeyPacket;
import net.minecraft.network.protocol.login.ServerboundLoginAcknowledgedPacket;
import net.minecraft.util.Crypt;
import net.minecraft.util.CryptException;
import night.pingbypass.server.ProxyServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PbLoginHandler implements ServerLoginPacketListener {
   private static final Logger LOGGER = LoggerFactory.getLogger(PbLoginHandler.class);
   private static final Random RANDOM = new Random();
   private final ProxyServer proxyServer;
   private final Connection connection;
   private final KeyPair keyPair;
   private final byte[] nonce = new byte[4];
   private PbLoginHandler.LoginState state = PbLoginHandler.LoginState.HELLO;
   private String playerName;
   private GameProfile acceptedProfile;

   public PbLoginHandler(ProxyServer proxyServer, Connection connection) {
      this.proxyServer = proxyServer;
      this.connection = connection;

      try {
         this.keyPair = Crypt.generateKeyPair();
      } catch (CryptException var4) {
         throw new IllegalStateException("Failed to generate RSA keypair", var4);
      }

      RANDOM.nextBytes(this.nonce);
   }

   public void handleHello(ServerboundHelloPacket packet) {
      if (this.state != PbLoginHandler.LoginState.HELLO) {
         throw new IllegalStateException("Unexpected hello packet");
      } else {
         this.playerName = packet.name();
         LOGGER.info("Login attempt from {}", this.playerName);
         this.state = PbLoginHandler.LoginState.KEY;
         this.connection.send(new ClientboundHelloPacket("", this.keyPair.getPublic().getEncoded(), this.nonce, false));
      }
   }

   public void handleKey(ServerboundKeyPacket packet) {
      if (this.state != PbLoginHandler.LoginState.KEY) {
         throw new IllegalStateException("Unexpected key packet");
      } else {
         PrivateKey privateKey = this.keyPair.getPrivate();
         if (!packet.isChallengeValid(this.nonce, privateKey)) {
            throw new IllegalStateException("Protocol error: invalid nonce!");
         } else {
            SecretKey secretKey;
            try {
               secretKey = packet.getSecretKey(privateKey);
            } catch (CryptException var7) {
               throw new IllegalStateException("Protocol error", var7);
            }

            this.state = PbLoginHandler.LoginState.READY_TO_ACCEPT;

            try {
               Cipher decryptCipher = Crypt.getCipher(2, secretKey);
               Cipher encryptCipher = Crypt.getCipher(1, secretKey);
               this.connection.setEncryptionKey(decryptCipher, encryptCipher);
            } catch (CryptException var6) {
               throw new IllegalStateException("Protocol error", var6);
            }

            this.acceptPlayer();
         }
      }
   }

   private void acceptPlayer() {
      GameProfile profile = new GameProfile(UUIDUtil.createOfflinePlayerUUID(this.playerName), this.playerName);
      this.acceptedProfile = profile;
      this.state = PbLoginHandler.LoginState.PROTOCOL_SWITCHING;
      this.connection.send(new ClientboundLoginFinishedPacket(profile, UUID.randomUUID()));
      LOGGER.info("Login success for {} ({}), waiting for LOGIN_ACKNOWLEDGED", profile.name(), profile.id());
   }

   public void handleLoginAcknowledgement(ServerboundLoginAcknowledgedPacket packet) {
      if (this.state != PbLoginHandler.LoginState.PROTOCOL_SWITCHING) {
         throw new IllegalStateException("Unexpected login acknowledgement packet");
      } else {
         this.connection.setupOutboundProtocol(ConfigurationProtocols.CLIENTBOUND);
         this.connection
            .setupInboundProtocol(ConfigurationProtocols.SERVERBOUND, new PbConfigurationHandler(this.proxyServer, this.connection, this.acceptedProfile));
         this.state = PbLoginHandler.LoginState.ACCEPTED;
         LOGGER.info("Transitioning {} to configuration phase", this.playerName);
      }
   }

   public void handleCustomQueryPacket(ServerboundCustomQueryAnswerPacket packet) {
      this.disconnect(Component.literal("Unexpected query response"));
   }

   public void handleCookieResponse(ServerboundCookieResponsePacket packet) {
      this.disconnect(Component.literal("Unexpected cookie response"));
   }

   public void onDisconnect(DisconnectionDetails info) {
      LOGGER.info("Client {} disconnected during login: {}", this.playerName != null ? this.playerName : "unknown", info.reason());
   }

   public boolean isAcceptingMessages() {
      return this.connection.isConnected();
   }

   private void disconnect(Component reason) {
      try {
         this.connection.send(new ClientboundLoginDisconnectPacket(reason));
         this.connection.disconnect(reason);
      } catch (Exception var3) {
         LOGGER.error("Error disconnecting client", var3);
      }
   }

   public String getPlayerName() {
      return this.playerName;
   }

   private static enum LoginState {
      HELLO,
      KEY,
      READY_TO_ACCEPT,
      PROTOCOL_SWITCHING,
      ACCEPTED;
   }
}
