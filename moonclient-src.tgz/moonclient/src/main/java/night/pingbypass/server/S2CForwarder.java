package night.pingbypass.server;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.network.Connection;
import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.PacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ClientboundPingPacket;
import net.minecraft.network.protocol.common.ClientboundTransferPacket;
import net.minecraft.network.protocol.game.ClientboundBundlePacket;
import net.minecraft.network.protocol.game.ClientboundStartConfigurationPacket;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketReceiveEvent;
import night.pingbypass.PingBypassFlags;
import night.pingbypass.ProtocolTransitionTracker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class S2CForwarder {
   private static final Logger LOGGER = LoggerFactory.getLogger(S2CForwarder.class);
   private final Connection clientConnection;
   private final List<Packet<?>> queuedPackets = new CopyOnWriteArrayList<>();
   private final AtomicBoolean locked = new AtomicBoolean(false);
   private volatile boolean active;

   public S2CForwarder(Connection clientConnection) {
      this.clientConnection = clientConnection;
      this.active = false;
   }

   public void start() {
      this.active = true;
      PingBypassFlags.proxyForwardingActive = true;
      Night.EVENT_HANDLER.subscribe(this);
      LOGGER.info("S2C forwarder started");
   }

   public void stop() {
      this.active = false;
      PingBypassFlags.proxyForwardingActive = false;
      Night.EVENT_HANDLER.unsubscribe(this);
      LOGGER.info("S2C forwarder stopped");
   }

   public void lock() {
      synchronized (this.locked) {
         this.locked.set(true);
      }
   }

   public void unlockAndFlush() {
      synchronized (this.locked) {
         for (Packet<?> packet : this.queuedPackets) {
            this.sendToClient(packet);
         }

         this.queuedPackets.clear();
         this.locked.set(false);
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      if (this.active && this.clientConnection.isConnected()) {
         Connection serverConnection = Night.PROXY_SERVER != null ? Night.PROXY_SERVER.getServerConnection() : null;
         if (serverConnection != null && event.getConnection() == serverConnection) {
            Packet<?> packet = event.getPacket();
            if (!(packet instanceof ClientboundKeepAlivePacket) && !(packet instanceof ClientboundPingPacket)) {
               if (!(packet instanceof ClientboundTransferPacket) && !(packet instanceof ClientboundStartConfigurationPacket)) {
                  PacketListener proxyListener = Night.PROXY_SERVER != null && Night.PROXY_SERVER.getServerConnection() != null
                     ? Night.PROXY_SERVER.getServerConnection().getPacketListener()
                     : null;
                  if (proxyListener != null && proxyListener.protocol() != ConnectionProtocol.PLAY) {
                     LOGGER.info(
                        "Suppressed {} while proxy's server connection is mid-reconfigure (protocol={})",
                        packet.getClass().getSimpleName(),
                        proxyListener.protocol()
                     );
                     ProtocolTransitionTracker.mark();
                  } else if (!(packet instanceof ClientboundBundlePacket)) {
                     synchronized (this.locked) {
                        if (this.locked.get()) {
                           this.queuedPackets.add(packet);
                        } else {
                           this.sendToClient(packet);
                        }
                     }
                  }
               } else {
                  LOGGER.info("Suppressed {} from being forwarded to client (proxy handles it internally)", packet.getClass().getSimpleName());
                  ProtocolTransitionTracker.mark();
               }
            }
         }
      }
   }

   private void sendToClient(Packet<?> packet) {
      if (this.clientConnection.isConnected()) {
         this.clientConnection.send(packet);
      }
   }
}
