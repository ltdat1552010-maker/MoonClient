package night.pingbypass;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PingBypassConfig {
   private static final Logger LOGGER = LoggerFactory.getLogger(PingBypassConfig.class);
   public static final String DEFAULT_SERVER = "false";
   public static final String DEFAULT_IP = "0.0.0.0";
   public static final String DEFAULT_PORT = "25565";
   public static final String DEFAULT_PASSWORD = "";
   private static final String KEY_SERVER = "pb.server";
   private static final String KEY_IP = "pb.ip";
   private static final String KEY_PORT = "pb.port";
   private static final String KEY_PASSWORD = "pb.password";
   private final Properties properties = new Properties();
   private final Path configPath;
   private boolean loaded;

   public PingBypassConfig(Path runDirectory) {
      this.configPath = runDirectory.resolve(Paths.get("night", "pingbypass.properties"));
   }

   public void load() {
      try {
         Path parentDir = this.configPath.getParent();
         if (parentDir != null) {
            Files.createDirectories(parentDir);
         }

         if (!Files.exists(this.configPath)) {
            Path oldConfigPath = this.configPath.getParent().getParent().resolve(Paths.get("euclient", "pingbypass.properties"));
            if (Files.exists(oldConfigPath)) {
               Files.copy(oldConfigPath, this.configPath, StandardCopyOption.COPY_ATTRIBUTES);
            } else {
               this.createDefaults();
            }
         }

         try (InputStream in = Files.newInputStream(this.configPath)) {
            this.properties.load(in);
         }
      } catch (IOException var12) {
         LOGGER.error("Failed to load PingBypass config from {}", this.configPath, var12);
      } finally {
         this.loaded = true;
      }
   }

   private void createDefaults() throws IOException {
      Properties defaults = new Properties();
      defaults.setProperty("pb.server", "false");
      defaults.setProperty("pb.ip", "0.0.0.0");
      defaults.setProperty("pb.port", "25565");
      defaults.setProperty("pb.password", "");

      try (OutputStream out = Files.newOutputStream(this.configPath)) {
         defaults.store(out, "PingBypass configuration");
      }
   }

   public boolean isServer() {
      return Boolean.parseBoolean(this.getProperty("pb.server", "false"));
   }

   public String getIp() {
      return this.getProperty("pb.ip", "0.0.0.0");
   }

   public int getPort() {
      String portStr = this.getProperty("pb.port", "25565");

      try {
         int port = Integer.parseInt(portStr);
         if (port >= 1 && port <= 65535) {
            return port;
         } else {
            LOGGER.error("PingBypass port out of range (1-65535): {}, falling back to default 25565", port);
            return 25565;
         }
      } catch (NumberFormatException var3) {
         LOGGER.error("PingBypass port is not a valid integer: '{}', falling back to default 25565", portStr);
         return 25565;
      }
   }

   public String getPassword() {
      return this.getProperty("pb.password", "");
   }

   public boolean hasPassword() {
      String password = this.getPassword();
      return password != null && !password.isEmpty();
   }

   public String getProperty(String key, String defaultValue) {
      String systemValue = System.getProperty(key);
      return systemValue != null ? systemValue : this.properties.getProperty(key, defaultValue);
   }

   public Properties toProperties() {
      Properties result = new Properties();
      result.setProperty("pb.server", String.valueOf(this.isServer()));
      result.setProperty("pb.ip", this.getIp());
      result.setProperty("pb.port", String.valueOf(this.getPort()));
      result.setProperty("pb.password", this.getPassword());
      return result;
   }

   public boolean isLoaded() {
      return this.loaded;
   }
}
