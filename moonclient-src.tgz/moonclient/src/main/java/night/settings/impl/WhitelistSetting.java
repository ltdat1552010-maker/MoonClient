package night.settings.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.Generated;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.level.block.Block;
import night.settings.Setting;

public class WhitelistSetting extends Setting {
   private final WhitelistSetting.Type type;
   private final Set<Object> whitelist = new HashSet<>();

   public WhitelistSetting(String name, String description, WhitelistSetting.Type type) {
      super(name, name, description, new Setting.Visibility());
      this.type = type;
   }

   public WhitelistSetting(String name, String tag, String description, WhitelistSetting.Type type) {
      super(name, tag, description, new Setting.Visibility());
      this.type = type;
   }

   public WhitelistSetting(String name, String description, Setting.Visibility visibility, WhitelistSetting.Type type) {
      super(name, name, description, visibility);
      this.type = type;
   }

   public WhitelistSetting(String name, String tag, String description, Setting.Visibility visibility, WhitelistSetting.Type type) {
      super(name, tag, description, visibility);
      this.type = type;
   }

   public void add(Object object) {
      this.whitelist.add(object);
   }

   public void remove(Object id) {
      this.whitelist.remove(id);
   }

   public boolean isWhitelistContains(Object object) {
      return this.whitelist.contains(object);
   }

   public List<String> getWhitelistIds() {
      return this.whitelist.stream().map(object -> {
         if (object instanceof Item item) {
            return BuiltInRegistries.ITEM.getKey(item).toString();
         } else if (object instanceof Block block) {
            return BuiltInRegistries.BLOCK.getKey(block).toString();
         } else {
            return object instanceof Potion potion ? BuiltInRegistries.POTION.getKey(potion).toString() : null;
         }
      }).toList();
   }

   public List<Potion> getWhitelistedPotions() {
      return this.whitelist.stream().filter(o -> o instanceof Potion).map(o -> (Potion)o).toList();
   }

   public void clear() {
      this.whitelist.clear();
   }

   @Generated
   public WhitelistSetting.Type getType() {
      return this.type;
   }

   @Generated
   public Set<Object> getWhitelist() {
      return this.whitelist;
   }

   public static enum Type {
      ITEMS,
      BLOCKS,
      POTIONS;
   }
}
