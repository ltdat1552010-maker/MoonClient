package night.settings.impl;

import lombok.Generated;
import night.settings.Setting;

public class PositionSetting extends Setting {
   private float x = 0.0F;
   private float y = 0.0F;

   public PositionSetting(String name, String description) {
      super(name, name, description, new Setting.Visibility());
   }

   public void set(float x, float y) {
      this.x = x;
      this.y = y;
   }

   public void resetValue() {
      this.x = 0.0F;
      this.y = 0.0F;
   }

   @Generated
   public float getX() {
      return this.x;
   }

   @Generated
   public float getY() {
      return this.y;
   }

   @Generated
   public void setX(float x) {
      this.x = x;
   }

   @Generated
   public void setY(float y) {
      this.y = y;
   }
}
