package night.commands.impl;

import java.util.List;
import java.util.Map;
import night.Night;
import night.commands.Command;
import night.commands.RegisterCommand;
import night.modules.impl.visuals.StashFinderModule;
import night.modules.impl.visuals.stashfinder.StashWebhook;
import night.utils.chat.ChatUtils;

@RegisterCommand(
   name = "stashfinder",
   aliases = {"stash"},
   tag = "StashFinder",
   description = "Configures StashFinder's Discord webhook and controls scan state.",
   syntax = "<webhook <url> | userid <id> | test | reset>"
)
public class StashFinderCommand extends Command {
   @Override
   public List<String> getSuggestions(String[] args) {
      return args.length == 0 ? List.of("webhook", "userid", "test", "reset") : List.of();
   }

   @Override
   public void execute(String[] args) {
      if (args.length == 0) {
         this.messageSyntax();
      } else {
         String var2 = args[0].toLowerCase();
         switch (var2) {
            case "webhook":
               if (args.length < 2) {
                  Night.CHAT_MANAGER
                     .tagged(
                        "Current webhook: " + ChatUtils.getPrimary() + (StashWebhook.getWebhookUrl().isBlank() ? "None" : StashWebhook.getWebhookUrl()),
                        this.getTag()
                     );
                  return;
               }

               String url = args[1];
               StashWebhook.setWebhookUrl(url);
               StashFinderModule modulex = Night.MODULE_MANAGER.getModule(StashFinderModule.class);
               if (modulex != null) {
                  modulex.webhookUrl.setValue(url);
               }

               Night.CHAT_MANAGER.tagged("Webhook URL updated.", this.getTag());
               break;
            case "userid":
               if (args.length < 2) {
                  Night.CHAT_MANAGER
                     .tagged(
                        "Current User ID: " + ChatUtils.getPrimary() + (StashWebhook.getUserId().isBlank() ? "None" : StashWebhook.getUserId()), this.getTag()
                     );
                  return;
               }

               String id = args[1];
               StashWebhook.setUserId(id);
               StashFinderModule modulex = Night.MODULE_MANAGER.getModule(StashFinderModule.class);
               if (modulex != null) {
                  modulex.userId.setValue(id);
               }

               Night.CHAT_MANAGER.tagged("User ID updated (will be pinged on stash finds).", this.getTag());
               break;
            case "test":
               StashFinderModule modulex = Night.MODULE_MANAGER.getModule(StashFinderModule.class);
               String url = modulex != null && !modulex.webhookUrl.getValue().isBlank() ? modulex.webhookUrl.getValue() : StashWebhook.getWebhookUrl();
               String id = modulex != null && !modulex.userId.getValue().isBlank() ? modulex.userId.getValue() : StashWebhook.getUserId();
               if (url.isBlank()) {
                  Night.CHAT_MANAGER
                     .tagged(
                        "No webhook URL configured. Use " + ChatUtils.getPrimary() + ".stashfinder webhook <url>" + ChatUtils.getSecondary() + " first.",
                        this.getTag()
                     );
               } else {
                  StashWebhook.send(0, 0, "Test Dimension", Map.of("Chests", 25, "Shulkers", 8), url, id);
                  Night.CHAT_MANAGER.tagged("Test webhook dispatched.", this.getTag());
               }
               break;
            case "reset":
               StashFinderModule module = Night.MODULE_MANAGER.getModule(StashFinderModule.class);
               if (module != null) {
                  module.resetCurrentWorldStore();
                  Night.CHAT_MANAGER.tagged("Scan history cleared for this world. All chunks will be re-evaluated.", this.getTag());
               }
               break;
            default:
               this.messageSyntax();
         }
      }
   }
}
