package night.commands.impl;

import java.util.List;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.world.entity.Pose;
import night.Night;
import night.commands.Command;
import night.commands.RegisterCommand;
import night.events.impl.PlayerPopEvent;
import night.modules.impl.miscellaneous.FakePlayerModule;

@RegisterCommand(
   name = "fakeplayer",
   aliases = {"fp"},
   description = "Spawns a client-side fake player to test on.",
   syntax = "[remove|pop|swim|record|stop|play|<name>]"
)
public class FakePlayerCommand extends Command {
   private static final byte TOTEM_POP_EVENT_ID = 35;

   @Override
   public void execute(String[] args) {
      FakePlayerModule fpModule = Night.MODULE_MANAGER.getModule(FakePlayerModule.class);
      if (fpModule != null) {
         if (args.length == 0) {
            fpModule.setToggled(!fpModule.isToggled());
         } else {
            String var3 = args[0].toLowerCase();
            switch (var3) {
               case "remove":
                  if (fpModule.isToggled()) {
                     fpModule.setToggled(false);
                  } else {
                     Night.CHAT_MANAGER.warn("No fake player spawned.");
                  }
                  break;
               case "pop":
                  this.popBot(fpModule);
                  break;
               case "swim":
                  this.toggleSwim(fpModule);
                  break;
               case "record":
                  fpModule.startRecording();
                  break;
               case "stop":
                  fpModule.stopRecording();
                  break;
               case "play":
                  fpModule.startPlaying();
                  break;
               default:
                  fpModule.name.setValue(args[0]);
                  if (!fpModule.isToggled()) {
                     fpModule.setToggled(true);
                  } else {
                     fpModule.setToggled(false);
                     fpModule.setToggled(true);
                  }
            }
         }
      }
   }

   @Override
   public List<String> getSuggestions(String[] args) {
      return args.length == 0 ? List.of("remove", "pop", "swim", "record", "stop", "play") : List.of();
   }

   private boolean nullCheck() {
      return mc.level == null || mc.player == null;
   }

   private void popBot(FakePlayerModule fpModule) {
      if (!this.nullCheck() && mc.getConnection() != null) {
         RemotePlayer fake = fpModule.getPlayer();
         if (fake != null && fake.level() == mc.level) {
            mc.getConnection().handleEntityEvent(new ClientboundEntityEventPacket(fake, (byte)35));
            Night.EVENT_HANDLER.post(new PlayerPopEvent(fake, 1));
            Night.CHAT_MANAGER.tagged("Popped fake player.", "FakePlayer");
         } else {
            Night.CHAT_MANAGER.warn("No fake player spawned. Spawn one first.");
         }
      } else {
         Night.CHAT_MANAGER.warn("You need to be in a world to do that.");
      }
   }

   private void toggleSwim(FakePlayerModule fpModule) {
      if (this.nullCheck()) {
         Night.CHAT_MANAGER.warn("You need to be in a world to do that.");
      } else {
         RemotePlayer fake = fpModule.getPlayer();
         if (fake != null && fake.level() == mc.level) {
            Pose pose = fake.getPose() != Pose.SWIMMING ? Pose.SWIMMING : Pose.STANDING;
            fake.setPose(pose);
            fake.refreshDimensions();
            Night.CHAT_MANAGER.tagged(pose == Pose.SWIMMING ? "Fake player now in swim pose." : "Fake player now standing.", "FakePlayer");
         } else {
            Night.CHAT_MANAGER.warn("No fake player spawned. Spawn one first.");
         }
      }
   }
}
