package night.utils.color;

import java.awt.Color;
import net.minecraft.ChatFormatting;
import night.Night;
import night.modules.impl.core.ColorModule;
import night.settings.impl.ColorSetting;

public class ColorUtils {
   public static ColorSetting.Color getDefaultColor() {
      return new ColorSetting.Color(new Color(160, 120, 255), true, false);
   }

   public static ColorSetting.Color getDefaultFillColor() {
      return new ColorSetting.Color(new Color(160, 120, 255, 40), true, false);
   }

   public static ColorSetting.Color getDefaultOutlineColor() {
      return new ColorSetting.Color(new Color(160, 120, 255, 120), true, false);
   }

   public static Color getGlobalColor() {
      return getGlobalColor(255, 0L);
   }

   public static Color getGlobalColor(int alpha) {
      return getGlobalColor(alpha, 0L);
   }

   public static Color getGlobalColor(int alpha, long index) {
      ColorModule cm = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ColorModule.class) : null;
      if (cm == null) {
         return new Color(160, 120, 255, alpha);
      } else {
         return cm.color.isRainbow()
            ? getRainbow(
               cm.rainbowSpeed.getValue().longValue(),
               cm.rainbowSaturation.getValue().floatValue() / 100.0F,
               cm.rainbowBrightness.getValue().floatValue() / 100.0F,
               alpha,
               index
            )
            : getColor(cm.color.getValue().getColor(), alpha);
      }
   }

   public static Color getColor(Color color, int alpha) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
   }

   public static Color getRainbow() {
      return getRainbow(255);
   }

   public static Color getOffsetRainbow(long index) {
      return getOffsetRainbow(255, index);
   }

   public static Color getRainbow(int alpha) {
      return getOffsetRainbow(alpha, 0L);
   }

   public static Color getOffsetRainbow(int alpha, long index) {
      ColorModule cm = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ColorModule.class) : null;
      long speed = cm != null ? cm.rainbowSpeed.getValue().longValue() : 6L;
      float sat = cm != null ? cm.rainbowSaturation.getValue().floatValue() / 100.0F : 1.0F;
      float bri = cm != null ? cm.rainbowBrightness.getValue().floatValue() / 100.0F : 1.0F;
      float scale = cm != null && cm.rainbowScale != null ? cm.rainbowScale.getValue().floatValue() / 100.0F : 1.0F;
      return getRainbow(speed, sat, bri, alpha, (long)((float)index * scale));
   }

   public static Color getRainbow(long speed, float saturation, float brightness, int alpha) {
      return getRainbow(speed, saturation, brightness, alpha, 0L);
   }

   public static Color getRainbow(long speed, float saturation, float brightness, int alpha, long index) {
      speed = Math.clamp(speed, 1, 20);
      double period = 10500.0 - 500.0 * speed;
      double timeProgress = System.currentTimeMillis() % (long)period / period;
      double spatialProgress = index * 0.0035;
      float hue = (float)((timeProgress + spatialProgress) % 1.0);
      if (hue < 0.0F) {
         hue++;
      }

      Color color = new Color(Color.HSBtoRGB(Math.clamp(hue, 0.0F, 1.0F), Math.clamp(saturation, 0.0F, 1.0F), Math.clamp(brightness, 0.0F, 1.0F)));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
   }

   public static Color getOffsetWave(Color color, long index) {
      ColorModule cm = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ColorModule.class) : null;
      long speed = cm != null ? cm.rainbowSpeed.getValue().longValue() : 6L;
      return getWave(color, speed, 255, index);
   }

   public static Color getWave(Color color, long speed, int alpha, long index) {
      speed = Math.max(1L, Math.min(speed, 20L));
      float[] hsb = new float[3];
      Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), hsb);
      double period = 10500.0 - 500.0 * speed;
      double timeProgress = System.currentTimeMillis() % (long)period / period;
      double spatialProgress = index * 0.0035;
      double cycle = (timeProgress + spatialProgress) % 1.0;
      if (cycle < 0.0) {
         cycle++;
      }

      float adjustedBrightness = (float)Math.abs(cycle * 2.0 % 2.0 - 1.0);
      hsb[2] = 0.5F + 0.5F * adjustedBrightness;
      Color resultColor = new Color(Color.HSBtoRGB(hsb[0], hsb[1], hsb[2]));
      return new Color(resultColor.getRed(), resultColor.getGreen(), resultColor.getBlue(), alpha);
   }

   public static Color getPulse(Color color) {
      return getPulse(color, 15L);
   }

   public static Color getPulse(Color color, long speed) {
      speed = Math.max(1L, Math.min(speed, 20L));
      double sin = Math.sin((Math.PI * 2) * ((float)speed / 20.0F) * ((float)(System.currentTimeMillis() - Night.UPTIME) / 1000.0F));
      double scale = (sin + 1.0) / 2.0;
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(color.getAlpha() * scale));
   }

   public static Color getHashColor(String text) {
      int hash = text.hashCode();
      return new Color((hash & 0xFF0000) >> 16, (hash & 0xFF00) >> 8, hash & 0xFF);
   }

   public static boolean isValidColorCode(String code) {
      if (code.startsWith("#")) {
         code = code.substring(1);
      }

      if (code.length() != 3 && code.length() != 6) {
         return false;
      } else {
         for (int i = 0; i < code.length(); i++) {
            if ((code.charAt(i) < '0' || code.charAt(i) > '\t')
               && (code.charAt(i) < 'a' || code.charAt(i) > 'f')
               && code.charAt(i) < 'A'
               && code.charAt(i) > 'F') {
               return false;
            }
         }

         return true;
      }
   }

   public static ChatFormatting getHealthColor(double health) {
      if (health > 18.0) {
         return ChatFormatting.GREEN;
      } else if (health > 16.0) {
         return ChatFormatting.DARK_GREEN;
      } else if (health > 12.0) {
         return ChatFormatting.YELLOW;
      } else if (health > 8.0) {
         return ChatFormatting.GOLD;
      } else {
         return health > 5.0 ? ChatFormatting.RED : ChatFormatting.DARK_RED;
      }
   }

   public static ChatFormatting getTotemColor(int pops) {
      if (pops == 1) {
         return ChatFormatting.GREEN;
      } else if (pops == 2) {
         return ChatFormatting.DARK_GREEN;
      } else if (pops == 3) {
         return ChatFormatting.YELLOW;
      } else if (pops == 4) {
         return ChatFormatting.GOLD;
      } else {
         return pops == 5 ? ChatFormatting.RED : ChatFormatting.DARK_RED;
      }
   }
}
