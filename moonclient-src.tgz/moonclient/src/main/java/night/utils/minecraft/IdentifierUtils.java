package night.utils.minecraft;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.level.block.Block;

public class IdentifierUtils {
   public static Item getItem(String name) {
      try {
         Item item = getIdentifier(BuiltInRegistries.ITEM, name);
         if (item != null) {
            return item;
         }
      } catch (Exception var2) {
      }

      return null;
   }

   public static Block getBlock(String name) {
      try {
         Block block = getIdentifier(BuiltInRegistries.BLOCK, name);
         if (block != null) {
            return block;
         }
      } catch (Exception var2) {
      }

      return null;
   }

   public static Potion getPotion(String name) {
      try {
         Potion potion = getIdentifier(BuiltInRegistries.POTION, name);
         if (potion != null) {
            return potion;
         }
      } catch (Exception var2) {
      }

      return null;
   }

   public static <T> T getIdentifier(Registry<T> registry, String name) {
      if (name != null && !name.trim().isEmpty()) {
         name = name.trim();
         Identifier identifier = Identifier.tryParse(name.contains(":") ? name : "minecraft:" + name);
         if (identifier == null) {
            return null;
         } else {
            return (T)(registry.containsKey(identifier) ? registry.getValue(identifier) : null);
         }
      } else {
         return null;
      }
   }
}
