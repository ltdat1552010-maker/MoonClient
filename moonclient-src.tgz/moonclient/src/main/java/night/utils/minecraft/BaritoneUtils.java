package night.utils.minecraft;

import java.util.Optional;

public final class BaritoneUtils {
   private BaritoneUtils() {
   }

   public static Object getPrimaryBaritone() {
      try {
         Class<?> apiClass = Class.forName("baritone.api.BaritoneAPI");
         Object provider = apiClass.getMethod("getProvider").invoke(null);
         return provider.getClass().getMethod("getPrimaryBaritone").invoke(provider);
      } catch (Throwable var2) {
         return null;
      }
   }

   public static boolean isAvailable() {
      return getPrimaryBaritone() != null;
   }

   public static boolean isActive() {
      Object baritone = getPrimaryBaritone();
      if (baritone == null) {
         return false;
      } else {
         try {
            Object pathingBehavior = baritone.getClass().getMethod("getPathingBehavior").invoke(baritone);
            if ((Boolean)pathingBehavior.getClass().getMethod("isPathing").invoke(pathingBehavior)) {
               return true;
            }
         } catch (Throwable var7) {
         }

         try {
            Object customGoalProcess = baritone.getClass().getMethod("getCustomGoalProcess").invoke(baritone);
            if ((Boolean)customGoalProcess.getClass().getMethod("isActive").invoke(customGoalProcess)) {
               return true;
            }
         } catch (Throwable var6) {
         }

         try {
            Object elytraProcess = baritone.getClass().getMethod("getElytraProcess").invoke(baritone);
            if (elytraProcess != null && (Boolean)elytraProcess.getClass().getMethod("isActive").invoke(elytraProcess)) {
               return true;
            }
         } catch (Throwable var5) {
         }

         try {
            Object pcm = baritone.getClass().getMethod("getPathingControlManager").invoke(baritone);
            Optional<?> mostRecent = (Optional<?>)pcm.getClass().getMethod("mostRecentInControl").invoke(pcm);
            if (mostRecent.isPresent()) {
               Object proc = mostRecent.get();
               if ((Boolean)proc.getClass().getMethod("isActive").invoke(proc)) {
                  return true;
               }
            }
         } catch (Throwable var4) {
         }

         return false;
      }
   }
}
