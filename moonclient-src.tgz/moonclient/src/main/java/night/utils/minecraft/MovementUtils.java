package night.utils.minecraft;

import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.impl.PlayerMoveEvent;
import night.mixins.accessors.Vec3dAccessor;
import night.modules.api.ISprintModule;
import night.utils.IMinecraft;
import night.utils.rotations.RotationUtils;
import org.joml.Vector2d;

public class MovementUtils implements IMinecraft {
   public static double DEFAULT_SPEED = 0.2873;

   public static Vector2d forward(double speed) {
      float forward = mc.player.input.getMoveVector().y;
      float sideways = mc.player.input.getMoveVector().x;
      float yaw = mc.player.getYRot();
      if (Night.MODULE_MANAGER != null) {
         ISprintModule sprint = (ISprintModule)Night.MODULE_MANAGER.getModule("Sprint");
         if (sprint != null && sprint.isGrimCompensating()) {
            yaw = sprint.getGrimYaw();
         }
      }

      if (forward == 0.0F && sideways == 0.0F) {
         return new Vector2d(0.0, 0.0);
      } else {
         float magnitude = (float)Math.sqrt(forward * forward + sideways * sideways);
         if (magnitude > 1.0E-4F && Math.abs(magnitude - 1.0F) > 1.0E-4F) {
            forward /= magnitude;
            sideways /= magnitude;
         }

         double motionX = Math.cos(Math.toRadians(yaw + 90.0F));
         double motionZ = Math.sin(Math.toRadians(yaw + 90.0F));
         return new Vector2d(forward * speed * motionX + sideways * speed * motionZ, forward * speed * motionZ - sideways * speed * motionX);
      }
   }

   public static double[] straightForward(double speed) {
      float yaw = mc.player.getYRot();
      if (Night.MODULE_MANAGER != null) {
         ISprintModule sprint = (ISprintModule)Night.MODULE_MANAGER.getModule("Sprint");
         if (sprint != null && sprint.isGrimCompensating()) {
            yaw = sprint.getGrimYaw();
         }
      }

      return new double[]{speed * Math.cos(Math.toRadians(yaw + 90.0F)), speed * Math.sin(Math.toRadians(yaw + 90.0F))};
   }

   public static double getPotionSpeed(double speed) {
      if (mc.player.hasEffect(MobEffects.SPEED)) {
         speed *= 1.0 + 0.2 * (mc.player.getEffect(MobEffects.SPEED).getAmplifier() + 1);
      }

      if (mc.player.hasEffect(MobEffects.SLOWNESS)) {
         speed /= 1.0 + 0.2 * (mc.player.getEffect(MobEffects.SLOWNESS).getAmplifier() + 1);
      }

      return speed;
   }

   public static double getPotionJump(double jump) {
      if (mc.player.hasEffect(MobEffects.JUMP_BOOST)) {
         jump += (mc.player.getEffect(MobEffects.JUMP_BOOST).getAmplifier() + 1) * 0.1F;
      }

      return jump;
   }

   public static boolean isMoving() {
      return mc.player == null
         ? false
         : mc.options.keyUp.isDown()
            || mc.options.keyDown.isDown()
            || mc.options.keyLeft.isDown()
            || mc.options.keyRight.isDown()
            || mc.player.input != null && (mc.player.input.getMoveVector().x != 0.0F || mc.player.input.getMoveVector().y != 0.0F)
            || mc.player.xxa != 0.0F
            || mc.player.zza != 0.0F;
   }

   public static void moveTowards(PlayerMoveEvent event, Vec3 vec3d, double speed) {
      double angle = Math.toRadians(RotationUtils.getRotations(vec3d)[0]);
      double x = -Math.sin(angle) * speed;
      double z = Math.cos(angle) * speed;
      double[] difference = new double[]{vec3d.x - mc.player.getX(), vec3d.z - mc.player.getZ()};
      event.setMovement(new Vec3(Math.abs(x) < Math.abs(difference[0]) ? x : difference[0], event.getMovement().y, event.getMovement().z));
      event.setMovement(new Vec3(event.getMovement().x, event.getMovement().y, Math.abs(z) < Math.abs(difference[1]) ? z : difference[1]));
      ((Vec3dAccessor)mc.player.getDeltaMovement()).setX(0.0);
      ((Vec3dAccessor)mc.player.getDeltaMovement()).setZ(0.0);
      event.setCancelled(true);
   }
}
