package night.utils.minecraft;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.modules.impl.movement.HitboxDesyncModule;
import night.utils.IMinecraft;

public class HoleUtils implements IMinecraft {
   private static final Vec3i[] holeOffsets = new Vec3i[]{
      new Vec3i(0, -1, 0), new Vec3i(1, 0, 0), new Vec3i(-1, 0, 0), new Vec3i(0, 0, 1), new Vec3i(0, 0, -1)
   };
   private static final Vec3i[] singleOffsets = new Vec3i[]{
      new Vec3i(-1, 0, 0), new Vec3i(1, 0, 0), new Vec3i(0, 0, -1), new Vec3i(0, 0, 1), new Vec3i(0, -1, 0)
   };
   private static final Vec3i[] doubleXOffsets = new Vec3i[]{
      new Vec3i(-1, 0, 0),
      new Vec3i(0, 0, -1),
      new Vec3i(0, 0, 1),
      new Vec3i(0, -1, 0),
      new Vec3i(2, 0, 0),
      new Vec3i(1, 0, -1),
      new Vec3i(1, 0, 1),
      new Vec3i(1, -1, 0)
   };
   private static final Vec3i[] doubleZOffsets = new Vec3i[]{
      new Vec3i(0, 0, -1),
      new Vec3i(-1, 0, 0),
      new Vec3i(1, 0, 0),
      new Vec3i(0, -1, 0),
      new Vec3i(0, 0, 2),
      new Vec3i(-1, 0, 1),
      new Vec3i(1, 0, 1),
      new Vec3i(0, -1, 1)
   };
   private static final Vec3i[] quadOffsets = new Vec3i[]{
      new Vec3i(-1, 0, 0),
      new Vec3i(0, 0, -1),
      new Vec3i(0, -1, 0),
      new Vec3i(2, 0, 0),
      new Vec3i(1, 0, -1),
      new Vec3i(1, -1, 0),
      new Vec3i(-1, 0, 1),
      new Vec3i(0, 0, 2),
      new Vec3i(0, -1, 1),
      new Vec3i(2, 0, 1),
      new Vec3i(1, 0, 2),
      new Vec3i(1, -1, 1)
   };

   public static boolean isPlayerInHole(Player player) {
      return getFeetPositions(player, true, true, false).stream().noneMatch(position -> mc.level.getBlockState(position).canBeReplaced());
   }

   public static List<BlockPos> getInsidePositions(Entity targetEntity) {
      if (targetEntity != null && mc.level != null) {
         List<BlockPos> targetPositions = new ArrayList<>();
         AABB box = targetEntity.getBoundingBox();
         boolean isHorizontal = targetEntity.isSwimming()
            || targetEntity.isVisuallySwimming()
            || targetEntity.isVisuallyCrawling()
            || targetEntity instanceof LivingEntity living && living.isFallFlying()
            || targetEntity.getPose() == Pose.SWIMMING
            || targetEntity.getPose() == Pose.FALL_FLYING
            || box.maxY - box.minY <= 1.0;
         if (isHorizontal) {
            float yaw = targetEntity.getYRot();
            double rad = Math.toRadians(yaw);
            double dirX = -Math.sin(rad);
            double dirZ = Math.cos(rad);
            double posX = targetEntity.getX();
            double posY = targetEntity.getY();
            double posZ = targetEntity.getZ();

            for (double dist = -0.9; dist <= 0.9; dist += 0.2) {
               for (double width = -0.3; width <= 0.3; width += 0.3) {
                  double sx = posX + dirX * dist - dirZ * width;
                  double sz = posZ + dirZ * dist + dirX * width;
                  BlockPos pos = new BlockPos((int)Math.floor(sx), (int)Math.floor(posY), (int)Math.floor(sz));
                  if (!targetPositions.contains(pos)) {
                     targetPositions.add(pos);
                  }
               }
            }

            int minX = (int)Math.floor(box.minX);
            int maxX = (int)Math.ceil(box.maxX);
            int minY = (int)Math.floor(box.minY);
            int maxY = (int)Math.ceil(box.maxY);
            int minZ = (int)Math.floor(box.minZ);
            int maxZ = (int)Math.ceil(box.maxZ);

            for (int x = minX; x < maxX; x++) {
               for (int y = minY; y < maxY; y++) {
                  for (int z = minZ; z < maxZ; z++) {
                     BlockPos pos = new BlockPos(x, y, z);
                     if (!targetPositions.contains(pos)) {
                        targetPositions.add(pos);
                     }
                  }
               }
            }
         } else {
            int minX = (int)Math.floor(box.minX);
            int maxX = (int)Math.ceil(box.maxX);
            int minY = (int)Math.floor(box.minY);
            int minZ = (int)Math.floor(box.minZ);
            int maxZ = (int)Math.ceil(box.maxZ);
            int scanMaxY = (int)Math.ceil(box.maxY);

            for (int x = minX; x < maxX; x++) {
               for (int y = minY; y < scanMaxY; y++) {
                  for (int zx = minZ; zx < maxZ; zx++) {
                     BlockPos pos = new BlockPos(x, y, zx);
                     if (!targetPositions.contains(pos)) {
                        targetPositions.add(pos);
                     }
                  }
               }
            }
         }

         if (targetPositions.isEmpty()) {
            targetPositions.add(PositionUtils.getFlooredPosition(targetEntity));
         }

         return targetPositions;
      } else {
         return Collections.emptyList();
      }
   }

   public static BlockPos getTargetFeetPosition(Player target) {
      if (target != null && mc.level != null) {
         BlockPos floored = PositionUtils.getFlooredPosition(target);
         if (mc.level.getBlockState(floored.below()).canBeReplaced()) {
            for (int dy = 2; dy <= 3; dy++) {
               BlockPos below = floored.below(dy);
               if (!mc.level.getBlockState(below).canBeReplaced()) {
                  return below.above();
               }
            }
         }

         return floored;
      } else {
         return BlockPos.ZERO;
      }
   }

   public static HashSet<BlockPos> getFeetPositions(Player target, boolean extension, boolean floor, boolean targetOnly) {
      return getFeetPositions(target, extension, floor, floor, targetOnly);
   }

   public static HashSet<BlockPos> getFeetPositions(Player target, boolean extension, boolean floor, boolean underFeet, boolean targetOnly) {
      HashSet<BlockPos> positions = new HashSet<>();
      HashSet<BlockPos> blacklist = new HashSet<>();
      HitboxDesyncModule hitboxDesyncModule = Night.MODULE_MANAGER.getModule(HitboxDesyncModule.class);
      AABB bounds = target.getBoundingBox();
      double fracY = bounds.minY - Math.floor(bounds.minY);
      int feetY = (int)(fracY > 0.8 ? Math.floor(bounds.minY) + 1.0 : Math.floor(bounds.minY));
      int minX = (int)Math.floor(bounds.minX);
      int maxX = (int)Math.floor(bounds.maxX);
      int minZ = (int)Math.floor(bounds.minZ);
      int maxZ = (int)Math.floor(bounds.maxZ);
      BlockPos centerPos = new BlockPos((int)Math.floor(target.getX()), feetY, (int)Math.floor(target.getZ()));
      if (mc.level != null && !target.onGround() && mc.level.getBlockState(centerPos.below()).canBeReplaced()) {
         for (int dy = 2; dy <= 3; dy++) {
            BlockPos below = centerPos.below(dy);
            if (!mc.level.getBlockState(below).canBeReplaced()) {
               feetY = below.above().getY();
               break;
            }
         }
      }

      BlockPos floored = PositionUtils.getFlooredPosition(target);
      blacklist.add(new BlockPos(floored.getX(), feetY, floored.getZ()));

      for (int x = minX; x <= maxX; x++) {
         for (int z = minZ; z <= maxZ; z++) {
            if (bounds.intersects(new AABB(x, feetY, z, x + 1, feetY + 1, z + 1))) {
               blacklist.add(new BlockPos(x, feetY, z));
            }
         }
      }

      if (extension && mc.level != null) {
         for (BlockPos cell : Set.copyOf(blacklist)) {
            for (Direction dir : Direction.values()) {
               if (!dir.getAxis().isVertical()) {
                  BlockPos off = cell.relative(dir);
                  if (mc.level.getBlockState(off).canBeReplaced()) {
                     List<Player> collisions = WorldUtils.getCollisions(off);
                     if (!collisions.isEmpty()) {
                        for (Player player : collisions) {
                           if (player != target
                              && (player != mc.player || target != mc.player)
                              && (!targetOnly || player == target)
                              && (target != mc.player || Night.FRIEND_MANAGER.contains(player.getName().getString()))
                              && !(Math.abs(player.getY() - target.getY()) > 1.0)) {
                              AABB pBox = player.getBoundingBox();
                              int pMinX = (int)Math.floor(pBox.minX + 0.001);
                              int pMaxX = (int)Math.floor(pBox.maxX - 0.001);
                              int pMinZ = (int)Math.floor(pBox.minZ + 0.001);
                              int pMaxZ = (int)Math.floor(pBox.maxZ - 0.001);

                              for (int px = pMinX; px <= pMaxX; px++) {
                                 for (int pz = pMinZ; pz <= pMaxZ; pz++) {
                                    blacklist.add(new BlockPos(px, feetY, pz));
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      for (BlockPos pos : blacklist) {
         if (floor && underFeet) {
            positions.add(pos.below());
         }

         for (Direction dirx : Direction.values()) {
            if (dirx.getAxis().isHorizontal()) {
               BlockPos off = pos.relative(dirx);
               if (!blacklist.contains(off)) {
                  positions.add(off);
                  if (floor && mc.level != null && mc.level.getBlockState(off).canBeReplaced()) {
                     positions.add(off.below());
                  }
               }
            }
         }
      }

      int targetFeetY = feetY;
      positions.removeIf(p -> p.getY() == targetFeetY && target.getBoundingBox().intersects(new AABB(p)));
      if (target == mc.player && hitboxDesyncModule.isToggled() && hitboxDesyncModule.close.getValue()) {
         List<BlockPos> desyncPositions = new ArrayList<>();
         Vec3 vec3d = Vec3.atCenterOf(mc.player.blockPosition());
         boolean flagX = vec3d.x - mc.player.getX() > 0.0;
         boolean flagZ = vec3d.z - mc.player.getZ() > 0.0;
         if (flagX && flagZ) {
            desyncPositions.add(new BlockPos(mc.player.blockPosition().offset(-1, 0, 0)));
            desyncPositions.add(new BlockPos(mc.player.blockPosition().offset(0, 0, -1)));
         }

         if (!flagX && flagZ) {
            desyncPositions.add(new BlockPos(mc.player.blockPosition().offset(1, 0, 0)));
            desyncPositions.add(new BlockPos(mc.player.blockPosition().offset(0, 0, -1)));
         }

         if (flagX && !flagZ) {
            desyncPositions.add(new BlockPos(mc.player.blockPosition().offset(-1, 0, 0)));
            desyncPositions.add(new BlockPos(mc.player.blockPosition().offset(0, 0, 1)));
         }

         if (!flagX && !flagZ) {
            desyncPositions.add(new BlockPos(mc.player.blockPosition().offset(1, 0, 0)));
            desyncPositions.add(new BlockPos(mc.player.blockPosition().offset(0, 0, 1)));
         }

         positions.removeIf(desyncPositions::contains);
      }

      return positions;
   }

   public static List<BlockPos> getTrapPositions(Player player, boolean partial, boolean head, boolean antiStep, boolean antiBomb, boolean strictDirection) {
      return getTrapPositions(player, partial, head, antiStep, antiBomb, strictDirection, false, false);
   }

   public static List<BlockPos> getTrapPositions(
      Player player, boolean partial, boolean head, boolean antiStep, boolean antiBomb, boolean strictDirection, boolean airPlace
   ) {
      return getTrapPositions(player, null, partial, head, antiStep, antiBomb, strictDirection, false, airPlace);
   }

   public static List<BlockPos> getTrapPositions(
      Player player, BlockPos basePos, boolean partial, boolean head, boolean antiStep, boolean antiBomb, boolean strictDirection, boolean airPlace
   ) {
      return getTrapPositions(player, basePos, partial, head, antiStep, antiBomb, strictDirection, false, airPlace);
   }

   public static List<BlockPos> getTrapPositions(
      Player player, boolean partial, boolean head, boolean antiStep, boolean antiBomb, boolean strictDirection, boolean feet, boolean airPlace
   ) {
      return getTrapPositions(player, null, partial, head, antiStep, antiBomb, strictDirection, feet, airPlace);
   }

   public static List<BlockPos> getTrapPositions(
      Player player,
      BlockPos basePos,
      boolean partial,
      boolean head,
      boolean antiStep,
      boolean antiBomb,
      boolean strictDirection,
      boolean feet,
      boolean airPlace
   ) {
      LinkedHashSet<BlockPos> positions = new LinkedHashSet<>();
      HashSet<BlockPos> occupiedCells;
      if (basePos != null && !player.onGround()) {
         occupiedCells = new HashSet<>();
         occupiedCells.add(basePos);
      } else {
         occupiedCells = getOccupiedFloorCells(player);
      }

      for (BlockPos position : occupiedCells) {
         Direction wallDirection = null;

         for (Direction dir : Direction.values()) {
            if (dir.getAxis().isHorizontal() && !occupiedCells.contains(position.relative(dir))) {
               if (wallDirection == null) {
                  wallDirection = dir;
               }

               if (WorldUtils.getDirection(position.relative(dir).above(), strictDirection) != null) {
                  wallDirection = dir;
                  break;
               }
            }
         }

         if (wallDirection == null) {
            wallDirection = Direction.EAST;
         }

         if (antiStep) {
            addWallOffset(positions, occupiedCells, position, new Vec3i(1, 2, 0));
            addWallOffset(positions, occupiedCells, position, new Vec3i(-1, 2, 0));
            addWallOffset(positions, occupiedCells, position, new Vec3i(0, 2, 1));
            addWallOffset(positions, occupiedCells, position, new Vec3i(0, 2, -1));
         }

         if (antiBomb) {
            positions.add(position.offset(0, 3, 0));
         }

         if (feet) {
            for (Direction dirx : Direction.values()) {
               if (dirx.getAxis().isHorizontal() && !occupiedCells.contains(position.relative(dirx))) {
                  positions.add(position.relative(dirx));
               }
            }
         }

         if (partial) {
            BlockPos headPosition = position.offset(0, 2, 0);
            if (mc.level != null && !mc.level.getBlockState(headPosition).canBeReplaced()) {
               positions.add(headPosition);
            } else if (!airPlace && WorldUtils.getDirection(headPosition, strictDirection) == null) {
               positions.add(position.relative(wallDirection).above());
               positions.add(position.relative(wallDirection).above(2));
               positions.add(headPosition);
            } else {
               positions.add(headPosition);
            }
         } else {
            for (Direction dirxx : Direction.values()) {
               if (dirxx.getAxis().isHorizontal() && !occupiedCells.contains(position.relative(dirxx))) {
                  positions.add(position.relative(dirxx).above());
               }
            }

            if (head) {
               BlockPos headPosition = position.offset(0, 2, 0);
               if (!airPlace && (mc.level == null || mc.level.getBlockState(headPosition).canBeReplaced())) {
                  positions.add(position.relative(wallDirection).above(2));
               }

               positions.add(headPosition);
            }
         }
      }

      return new ArrayList<>(positions);
   }

   private static void addWallOffset(Set<BlockPos> positions, HashSet<BlockPos> occupiedCells, BlockPos base, Vec3i vec3i) {
      if (vec3i.getX() != 0 || vec3i.getZ() != 0) {
         BlockPos floorBelow = base.offset(vec3i.getX(), 0, vec3i.getZ());
         if (occupiedCells.contains(floorBelow)) {
            return;
         }
      }

      positions.add(base.offset(vec3i));
   }

   private static HashSet<BlockPos> getOccupiedFloorCells(Player target) {
      HashSet<BlockPos> cells = new HashSet<>();
      BlockPos feetPos = PositionUtils.getFlooredPosition(target);
      cells.add(feetPos);

      for (Direction dir : Direction.values()) {
         if (!dir.getAxis().isVertical()) {
            AABB box = target.getBoundingBox();
            BlockPos off = feetPos.relative(dir);
            if (box.minX < off.getX() + 1 && box.maxX > off.getX() && box.minZ < off.getZ() + 1 && box.maxZ > off.getZ()) {
               for (int x = (int)Math.floor(box.minX); x < Math.ceil(box.maxX); x++) {
                  for (int z = (int)Math.floor(box.minZ); z < Math.ceil(box.maxZ); z++) {
                     cells.add(new BlockPos(x, feetPos.getY(), z));
                  }
               }
            }
         }
      }

      return cells;
   }

   private static HoleUtils.HoleSafety classifyWalls(BlockPos position, Vec3i[] offsets) {
      boolean allBedrock = true;
      boolean allBlastProof = true;

      for (Vec3i offset : offsets) {
         BlockPos pos = position.offset(offset);
         Block block = mc.level.getBlockState(pos).getBlock();
         boolean bedrock = block.equals(Blocks.BEDROCK);
         boolean otherBlastProof = block.equals(Blocks.OBSIDIAN) || block.equals(Blocks.RESPAWN_ANCHOR) || block.equals(Blocks.ENDER_CHEST);
         if (!bedrock && !otherBlastProof) {
            allBlastProof = false;
            if (!(block instanceof ShulkerBoxBlock) && mc.level.getBlockState(pos).getCollisionShape(mc.level, pos).isEmpty()) {
               return null;
            }
         } else if (!bedrock) {
            allBedrock = false;
         }
      }

      if (!allBlastProof) {
         return HoleUtils.HoleSafety.NONE;
      } else {
         return allBedrock ? HoleUtils.HoleSafety.SAFE : HoleUtils.HoleSafety.UNSAFE;
      }
   }

   public static HoleUtils.Hole getSingleHole(BlockPos position, double height) {
      return getSingleHole(position, height, true);
   }

   public static HoleUtils.Hole getSingleHole(BlockPos position, double height, boolean reachable) {
      if (!mc.level.getBlockState(position).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.above()).getBlock().equals(Blocks.AIR) && reachable) {
         return null;
      } else if (!mc.level.getBlockState(position.above().above()).getBlock().equals(Blocks.AIR) && reachable) {
         return null;
      } else {
         HoleUtils.HoleSafety safety = classifyWalls(position, singleOffsets);
         return safety == null
            ? null
            : new HoleUtils.Hole(
               new AABB(position.getX(), position.getY(), position.getZ(), position.getX() + 1, position.getY() + height, position.getZ() + 1),
               HoleUtils.HoleType.SINGLE,
               safety
            );
      }
   }

   public static HoleUtils.Hole getDoubleHole(BlockPos position, double height) {
      if (!mc.level.getBlockState(position).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.above().above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else {
         boolean x = mc.level.getBlockState(position.offset(new Vec3i(1, 0, 0))).getBlock().equals(Blocks.AIR)
            && mc.level.getBlockState(position.offset(new Vec3i(1, 0, 0)).above()).getBlock().equals(Blocks.AIR)
            && mc.level.getBlockState(position.offset(new Vec3i(1, 0, 0)).above().above()).getBlock().equals(Blocks.AIR);
         boolean z = mc.level.getBlockState(position.offset(new Vec3i(0, 0, 1))).getBlock().equals(Blocks.AIR)
            && mc.level.getBlockState(position.offset(new Vec3i(0, 0, 1)).above()).getBlock().equals(Blocks.AIR)
            && mc.level.getBlockState(position.offset(new Vec3i(0, 0, 1)).above().above()).getBlock().equals(Blocks.AIR);
         if (!x && !z) {
            return null;
         } else {
            AABB box = null;
            HoleUtils.HoleSafety safety = null;
            if (x) {
               HoleUtils.HoleSafety s = classifyWalls(position, doubleXOffsets);
               if (s != null) {
                  box = new AABB(position.getX(), position.getY(), position.getZ(), position.getX() + 2, position.getY() + height, position.getZ() + 1);
                  safety = s;
               }
            }

            if (z && box == null) {
               HoleUtils.HoleSafety s = classifyWalls(position, doubleZOffsets);
               if (s != null) {
                  box = new AABB(position.getX(), position.getY(), position.getZ(), position.getX() + 1, position.getY() + height, position.getZ() + 2);
                  safety = s;
               }
            }

            return box == null ? null : new HoleUtils.Hole(box, HoleUtils.HoleType.DOUBLE, safety);
         }
      }
   }

   public static HoleUtils.Hole getQuadHole(BlockPos position, double height) {
      if (!mc.level.getBlockState(position).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.offset(new Vec3i(1, 0, 0))).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.offset(new Vec3i(0, 0, 1))).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.offset(new Vec3i(1, 0, 1))).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.above().above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.offset(new Vec3i(1, 0, 0)).above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.offset(new Vec3i(1, 0, 0)).above().above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.offset(new Vec3i(0, 0, 1)).above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.offset(new Vec3i(0, 0, 1)).above().above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.offset(new Vec3i(1, 0, 1)).above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.offset(new Vec3i(1, 0, 1)).above().above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else {
         HoleUtils.HoleSafety safety = classifyWalls(position, quadOffsets);
         return safety == null
            ? null
            : new HoleUtils.Hole(
               new AABB(position.getX(), position.getY(), position.getZ(), position.getX() + 2, position.getY() + height, position.getZ() + 2),
               HoleUtils.HoleType.QUAD,
               safety
            );
      }
   }

   public static HoleUtils.Hole getPartialHole(BlockPos position, double height) {
      if (mc.level == null) {
         return null;
      } else if (!mc.level.getBlockState(position).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (!mc.level.getBlockState(position.above().above()).getBlock().equals(Blocks.AIR)) {
         return null;
      } else if (getSingleHole(position, height) != null) {
         return null;
      } else if (getDoubleHole(position, height) != null) {
         return null;
      } else if (getQuadHole(position, height) != null) {
         return null;
      } else if (mc.level.getBlockState(position.below()).canBeReplaced()) {
         return null;
      } else {
         int solidSides = 0;
         BlockPos openSide = null;

         for (Direction dir : Direction.values()) {
            if (dir.getAxis().isHorizontal()) {
               BlockPos neighbor = position.relative(dir);
               if (!mc.level.getBlockState(neighbor).canBeReplaced() && !mc.level.getBlockState(neighbor).getCollisionShape(mc.level, neighbor).isEmpty()) {
                  solidSides++;
               } else {
                  openSide = neighbor;
               }
            }
         }

         if (solidSides != 3) {
            return null;
         } else {
            return openSide != null && !mc.level.getBlockState(openSide.below()).canBeReplaced()
               ? new HoleUtils.Hole(
                  new AABB(position.getX(), position.getY(), position.getZ(), position.getX() + 1, position.getY() + height, position.getZ() + 1),
                  HoleUtils.HoleType.PARTIAL,
                  HoleUtils.HoleSafety.PARTIAL
               )
               : null;
         }
      }
   }

   public record Hole(AABB box, HoleUtils.HoleType type, HoleUtils.HoleSafety safety) {
   }

   public static enum HoleSafety {
      SAFE,
      UNSAFE,
      PARTIAL,
      NONE;
   }

   public static enum HoleType {
      SINGLE,
      DOUBLE,
      QUAD,
      PARTIAL;
   }
}
