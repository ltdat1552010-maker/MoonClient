package night.utils.minecraft;

import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerInputPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectUtil;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.AnvilBlock;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.CrafterBlock;
import net.minecraft.world.level.block.CraftingTableBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.EnderChestBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.SignBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import night.Night;
import night.mixins.accessors.ClientPlayerEntityAccessor;
import night.modules.impl.combat.CrystalPlacementHelper;
import night.modules.impl.core.RotationsModule;
import night.modules.impl.player.SpeedMineModule;
import night.pingbypass.PingBypassFlags;
import night.pingbypass.protocol.PbCustomPayload;
import night.pingbypass.protocol.packets.S2CBlockRenderPacket;
import night.utils.IMinecraft;
import night.utils.miscellaneous.RenderPosition;
import night.utils.rotations.RotationUtils;

public class WorldUtils implements IMinecraft {
   public static Set<Block> RIGHT_CLICKABLE_BLOCKS = Sets.newHashSet(
      new Block[]{
         Blocks.CHEST,
         Blocks.TRAPPED_CHEST,
         Blocks.ENDER_CHEST,
         Blocks.SHULKER_BOX,
         Blocks.BARREL,
         Blocks.RESPAWN_ANCHOR,
         Blocks.CRAFTER,
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.WHITE),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.ORANGE),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.MAGENTA),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.LIGHT_BLUE),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.YELLOW),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.LIME),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.PINK),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.GRAY),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.LIGHT_GRAY),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.CYAN),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.PURPLE),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.BLUE),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.BROWN),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.GREEN),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.RED),
         (Block)Blocks.DYED_SHULKER_BOX.pick(DyeColor.BLACK),
         Blocks.ANVIL,
         Blocks.CHIPPED_ANVIL,
         Blocks.DAMAGED_ANVIL,
         Blocks.BELL,
         Blocks.OAK_BUTTON,
         Blocks.ACACIA_BUTTON,
         Blocks.BIRCH_BUTTON,
         Blocks.DARK_OAK_BUTTON,
         Blocks.JUNGLE_BUTTON,
         Blocks.SPRUCE_BUTTON,
         Blocks.STONE_BUTTON,
         Blocks.COMPARATOR,
         Blocks.REPEATER,
         Blocks.OAK_FENCE_GATE,
         Blocks.SPRUCE_FENCE_GATE,
         Blocks.BIRCH_FENCE_GATE,
         Blocks.JUNGLE_FENCE_GATE,
         Blocks.DARK_OAK_FENCE_GATE,
         Blocks.ACACIA_FENCE_GATE,
         Blocks.BREWING_STAND,
         Blocks.DISPENSER,
         Blocks.DROPPER,
         Blocks.LEVER,
         Blocks.NOTE_BLOCK,
         Blocks.JUKEBOX,
         Blocks.BEACON,
         (Block)Blocks.BED.pick(DyeColor.BLACK),
         (Block)Blocks.BED.pick(DyeColor.BLUE),
         (Block)Blocks.BED.pick(DyeColor.BROWN),
         (Block)Blocks.BED.pick(DyeColor.CYAN),
         (Block)Blocks.BED.pick(DyeColor.GRAY),
         (Block)Blocks.BED.pick(DyeColor.GREEN),
         (Block)Blocks.BED.pick(DyeColor.LIGHT_BLUE),
         (Block)Blocks.BED.pick(DyeColor.LIGHT_GRAY),
         (Block)Blocks.BED.pick(DyeColor.LIME),
         (Block)Blocks.BED.pick(DyeColor.MAGENTA),
         (Block)Blocks.BED.pick(DyeColor.ORANGE),
         (Block)Blocks.BED.pick(DyeColor.PINK),
         (Block)Blocks.BED.pick(DyeColor.PURPLE),
         (Block)Blocks.BED.pick(DyeColor.RED),
         (Block)Blocks.BED.pick(DyeColor.WHITE),
         (Block)Blocks.BED.pick(DyeColor.YELLOW),
         Blocks.FURNACE,
         Blocks.OAK_DOOR,
         Blocks.SPRUCE_DOOR,
         Blocks.BIRCH_DOOR,
         Blocks.JUNGLE_DOOR,
         Blocks.ACACIA_DOOR,
         Blocks.DARK_OAK_DOOR,
         Blocks.CAKE,
         Blocks.ENCHANTING_TABLE,
         Blocks.DRAGON_EGG,
         Blocks.HOPPER,
         Blocks.REPEATING_COMMAND_BLOCK,
         Blocks.COMMAND_BLOCK,
         Blocks.CHAIN_COMMAND_BLOCK,
         Blocks.CRAFTING_TABLE,
         Blocks.ACACIA_TRAPDOOR,
         Blocks.BIRCH_TRAPDOOR,
         Blocks.DARK_OAK_TRAPDOOR,
         Blocks.JUNGLE_TRAPDOOR,
         Blocks.OAK_TRAPDOOR,
         Blocks.SPRUCE_TRAPDOOR,
         Blocks.CAKE,
         Blocks.ACACIA_SIGN,
         Blocks.ACACIA_WALL_SIGN,
         Blocks.BIRCH_SIGN,
         Blocks.BIRCH_WALL_SIGN,
         Blocks.DARK_OAK_SIGN,
         Blocks.DARK_OAK_WALL_SIGN,
         Blocks.JUNGLE_SIGN,
         Blocks.JUNGLE_WALL_SIGN,
         Blocks.OAK_SIGN,
         Blocks.OAK_WALL_SIGN,
         Blocks.SPRUCE_SIGN,
         Blocks.SPRUCE_WALL_SIGN,
         Blocks.CRIMSON_SIGN,
         Blocks.CRIMSON_WALL_SIGN,
         Blocks.WARPED_SIGN,
         Blocks.WARPED_WALL_SIGN,
         Blocks.BLAST_FURNACE,
         Blocks.SMOKER,
         Blocks.CARTOGRAPHY_TABLE,
         Blocks.GRINDSTONE,
         Blocks.LECTERN,
         Blocks.LOOM,
         Blocks.STONECUTTER,
         Blocks.SMITHING_TABLE
      }
   );
   private static final ItemStack NETHERITE_PICKAXE = new ItemStack(Items.NETHERITE_PICKAXE);
   private static final Map<BlockPos, Long> pendingAirPlaces = new ConcurrentHashMap<>();
   private static final Map<BlockPos, WorldUtils.PredictedPlacement> predictedPlacements = new ConcurrentHashMap<>();
   private static final long PREDICTION_TIMEOUT_MS = 1000L;
   public static volatile long lastInteractablePlaceTime = 0L;
   private static final String[] FACING_NAMES = new String[]{"South", "South West", "West", "North West", "North", "North East", "East", "South East"};
   private static final String[] FACING_AXES = new String[]{"+Z", "-X +Z", "-X", "-X -Z", "-Z", "+X -Z", "+X", "+X +Z"};

   public static boolean isInteractable(BlockState state) {
      if (state != null && !state.isAir()) {
         Block block = state.getBlock();
         return RIGHT_CLICKABLE_BLOCKS.contains(block)
            ? true
            : block instanceof BaseEntityBlock
               || block instanceof ShulkerBoxBlock
               || block instanceof ChestBlock
               || block instanceof EnderChestBlock
               || block instanceof AnvilBlock
               || block instanceof CraftingTableBlock
               || block instanceof DoorBlock
               || block instanceof TrapDoorBlock
               || block instanceof FenceGateBlock
               || block instanceof ButtonBlock
               || block instanceof LeverBlock
               || block instanceof AbstractFurnaceBlock
               || block instanceof BedBlock
               || block instanceof SignBlock
               || block instanceof WallSignBlock
               || block instanceof CrafterBlock
               || block instanceof RespawnAnchorBlock
               || block instanceof BarrelBlock;
      } else {
         return false;
      }
   }

   public static boolean placeBlock(BlockPos position, Direction direction, InteractionHand hand, boolean rotate, boolean crystalDestruction) {
      return placeBlock(position, direction, hand, rotate ? "Normal" : "None", crystalDestruction, false);
   }

   public static boolean placeBlock(BlockPos position, Direction direction, InteractionHand hand, boolean rotate, boolean crystalDestruction, boolean render) {
      return placeBlock(position, direction, hand, null, rotate ? "Normal" : "None", crystalDestruction, render);
   }

   public static boolean placeBlock(
      BlockPos position, Direction direction, InteractionHand hand, Runnable runnable, boolean rotate, boolean crystalDestruction, boolean render
   ) {
      return placeBlock(position, direction, hand, runnable, rotate ? "Normal" : "None", crystalDestruction, render);
   }

   public static boolean placeBlock(BlockPos position, Direction direction, InteractionHand hand, String rotateMode, boolean crystalDestruction) {
      return placeBlock(position, direction, hand, rotateMode, crystalDestruction, false);
   }

   public static boolean placeBlock(BlockPos position, Direction direction, InteractionHand hand, String rotateMode, boolean crystalDestruction, boolean render) {
      return placeBlock(position, direction, hand, null, rotateMode, crystalDestruction, render);
   }

   public static void predictPlacement(BlockPos position, Block block) {
      if (position != null && block != null) {
         long now = System.currentTimeMillis();
         if (predictedPlacements.size() > 256) {
            predictedPlacements.entrySet().removeIf(e -> now - e.getValue().time() >= 1000L);
         }

         predictedPlacements.put(position.immutable(), new WorldUtils.PredictedPlacement(block, now));
      }
   }

   public static void clearPredictedPlacement(BlockPos position) {
      if (position != null) {
         predictedPlacements.remove(position);
      }
   }

   public static void clearPredictedPlacements() {
      predictedPlacements.clear();
   }

   public static BlockState getPredictedCollisionState(BlockPos position) {
      if (predictedPlacements.isEmpty()) {
         return null;
      } else {
         WorldUtils.PredictedPlacement pending = predictedPlacements.get(position);
         if (pending == null) {
            return null;
         } else if (System.currentTimeMillis() - pending.time() >= 1000L) {
            predictedPlacements.remove(position);
            return null;
         } else {
            return pending.block().defaultBlockState();
         }
      }
   }

   public static void airPlaceBlock(BlockPos position, InteractionHand hand, String rotateMode, boolean render) {
      if (position != null && mc.player != null && mc.level != null && mc.getConnection() != null) {
         long now = System.currentTimeMillis();
         long cooldownMs = Math.max(50L, Night.SERVER_MANAGER.getPing() * 2L);
         Long lastAttempt = pendingAirPlaces.get(position);
         if (lastAttempt != null) {
            if (now - lastAttempt < cooldownMs) {
               return;
            }

            pendingAirPlaces.remove(position);
         }

         if (pendingAirPlaces.size() > 256) {
            pendingAirPlaces.entrySet().removeIf(e -> now - e.getValue() >= cooldownMs);
         }

         pendingAirPlaces.put(position, now);
         Vec3 hitVec = Vec3.atCenterOf(position).add(0.0, 0.5, 0.0);
         boolean shouldRotate = rotateMode != null && !rotateMode.equalsIgnoreCase("None") && !rotateMode.equalsIgnoreCase("false");
         if (shouldRotate) {
            float[] rotations = RotationUtils.getRotations(hitVec);
            if (Night.ROTATION_MANAGER.isBatchingRotations()) {
               Night.ROTATION_MANAGER.batchRotate(rotations[0], rotations[1]);
            } else {
               Night.ROTATION_MANAGER.silentRotate(rotations[0], rotations[1]);
            }
         }

         if (render) {
            RenderPosition renderPosition = new RenderPosition(position);
            if (!Night.RENDER_MANAGER.renderPositions.contains(renderPosition)) {
               Night.RENDER_MANAGER.renderPositions.add(renderPosition);
            }
         }

         BlockHitResult result = new BlockHitResult(hitVec, Direction.UP, position, false);
         NetworkUtils.sendSequencedPacket(seq -> new ServerboundUseItemOnPacket(hand, result, seq));
         mc.getConnection().send(new ServerboundSwingPacket(hand));
      }
   }

   public static boolean placeBlock(
      BlockPos position, Direction direction, InteractionHand hand, Runnable runnable, String rotateMode, boolean crystalDestruction, boolean render
   ) {
      if (position != null && direction != null) {
         BlockPos offsetPosition = position.relative(direction);
         if (mc.level != null && mc.player != null) {
            boolean isInter = isInteractable(mc.level.getBlockState(offsetPosition)) || isInteractable(mc.level.getBlockState(position));
            if (isInter) {
               lastInteractablePlaceTime = System.currentTimeMillis();
            }

            Vec3 hitVec = Vec3.atCenterOf(offsetPosition).add(-direction.getStepX() * 0.45, -direction.getStepY() * 0.45, -direction.getStepZ() * 0.45);
            Night.WORLD_MANAGER.reservePlacement(position);
            float prevYaw = Night.ROTATION_MANAGER.getServerYaw();
            float prevPitch = Night.ROTATION_MANAGER.getServerPitch();
            float yaw = (float)RotationUtils.getYRotToVec(mc.player, hitVec);
            float pitch = (float)RotationUtils.getXRotToVec(mc.player, hitVec);
            boolean shouldRotate = rotateMode != null && !rotateMode.equalsIgnoreCase("None") && !rotateMode.equalsIgnoreCase("false");
            if (shouldRotate) {
               if (Night.ROTATION_MANAGER.isBatchingRotations()) {
                  Night.ROTATION_MANAGER.batchRotate(yaw, pitch);
               } else {
                  Night.ROTATION_MANAGER.silentRotate(yaw, pitch);
               }
            }

            if (crystalDestruction) {
               Runnable retry = () -> placeBlock(position, direction, hand, runnable, rotateMode, crystalDestruction, render);
               if (destroyCrystals(position, mc.player.getEyePosition(), hitVec, retry, rotateMode)) {
                  return false;
               }
            }

            if (runnable != null) {
               runnable.run();
            }

            boolean sneak = (isInteractable(mc.level.getBlockState(offsetPosition)) || isInteractable(mc.level.getBlockState(position)))
               && !mc.player.isShiftKeyDown();
            if (sneak) {
               Input real = mc.player.input != null ? mc.player.input.keyPresses : new Input(false, false, false, false, false, false, false);
               Input sneakInput = new Input(real.forward(), real.backward(), real.left(), real.right(), real.jump(), true, real.sprint());
               mc.getConnection().send(new ServerboundPlayerInputPacket(sneakInput));
               if (mc.player instanceof ClientPlayerEntityAccessor accessor) {
                  accessor.setLastSentInput(sneakInput);
               }
            }

            BlockHitResult blockHitResult = new BlockHitResult(hitVec, direction.getOpposite(), offsetPosition, false);
            NetworkUtils.sendSequencedPacket(sequence -> new ServerboundUseItemOnPacket(hand, blockHitResult, sequence));
            mc.getConnection().send(new ServerboundSwingPacket(hand));
            if (shouldRotate && !Night.ROTATION_MANAGER.isBatchingRotations() && Night.MODULE_MANAGER.getModule(RotationsModule.class).snapBack.getValue()) {
               Night.ROTATION_MANAGER.packetRotate(prevYaw, prevPitch);
            }

            Night.WORLD_MANAGER.getPlaceTimer().reset();
            if (sneak) {
               Input real = mc.player.input != null ? mc.player.input.keyPresses : new Input(false, false, false, false, false, false, false);
               mc.getConnection().send(new ServerboundPlayerInputPacket(real));
               if (mc.player instanceof ClientPlayerEntityAccessor accessor) {
                  accessor.setLastSentInput(real);
               }
            }

            if (render) {
               RenderPosition renderPosition = new RenderPosition(position);
               if (!Night.RENDER_MANAGER.renderPositions.contains(renderPosition)) {
                  Night.RENDER_MANAGER.renderPositions.add(renderPosition);
                  if (PingBypassFlags.proxyForwardingActive
                     && Night.PINGBYPASS_CONFIG != null
                     && Night.PINGBYPASS_CONFIG.isServer()
                     && Night.PROXY_SERVER != null) {
                     ClientboundCustomPayloadPacket packet = new ClientboundCustomPayloadPacket(PbCustomPayload.fromPacket(new S2CBlockRenderPacket(position)));

                     for (Connection conn : Night.PROXY_SERVER.getConnections()) {
                        if (conn.isConnected()) {
                           conn.send(packet);
                        }
                     }
                  }
               }
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean isPlaceable(BlockPos position) {
      return isPlaceable(position, false);
   }

   public static boolean isPlaceable(BlockPos position, boolean excludeSelf) {
      if (mc.level == null || mc.player == null) {
         return false;
      } else if (mc.level.isOutsideBuildHeight(position)) {
         return false;
      } else if (!mc.level.getBlockState(position).canBeReplaced()) {
         return false;
      } else {
         boolean isFloorBlock = position.getY() < Math.floor(mc.player.getBoundingBox().minY + 0.01);
         boolean playerCenterInside = new AABB(position).contains(mc.player.position().x, mc.player.getBoundingBox().minY + 0.1, mc.player.position().z);
         boolean isFeetLevel = !isFloorBlock && position.getY() == (int)Math.floor(mc.player.getBoundingBox().minY);
         double selfDeflate = isFeetLevel ? 0.05 : 0.25;
         boolean selfCollides = !excludeSelf
            && !isFloorBlock
            && (playerCenterInside || !EntityUtils.isPhased(mc.player) && mc.player.getBoundingBox().deflate(selfDeflate).intersects(new AABB(position)));
         return selfCollides
            ? false
            : mc.level
               .getEntities((Entity)null, new AABB(position), entity -> true)
               .stream()
               .noneMatch(
                  entity -> !(entity instanceof EndCrystal)
                     && !(entity instanceof ExperienceOrb)
                     && !(entity instanceof ItemEntity)
                     && !(entity instanceof AbstractArrow)
                     && (!entity.equals(mc.player) || !excludeSelf && !isFloorBlock && selfCollides)
                     && !EntityUtils.isGhost(entity)
               );
      }
   }

   public static boolean isCrystalPlaceable(BlockPos position) {
      if (mc.level == null) {
         return false;
      } else {
         return !mc.level.getBlockState(position).canBeReplaced()
            ? false
            : mc.level
               .getEntities((Entity)null, new AABB(position), entity -> true)
               .stream()
               .noneMatch(
                  entity -> !(entity instanceof EndCrystal)
                     && !(entity instanceof ExperienceOrb)
                     && !(entity instanceof ItemEntity)
                     && !(entity instanceof AbstractArrow)
                     && !EntityUtils.isGhost(entity)
               );
      }
   }

   public static boolean isInstantBreakable(BlockPos position) {
      if (mc.level == null) {
         return false;
      } else {
         BlockState state = mc.level.getBlockState(position);
         return !state.isAir() && !state.canBeReplaced() ? state.getDestroySpeed(mc.level, position) == 0.0F : false;
      }
   }

   public static void instantBreak(BlockPos position, Direction side) {
      if (mc.level != null && mc.player != null) {
         mc.getConnection().send(new ServerboundPlayerActionPacket(Action.START_DESTROY_BLOCK, position, side != null ? side : Direction.UP));
         mc.getConnection().send(new ServerboundPlayerActionPacket(Action.STOP_DESTROY_BLOCK, position, side != null ? side : Direction.UP));
         mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
      }
   }

   public static Direction getDirection(BlockPos position) {
      return getDirection(position, null, false);
   }

   public static Direction getDirection(BlockPos position, boolean strictDirection) {
      return getDirection(position, null, strictDirection);
   }

   public static BlockPos findSupportBlock(BlockPos targetPos, List<BlockPos> placedPositions, boolean strictDirection, int maxDistance) {
      if (mc.level != null && mc.player != null && targetPos != null) {
         for (int d = 1; d <= maxDistance; d++) {
            for (Direction dir : Direction.values()) {
               BlockPos candidate = targetPos.relative(dir, d);
               if (mc.player.isWithinBlockInteractionRange(candidate, 0.0) && isPlaceable(candidate, false)) {
                  Direction supportDir = getDirection(candidate, placedPositions, strictDirection);
                  if (supportDir != null) {
                     return candidate;
                  }
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static boolean isVisibleBlock(BlockPos hitPos, BlockPos offset, BlockPos position) {
      return hitPos == null ? false : hitPos.equals(offset) || hitPos.equals(position);
   }

   public static List<Direction> getDirections(BlockPos position, List<BlockPos> exceptions, boolean strictDirection) {
      if (mc.level != null && mc.player != null) {
         Vec3 eye = mc.player.getEyePosition();
         List<WorldUtils.DirectionCandidate> candidates = new ArrayList<>();
         new ArrayList();

         for (Direction direction : Direction.values()) {
            BlockPos offset = position.relative(direction);
            BlockState state = mc.level.getBlockState(offset);
            if ((!state.canBeReplaced() || exceptions != null && exceptions.contains(offset))
               && state.getFluidState().isEmpty()
               && mc.player.isWithinBlockInteractionRange(offset, 0.0)) {
               Vec3 hit = Vec3.atCenterOf(position).relative(direction, 0.5);
               if (strictDirection) {
                  if (direction == Direction.DOWN) {
                     if (eye.y < offset.getY() + 1.0) {
                        continue;
                     }
                  } else if (direction == Direction.UP) {
                     if (eye.y > offset.getY()) {
                        continue;
                     }
                  } else {
                     List<Direction> strictDirections = getStrictDirections(eye, Vec3.atCenterOf(offset));
                     if (!strictDirections.contains(direction.getOpposite())) {
                        continue;
                     }
                  }

                  Direction face = direction.getOpposite();
                  int[] faceSteps = new int[]{face.getStepX(), face.getStepY(), face.getStepZ()};
                  double[][] lateralRatios = new double[][]{{0.5, 0.5}, {0.25, 0.5}, {0.75, 0.5}, {0.5, 0.25}, {0.5, 0.75}};
                  boolean faceVisible = false;

                  for (double[] ratio : lateralRatios) {
                     double[] p = new double[]{offset.getX(), offset.getY(), offset.getZ()};
                     int lateral = 0;

                     for (int axis = 0; axis < 3; axis++) {
                        p[axis] += faceSteps[axis] != 0 ? 0.5 + faceSteps[axis] * 0.48 : ratio[lateral++];
                     }

                     HitResult clip = mc.level
                        .clip(new ClipContext(eye, new Vec3(p[0], p[1], p[2]), net.minecraft.world.level.ClipContext.Block.COLLIDER, Fluid.NONE, mc.player));
                     if (clip.getType() == Type.BLOCK
                        && clip instanceof BlockHitResult blockHit
                        && blockHit.getBlockPos().equals(offset)
                        && blockHit.getDirection() == face) {
                        faceVisible = true;
                        break;
                     }
                  }

                  if (!faceVisible) {
                     continue;
                  }
               }

               double distSq = eye.distanceToSqr(hit);
               if (RIGHT_CLICKABLE_BLOCKS.contains(state.getBlock())) {
                  distSq += 20.0;
               }

               if (direction == Direction.DOWN) {
                  distSq -= 50.0;
               }

               candidates.add(new WorldUtils.DirectionCandidate(direction, distSq));
            }
         }

         candidates.sort(Comparator.comparingDouble(c -> c.distSq));
         List<Direction> result = new ArrayList<>();

         for (WorldUtils.DirectionCandidate candidate : candidates) {
            result.add(candidate.direction);
         }

         return result;
      } else {
         return Collections.emptyList();
      }
   }

   public static Direction getDirection(BlockPos position, List<BlockPos> exceptions, boolean strictDirection) {
      List<Direction> dirs = getDirections(position, exceptions, strictDirection);
      return dirs.isEmpty() ? null : dirs.get(0);
   }

   public static boolean destroyCrystals(BlockPos position) {
      return destroyCrystals(position, null, null, null, "None");
   }

   public static boolean destroyCrystals(BlockPos position, Vec3 from, Vec3 to, Runnable retry, String rotateMode) {
      AABB searchArea = from != null && to != null ? new AABB(from, to).inflate(0.5) : new AABB(position);

      List<Entity> surroundingCrystals;
      try {
         surroundingCrystals = mc.level
            .getEntities(
               (Entity)null,
               searchArea,
               entityx -> entityx instanceof EndCrystal
                  && (
                     from == null
                        || to == null
                        || new AABB(position).intersects(entityx.getBoundingBox())
                        || entityx.getBoundingBox().clip(from, to).isPresent()
                  )
            );
      } catch (ConcurrentModificationException var11) {
         return false;
      }

      if (surroundingCrystals.isEmpty()) {
         return false;
      } else {
         boolean shouldRotate = rotateMode != null && !rotateMode.equalsIgnoreCase("None") && !rotateMode.equalsIgnoreCase("false");

         for (Entity entity : surroundingCrystals) {
            if (entity.isAlive() && !entity.isRemoved() && !(mc.player.getEyePosition().distanceToSqr(entity.position()) > 36.0)) {
               if (shouldRotate) {
                  float[] rots = RotationUtils.getRotations(entity.getBoundingBox().getCenter());
                  Night.ROTATION_MANAGER.silentRotate(rots[0], rots[1]);
               }

               mc.player.connection.send(new ServerboundAttackPacket(entity.getId()));
               mc.player.connection.send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               if (retry != null) {
                  Night.WORLD_MANAGER.onCrystalAttacked(entity.getId(), retry);
               }
            }
         }

         return true;
      }
   }

   public static Vec3 getHitVector(BlockPos position, Direction direction) {
      return Vec3.atCenterOf(position).add(direction.getStepX() / 2.0, direction.getStepY() / 2.0, direction.getStepZ() / 2.0);
   }

   public static Direction getClosestDirection(BlockPos position, boolean strictDirection) {
      if (strictDirection) {
         if (mc.player.getY() >= position.getY()) {
            return Direction.UP;
         } else {
            BlockHitResult result = mc.level
               .clip(
                  new ClipContext(
                     mc.player.getEyePosition(), Vec3.atCenterOf(position), net.minecraft.world.level.ClipContext.Block.OUTLINE, Fluid.NONE, mc.player
                  )
               );
            return result != null && result.getType() == Type.BLOCK && result.getDirection() != null ? result.getDirection() : getClosestDirection(position);
         }
      } else {
         return getClosestDirection(position);
      }
   }

   private static Direction getClosestDirection(BlockPos position) {
      Direction closestDirection = null;
      Vec3 offsetPosition = null;

      for (Direction direction : Direction.values()) {
         Vec3 newOffset = getHitVector(position, direction);
         if (closestDirection == null) {
            closestDirection = direction;
            offsetPosition = newOffset;
         } else if (mc.player.distanceToSqr(newOffset) < mc.player.distanceToSqr(offsetPosition)) {
            closestDirection = direction;
            offsetPosition = newOffset;
         }
      }

      return closestDirection;
   }

   public static List<Direction> getStrictDirections(Vec3 eyePos, Vec3 blockPos) {
      List<Direction> directions = new ArrayList<>();
      double differenceX = eyePos.x - blockPos.x;
      double differenceY = eyePos.y - blockPos.y;
      double differenceZ = eyePos.z - blockPos.z;
      if (differenceY > 0.5) {
         directions.add(Direction.UP);
      } else if (differenceY < -0.5) {
         directions.add(Direction.DOWN);
      }

      if (differenceX > 0.5) {
         directions.add(Direction.EAST);
      } else if (differenceX < -0.5) {
         directions.add(Direction.WEST);
      }

      if (differenceZ > 0.5) {
         directions.add(Direction.SOUTH);
      } else if (differenceZ < -0.5) {
         directions.add(Direction.NORTH);
      }

      return directions;
   }

   public static HitResult getRaytraceTarget(float yaw, float pitch, double x, double y, double z) {
      Vec3 rotationVector = new Vec3(
         Mth.sin(-yaw * (float) (Math.PI / 180.0)) * Mth.cos(pitch * (float) (Math.PI / 180.0)),
         -Mth.sin(pitch * (float) (Math.PI / 180.0)),
         Mth.cos(-yaw * (float) (Math.PI / 180.0)) * Mth.cos(pitch * (float) (Math.PI / 180.0))
      );
      HitResult result = mc.level
         .clip(
            new ClipContext(
               new Vec3(x, y, z),
               new Vec3(x + rotationVector.x * 5.0, y + rotationVector.y * 5.0, z + rotationVector.z * 5.0),
               net.minecraft.world.level.ClipContext.Block.OUTLINE,
               Fluid.NONE,
               mc.player
            )
         );
      Vec3 vec3d = new Vec3(x, y + mc.player.getEyeHeight(mc.player.getPose()), z);
      double distance = 25.0;
      if (result != null) {
         distance = result.getLocation().distanceToSqr(vec3d);
      }

      Vec3 multipliedVector = vec3d.add(rotationVector.x * 5.0, rotationVector.y * 5.0, rotationVector.z * 5.0);
      AABB box = new AABB(x - 0.3, y, z - 0.3, x + 0.3, y + 1.8, z + 0.3).expandTowards(rotationVector.scale(5.0)).inflate(1.0, 1.0, 1.0);
      EntityHitResult entityHitResult = ProjectileUtil.getEntityHitResult(
         mc.player, vec3d, multipliedVector, box, entity -> !entity.isSpectator() && entity.isPickable(), distance
      );
      return (HitResult)(entityHitResult != null
            && (vec3d.distanceToSqr(entityHitResult.getLocation()) < distance || result == null)
            && entityHitResult.getEntity() instanceof LivingEntity
         ? entityHitResult
         : result);
   }

   public static boolean canSee(Entity entity) {
      if (entity != null && mc.player != null && mc.level != null) {
         AABB box = entity.getBoundingBox();
         Vec3 eye = new Vec3(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ());
         if (canSee(eye, box.getCenter())) {
            return true;
         } else if (canSee(eye, new Vec3(box.getCenter().x, box.maxY - 0.1, box.getCenter().z))) {
            return true;
         } else if (canSee(eye, new Vec3(box.getCenter().x, box.minY + 0.1, box.getCenter().z))) {
            return true;
         } else {
            double minX = box.minX + 0.1;
            double maxX = box.maxX - 0.1;
            double minY = box.minY + 0.1;
            double maxY = box.maxY - 0.1;
            double minZ = box.minZ + 0.1;
            double maxZ = box.maxZ - 0.1;
            if (canSee(eye, new Vec3(minX, maxY, minZ))) {
               return true;
            } else if (canSee(eye, new Vec3(maxX, maxY, minZ))) {
               return true;
            } else if (canSee(eye, new Vec3(minX, maxY, maxZ))) {
               return true;
            } else if (canSee(eye, new Vec3(maxX, maxY, maxZ))) {
               return true;
            } else if (canSee(eye, new Vec3(minX, minY, minZ))) {
               return true;
            } else if (canSee(eye, new Vec3(maxX, minY, minZ))) {
               return true;
            } else if (canSee(eye, new Vec3(minX, minY, maxZ))) {
               return true;
            } else {
               return canSee(eye, new Vec3(maxX, minY, maxZ)) ? true : canSeeBlock(BlockPos.containing(box.getCenter().x, box.minY - 0.5, box.getCenter().z));
            }
         }
      } else {
         return false;
      }
   }

   public static boolean canSee(Vec3 from, Vec3 to) {
      return mc.level.clip(new ClipContext(from, to, net.minecraft.world.level.ClipContext.Block.COLLIDER, Fluid.NONE, mc.player)).getType() == Type.MISS;
   }

   public static boolean canSee(BlockPos position) {
      return canSee(position.getX() + 0.5, position.getY() + 0.5, position.getZ() + 0.5);
   }

   public static boolean canSee(Vec3 vec3d) {
      return canSee(vec3d.x, vec3d.y, vec3d.z);
   }

   public static boolean canSee(double x, double y, double z) {
      return mc.level
            .clip(
               new ClipContext(
                  new Vec3(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ()),
                  new Vec3(x, y, z),
                  net.minecraft.world.level.ClipContext.Block.COLLIDER,
                  Fluid.NONE,
                  mc.player
               )
            )
            .getType()
         == Type.MISS;
   }

   public static boolean canSeeBlock(BlockPos position) {
      if (mc.player != null && mc.level != null) {
         Vec3 eye = new Vec3(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ());
         HitResult result = mc.level
            .clip(new ClipContext(eye, Vec3.atCenterOf(position), net.minecraft.world.level.ClipContext.Block.COLLIDER, Fluid.NONE, mc.player));
         if (result.getType() != Type.MISS && !(result instanceof BlockHitResult blockHit && blockHit.getBlockPos().equals(position))) {
            Vec3 topCenter = new Vec3(position.getX() + 0.5, position.getY() + 1.0, position.getZ() + 0.5);
            HitResult topResult = mc.level.clip(new ClipContext(eye, topCenter, net.minecraft.world.level.ClipContext.Block.COLLIDER, Fluid.NONE, mc.player));
            return topResult.getType() != Type.MISS && !(topResult instanceof BlockHitResult blockHitx && blockHitx.getBlockPos().equals(position))
               ? CrystalPlacementHelper.isPlacementVisible(position)
               : true;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   public static boolean canBreak(BlockPos... pos) {
      return Arrays.stream(pos).allMatch(blockPos -> mc.level.getBlockState(blockPos).getBlock().defaultDestroyTime() != -1.0F);
   }

   public static boolean isReplaceable(BlockPos... pos) {
      return Arrays.stream(pos).allMatch(blockPos -> mc.level.getBlockState(blockPos).canBeReplaced());
   }

   public static Block getBlock(BlockPos pos) {
      return mc.level.getBlockState(pos).getBlock();
   }

   public static int getNetherPosition(int position) {
      return mc.player.level().dimension() == Level.NETHER ? position * 8 : position / 8;
   }

   public static String getMovementDirection(Direction direction) {
      if (direction.getName().equalsIgnoreCase("North")) {
         return "-Z";
      } else if (direction.getName().equalsIgnoreCase("East")) {
         return "+X";
      } else if (direction.getName().equalsIgnoreCase("South")) {
         return "+Z";
      } else {
         return direction.getName().equalsIgnoreCase("West") ? "-X" : "N/A";
      }
   }

   public static String getFacingName(float yaw) {
      return FACING_NAMES[getFacingOctant(yaw)];
   }

   public static String getFacingAxes(float yaw) {
      return FACING_AXES[getFacingOctant(yaw)];
   }

   private static int getFacingOctant(float yaw) {
      float angle = yaw % 360.0F;
      if (angle < 0.0F) {
         angle += 360.0F;
      }

      return Math.round(angle / 45.0F) % 8;
   }

   public static float getBreakTime(Player player, BlockState blockState) {
      if (player == null) {
         return 0.0F;
      } else {
         float speed = NETHERITE_PICKAXE.getItem().getDestroySpeed(NETHERITE_PICKAXE, blockState) + 26.0F;
         return 1.0F / (speed / blockState.getBlock().defaultDestroyTime() / 30.0F) * 50.0F;
      }
   }

   public static double getBreakDelta(BlockState blockState, int slot) {
      if (slot == -1) {
         return 0.0;
      } else {
         float speed = mc.player.getInventory().getItem(slot).getItem().getDestroySpeed(mc.player.getInventory().getItem(slot), blockState);
         if (speed > 1.0F) {
            ItemStack stack = mc.player.getInventory().getItem(slot);
            int efficiency = EnchantmentHelper.getItemEnchantmentLevel(
               mc.level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.EFFICIENCY), stack
            );
            if (efficiency > 0 && !stack.isEmpty()) {
               speed += efficiency * efficiency + 1;
            }
         }

         if (MobEffectUtil.hasDigSpeed(mc.player)) {
            speed *= 1.0F + (MobEffectUtil.getDigSpeedAmplification(mc.player) + 1) * 0.2F;
         }

         if (mc.player.hasEffect(MobEffects.MINING_FATIGUE)) {
            speed *= switch (mc.player.getEffect(MobEffects.MINING_FATIGUE).getAmplifier()) {
               case 0 -> 0.3F;
               case 1 -> 0.09F;
               case 2 -> 0.0027F;
               default -> 8.1E-4F;
            };
         }

         SpeedMineModule speedMine = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(SpeedMineModule.class) : null;
         boolean ignoreLiquid = speedMine != null && speedMine.isToggled() && speedMine.liquidCheck.getValue();
         boolean ignoreAir = speedMine != null && speedMine.isToggled() && speedMine.airCheck.getValue();
         if (!ignoreLiquid
            && mc.player.isEyeInFluid(FluidTags.WATER)
            && EnchantmentHelper.getEnchantmentLevel(
                  mc.level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.AQUA_AFFINITY), mc.player
               )
               <= 0) {
            speed /= 5.0F;
         }

         if (!ignoreAir && !mc.player.onGround()) {
            speed /= 5.0F;
         }

         return speed
            / blockState.getBlock().defaultDestroyTime()
            / (blockState.requiresCorrectToolForDrops() && !mc.player.getInventory().getItem(slot).isCorrectToolForDrops(blockState) ? 100 : 30);
      }
   }

   public static float getMineSpeed(BlockState state, int slot) {
      if (mc.player == null) {
         return 0.0F;
      } else {
         float speed = mc.player.getInventory().getItem(slot).getItem().getDestroySpeed(mc.player.getInventory().getItem(slot), state);
         if (speed > 1.0F) {
            ItemStack stack = mc.player.getInventory().getItem(slot);
            int efficiency = EnchantmentHelper.getItemEnchantmentLevel(
               mc.level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.EFFICIENCY), stack
            );
            if (efficiency > 0 && !stack.isEmpty()) {
               speed += (float)(StrictMath.pow(efficiency, 2.0) + 1.0);
            }
         }

         if (mc.player.hasEffect(MobEffects.HASTE)) {
            speed *= 1.0F + (mc.player.getEffect(MobEffects.HASTE).getAmplifier() + 1) * 0.2F;
         }

         if (mc.player.hasEffect(MobEffects.MINING_FATIGUE)) {
            speed *= (float)Math.pow(0.3F, mc.player.getEffect(MobEffects.MINING_FATIGUE).getAmplifier() + 1);
         }

         SpeedMineModule speedMine = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(SpeedMineModule.class) : null;
         boolean ignoreLiquid = speedMine != null && speedMine.isToggled() && speedMine.liquidCheck.getValue();
         boolean ignoreAir = speedMine != null && speedMine.isToggled() && speedMine.airCheck.getValue();
         if (!ignoreLiquid && mc.player.isEyeInFluid(FluidTags.WATER)) {
            speed *= (float)mc.player.getAttribute(Attributes.SUBMERGED_MINING_SPEED).getValue();
         }

         if (!ignoreAir && !mc.player.onGround()) {
            speed /= 5.0F;
         }

         speed = speed < 0.0F ? 0.0F : speed;
         return speed
            / state.getBlock().defaultDestroyTime()
            / (state.requiresCorrectToolForDrops() && !mc.player.getInventory().getItem(slot).isCorrectToolForDrops(state) ? 100 : 30);
      }
   }

   public static boolean blocksMovement(BlockState state) {
      return state.getBlock() != Blocks.COBWEB && state.getBlock() != Blocks.BAMBOO_SAPLING && !state.canBeReplaced();
   }

   public static boolean equals(BlockPos x, BlockPos y) {
      if (x == null && y == null) {
         return true;
      } else {
         return x != null && y != null ? x.equals(y) : false;
      }
   }

   public static String getDimension() {
      return mc.player.level().dimension().identifier().toString().replace("minecraft:", "");
   }

   public static List<Player> getCollisions(BlockPos pos) {
      List<Player> collisions = new ArrayList<>();

      for (Player player : mc.level.players()) {
         if (player != null && !player.isRemoved() && !EntityUtils.isGhost(player) && player.getBoundingBox().intersects(new AABB(pos))) {
            collisions.add(player);
         }
      }

      return collisions;
   }

   private record DirectionCandidate(Direction direction, double distSq) {
   }

   private record PredictedPlacement(Block block, long time) {
   }
}
