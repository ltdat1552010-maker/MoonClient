package night.utils.minecraft;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.network.protocol.game.ClientboundContainerSetContentPacket;
import net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket;
import net.minecraft.network.protocol.game.ClientboundOpenScreenPacket;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketReceiveEvent;

public final class EChestMemory {
   private static final EChestMemory INSTANCE = new EChestMemory();
   private static boolean registered = false;
   private static NonNullList<ItemStack> items = null;
   private int trackedContainerId = -1;

   private EChestMemory() {
   }

   public static void init() {
      if (!registered) {
         registered = true;
         Night.EVENT_HANDLER.subscribe(INSTANCE);
      }
   }

   public static boolean hasItems() {
      return items != null;
   }

   public static NonNullList<ItemStack> getItems() {
      return items;
   }

   @SubscribeEvent
   public void onPacket(PacketReceiveEvent event) {
      if (event.getPacket() instanceof ClientboundOpenScreenPacket open) {
         if (this.isLookingAtEnderChest()) {
            this.trackedContainerId = open.getContainerId();
            items = NonNullList.withSize(27, ItemStack.EMPTY);
         } else {
            this.trackedContainerId = -1;
         }
      } else if (this.trackedContainerId != -1) {
         if (!(event.getPacket() instanceof ClientboundContainerSetContentPacket content)) {
            if (event.getPacket() instanceof ClientboundContainerSetSlotPacket slot) {
               if (slot.getContainerId() != this.trackedContainerId) {
                  return;
               }

               int index = slot.getSlot();
               if (items != null && index >= 0 && index < 27) {
                  items.set(index, slot.getItem().copy());
               }
            }
         } else if (content.containerId() == this.trackedContainerId) {
            NonNullList<ItemStack> buffer = NonNullList.withSize(27, ItemStack.EMPTY);

            for (int i = 0; i < 27 && i < content.items().size(); i++) {
               buffer.set(i, ((ItemStack)content.items().get(i)).copy());
            }

            items = buffer;
         }
      }
   }

   private boolean isLookingAtEnderChest() {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level == null) {
         return false;
      } else if (mc.hitResult instanceof BlockHitResult blockHit) {
         BlockPos pos = blockHit.getBlockPos();
         return mc.level.getBlockState(pos).is(Blocks.ENDER_CHEST);
      } else {
         return false;
      }
   }
}
