package night.utils.minecraft;

import java.lang.reflect.Method;
import java.util.function.Consumer;
import net.minecraft.client.multiplayer.prediction.BlockStatePredictionHandler;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerGamePacketListener;
import night.mixins.accessors.ClientWorldAccessor;
import night.utils.IMinecraft;

public class NetworkUtils implements IMinecraft {
   private static Object vfpImpl;
   private static Method vfpTargetVersion;
   private static Method protocolVersionGetVersion;

   public static void sendIgnoredPacket(Packet<?> packet) {
      mc.getConnection().getConnection().send(packet, null, true);
   }

   public static void sendSequencedPacket(NetworkUtils.SequencedPacketCreator packetCreator) {
      sendSequencedPacket(packetCreator, packet -> mc.getConnection().send(packet));
   }

   public static void sendSequencedPacket(NetworkUtils.SequencedPacketCreator packetCreator, Consumer<Packet<ServerGamePacketListener>> sender) {
      BlockStatePredictionHandler prediction = ((ClientWorldAccessor)mc.level).invokeGetPendingUpdateManager().startPredicting();

      try {
         Packet<ServerGamePacketListener> packet = packetCreator.predict(prediction.currentSequence());
         sender.accept(packet);
      } catch (Throwable var6) {
         if (prediction != null) {
            try {
               prediction.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }
         }

         throw var6;
      }

      if (prediction != null) {
         prediction.close();
      }
   }

   public static boolean isLegacyProtocol() {
      try {
         if (vfpImpl == null) {
            vfpImpl = Class.forName("com.viaversion.viafabricplus.ViaFabricPlus").getMethod("getImpl").invoke(null);
            vfpTargetVersion = Class.forName("com.viaversion.viafabricplus.api.ViaFabricPlusBase").getMethod("getTargetVersion");
            protocolVersionGetVersion = Class.forName("com.viaversion.viaversion.api.protocol.version.ProtocolVersion").getMethod("getVersion");
         }

         Object targetVersion = vfpTargetVersion.invoke(vfpImpl);
         return targetVersion != null && (Integer)protocolVersionGetVersion.invoke(targetVersion) < 768;
      } catch (Throwable var1) {
         return false;
      }
   }

   public interface SequencedPacketCreator {
      Packet<ServerGamePacketListener> predict(int var1);
   }
}
