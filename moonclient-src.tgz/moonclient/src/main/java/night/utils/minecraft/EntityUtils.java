package night.utils.minecraft;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.bee.Bee;
import net.minecraft.world.entity.animal.golem.IronGolem;
import net.minecraft.world.entity.animal.panda.Panda;
import net.minecraft.world.entity.animal.polarbear.PolarBear;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Endermite;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinArmPose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEnderpearl;
import net.minecraft.world.item.EggItem;
import net.minecraft.world.item.EnderpearlItem;
import net.minecraft.world.item.ExperienceBottleItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.LingeringPotionItem;
import net.minecraft.world.item.SnowballItem;
import net.minecraft.world.item.SplashPotionItem;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import night.Night;
import night.modules.impl.miscellaneous.FakePlayerModule;
import night.modules.impl.visuals.LogoutSpotModule;
import night.modules.impl.visuals.PopChamsModule;
import night.utils.IMinecraft;

public class EntityUtils implements IMinecraft {
   public static Map<MobEffect, Color> POTION_COLORS = new HashMap<>();
   private static final Identifier ATTACKING_SPEED_MODIFIER = Identifier.withDefaultNamespace("attacking");

   public static boolean isPhased(Entity entity) {
      if (entity != null && mc.level != null) {
         AABB box = entity.getBoundingBox();
         int minX = Mth.floor(box.minX);
         int maxX = Mth.ceil(box.maxX);
         int minY = Mth.floor(box.minY);
         int maxY = Mth.ceil(box.maxY);
         int minZ = Mth.floor(box.minZ);
         int maxZ = Mth.ceil(box.maxZ);

         for (int x = minX; x < maxX; x++) {
            for (int y = minY; y < maxY; y++) {
               for (int z = minZ; z < maxZ; z++) {
                  BlockPos pos = new BlockPos(x, y, z);
                  VoxelShape shape = mc.level.getBlockState(pos).getCollisionShape(mc.level, pos);
                  if (!shape.isEmpty() && shape.bounds().move(pos).intersects(box)) {
                     return true;
                  }
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static List<BlockPos> getPhasedBlocks(Entity entity) {
      List<BlockPos> list = new ArrayList<>();
      if (entity != null && mc.level != null) {
         AABB box = entity.getBoundingBox();
         int minX = Mth.floor(box.minX);
         int maxX = Mth.ceil(box.maxX);
         int minY = Mth.floor(box.minY);
         int maxY = Mth.ceil(box.maxY);
         int minZ = Mth.floor(box.minZ);
         int maxZ = Mth.ceil(box.maxZ);

         for (int x = minX; x < maxX; x++) {
            for (int y = minY; y < maxY; y++) {
               for (int z = minZ; z < maxZ; z++) {
                  BlockPos pos = new BlockPos(x, y, z);
                  VoxelShape shape = mc.level.getBlockState(pos).getCollisionShape(mc.level, pos);
                  if (!shape.isEmpty() && shape.bounds().move(pos).intersects(box)) {
                     list.add(pos);
                  }
               }
            }
         }

         return list;
      } else {
         return list;
      }
   }

   public static boolean isEating() {
      if (mc.player == null) {
         return false;
      } else if (mc.player.isUsingItem()) {
         return true;
      } else {
         if (mc.options.keyUse.isDown()) {
            ItemStack main = mc.player.getMainHandItem();
            ItemStack off = mc.player.getOffhandItem();
            if (!main.isEmpty() && main.getUseDuration(mc.player) > 0) {
               return true;
            }

            if (!off.isEmpty() && off.getUseDuration(mc.player) > 0) {
               return true;
            }
         }

         return false;
      }
   }

   public static boolean isBot(Player player) {
      if (Night.MODULE_MANAGER.getModule(FakePlayerModule.class).isToggled() && player == Night.MODULE_MANAGER.getModule(FakePlayerModule.class).getPlayer()) {
         return false;
      } else {
         PlayerInfo entry = mc.getConnection().getPlayerInfo(player.getUUID());
         return entry == null
            || entry.getProfile() == null
            || player.getUUID().toString().startsWith(player.getName().getString())
            || !player.getGameProfile().name().equals(player.getName().getString());
      }
   }

   public static boolean isNaked(Player player) {
      if (player == null) {
         return false;
      } else {
         for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = player.getItemBySlot(slot);
            if (!stack.isEmpty() && (slot != EquipmentSlot.CHEST || stack.getItem() != Items.ELYTRA)) {
               return false;
            }
         }

         return true;
      }
   }

   public static boolean isGhost(Entity entity) {
      if (entity != null && Night.MODULE_MANAGER != null) {
         PopChamsModule popChams = Night.MODULE_MANAGER.getModule(PopChamsModule.class);
         if (popChams != null && popChams.isGhost(entity)) {
            return true;
         } else {
            LogoutSpotModule logoutSpot = Night.MODULE_MANAGER.getModule(LogoutSpotModule.class);
            return logoutSpot != null && logoutSpot.isGhost(entity);
         }
      } else {
         return false;
      }
   }

   public static int getLatency(Player player) {
      PlayerInfo playerListEntry = mc.getConnection().getPlayerInfo(player.getUUID());
      return playerListEntry == null ? 0 : playerListEntry.getLatency();
   }

   public static GameType getGameMode(Player player) {
      PlayerInfo playerListEntry = mc.getConnection().getPlayerInfo(player.getUUID());
      return playerListEntry == null ? GameType.CREATIVE : playerListEntry.getGameMode();
   }

   public static String getGameModeName(GameType gameMode) {
      return switch (gameMode) {
         case CREATIVE -> "C";
         case ADVENTURE -> "A";
         case SPECTATOR -> "SP";
         default -> "S";
      };
   }

   public static double getSpeed(Entity entity, EntityUtils.SpeedUnit unit) {
      double speed = Math.sqrt(Mth.square(Math.abs(entity.getX() - entity.xo)) + Mth.square(Math.abs(entity.getZ() - entity.zo)));
      return unit == EntityUtils.SpeedUnit.KILOMETERS
         ? speed * 3.6 * Night.WORLD_MANAGER.getTimerMultiplier() * 20.0
         : speed / 0.05 * Night.WORLD_MANAGER.getTimerMultiplier();
   }

   public static boolean hasNegativeEffects(Player player) {
      for (MobEffectInstance statusEffectInstance : new ArrayList(player.getActiveEffects())) {
         if (!((MobEffect)statusEffectInstance.getEffect().value()).isBeneficial()) {
            return true;
         }
      }

      return false;
   }

   public static Vec3 getRenderPos(Entity entity, float tickDelta) {
      double x = Mth.lerp(tickDelta, entity.xo, entity.getX());
      double y = Mth.lerp(tickDelta, entity.yo, entity.getY());
      double z = Mth.lerp(tickDelta, entity.zo, entity.getZ());
      return new Vec3(x, y, z);
   }

   public static LivingEntity getClosestEntity(Entity entity) {
      LivingEntity closestEntity = null;

      for (Entity e : mc.level.entitiesForRendering()) {
         if (e instanceof LivingEntity livingEntity
            && entity.distanceTo(livingEntity) <= 10.0F
            && !(livingEntity.getHealth() <= 0.0F)
            && livingEntity.isAlive()
            && entity != livingEntity) {
            if (closestEntity == null) {
               closestEntity = livingEntity;
            } else if (entity.distanceTo(livingEntity) < entity.distanceTo(closestEntity)) {
               closestEntity = livingEntity;
            }
         }
      }

      return closestEntity;
   }

   public static Direction getPearlDirection(ThrownEnderpearl pearl) {
      Direction direction = pearl.getDirection();
      if (direction.equals(Direction.WEST)) {
         return Direction.EAST;
      } else {
         return direction.equals(Direction.EAST) ? Direction.WEST : direction;
      }
   }

   public static boolean isThrowable(Item item) {
      return item instanceof EnderpearlItem
         || item instanceof TridentItem
         || item instanceof ExperienceBottleItem
         || item instanceof SnowballItem
         || item instanceof EggItem
         || item instanceof SplashPotionItem
         || item instanceof LingeringPotionItem;
   }

   public static boolean isInWeb(Entity entity) {
      for (float x : new float[]{0.0F, 0.3F, -0.3F}) {
         for (float z : new float[]{0.0F, 0.3F, -0.3F}) {
            for (int y : new int[]{-1, 0, 1, 2}) {
               BlockPos pos = BlockPos.containing(entity.getX() + x, entity.getY(), entity.getZ() + z).above(y);
               if (new AABB(pos).intersects(entity.getBoundingBox()) && mc.level.getBlockState(pos).getBlock() == Blocks.COBWEB) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   public static boolean isNeutral(Entity entity) {
      if (entity == null) {
         return false;
      } else if (entity.getType() == EntityTypes.PIGLIN || entity.getType() == EntityTypes.PIGLIN_BRUTE) {
         return false;
      } else if (entity instanceof NeutralMob) {
         return true;
      } else {
         Object type = entity.getType();
         return type == EntityTypes.ZOMBIFIED_PIGLIN
            || type == EntityTypes.ENDERMAN
            || type == EntityTypes.IRON_GOLEM
            || type == EntityTypes.WOLF
            || type == EntityTypes.POLAR_BEAR
            || type == EntityTypes.BEE
            || type == EntityTypes.DOLPHIN
            || type == EntityTypes.GOAT
            || type == EntityTypes.PANDA
            || type == EntityTypes.LLAMA
            || type == EntityTypes.TRADER_LLAMA;
      }
   }

   public static boolean isAngry(Entity entity) {
      if (entity instanceof Mob mob) {
         if (mob.isAggressive()) {
            return true;
         } else {
            AttributeInstance speedAttr = mob.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speedAttr != null && speedAttr.hasModifier(ATTACKING_SPEED_MODIFIER)) {
               return true;
            } else if (entity instanceof NeutralMob neutral && neutral.isAngry()) {
               return true;
            } else if (entity instanceof EnderMan enderman && (enderman.isCreepy() || enderman.hasBeenStaredAt())) {
               return true;
            } else if (entity instanceof PolarBear polarBear && polarBear.isStanding()) {
               return true;
            } else if (entity instanceof IronGolem golem && golem.getAttackAnimationTick() > 0) {
               return true;
            } else if (entity instanceof Bee bee && (bee.hasStung() || bee.isAngry())) {
               return true;
            } else if (entity instanceof Panda panda && panda.isAggressive()) {
               return true;
            } else {
               if (entity instanceof Piglin piglin) {
                  PiglinArmPose pose = piglin.getArmPose();
                  if (pose == PiglinArmPose.ATTACKING_WITH_MELEE_WEAPON || pose == PiglinArmPose.CROSSBOW_HOLD || pose == PiglinArmPose.CROSSBOW_CHARGE) {
                     return true;
                  }
               }

               if (mc.player != null) {
                  DamageSource playerDmg = mc.player.getLastDamageSource();
                  if (playerDmg != null && playerDmg.getEntity() == entity) {
                     return true;
                  }

                  DamageSource entityDmg = mob.getLastDamageSource();
                  if (entityDmg != null && entityDmg.getEntity() == mc.player) {
                     return true;
                  }
               }

               return mob.getTarget() != null ? true : entity instanceof NeutralMob neutral && neutral.getPersistentAngerTarget() != null;
            }
         }
      } else {
         return false;
      }
   }

   public static boolean isHostile(Entity entity) {
      if (entity == null) {
         return false;
      } else if (isAngry(entity)) {
         return true;
      } else if (isNeutral(entity)) {
         return false;
      } else if (!(entity instanceof Enemy) && !(entity instanceof Monster) && !(entity instanceof Endermite)) {
         return entity.getType() != EntityTypes.ENDERMITE && entity.getType() != EntityTypes.SILVERFISH
            ? entity.getType().getCategory() == MobCategory.MONSTER
            : true;
      } else {
         return true;
      }
   }

   public static boolean isAnimal(Entity entity) {
      if (entity == null || isNeutral(entity) || isHostile(entity)) {
         return false;
      } else if (entity instanceof Animal) {
         return true;
      } else {
         MobCategory cat = entity.getType().getCategory();
         return cat == MobCategory.CREATURE
            || cat == MobCategory.WATER_CREATURE
            || cat == MobCategory.WATER_AMBIENT
            || cat == MobCategory.UNDERGROUND_WATER_CREATURE
            || cat == MobCategory.AXOLOTLS
            || cat == MobCategory.AMBIENT;
      }
   }

   public static boolean isPassive(Entity entity) {
      return isAnimal(entity);
   }

   static {
      POTION_COLORS.put((MobEffect)MobEffects.SPEED.value(), new Color(124, 175, 198));
      POTION_COLORS.put((MobEffect)MobEffects.SLOWNESS.value(), new Color(90, 108, 129));
      POTION_COLORS.put((MobEffect)MobEffects.HASTE.value(), new Color(217, 192, 67));
      POTION_COLORS.put((MobEffect)MobEffects.MINING_FATIGUE.value(), new Color(74, 66, 23));
      POTION_COLORS.put((MobEffect)MobEffects.STRENGTH.value(), new Color(147, 36, 35));
      POTION_COLORS.put((MobEffect)MobEffects.INSTANT_HEALTH.value(), new Color(67, 10, 9));
      POTION_COLORS.put((MobEffect)MobEffects.INSTANT_DAMAGE.value(), new Color(67, 10, 9));
      POTION_COLORS.put((MobEffect)MobEffects.JUMP_BOOST.value(), new Color(34, 255, 76));
      POTION_COLORS.put((MobEffect)MobEffects.NAUSEA.value(), new Color(85, 29, 74));
      POTION_COLORS.put((MobEffect)MobEffects.REGENERATION.value(), new Color(205, 92, 171));
      POTION_COLORS.put((MobEffect)MobEffects.RESISTANCE.value(), new Color(153, 69, 58));
      POTION_COLORS.put((MobEffect)MobEffects.FIRE_RESISTANCE.value(), new Color(228, 154, 58));
      POTION_COLORS.put((MobEffect)MobEffects.WATER_BREATHING.value(), new Color(46, 82, 153));
      POTION_COLORS.put((MobEffect)MobEffects.INVISIBILITY.value(), new Color(127, 131, 146));
      POTION_COLORS.put((MobEffect)MobEffects.BLINDNESS.value(), new Color(31, 31, 35));
      POTION_COLORS.put((MobEffect)MobEffects.NIGHT_VISION.value(), new Color(31, 31, 161));
      POTION_COLORS.put((MobEffect)MobEffects.HUNGER.value(), new Color(88, 118, 83));
      POTION_COLORS.put((MobEffect)MobEffects.WEAKNESS.value(), new Color(72, 77, 72));
      POTION_COLORS.put((MobEffect)MobEffects.POISON.value(), new Color(78, 147, 49));
      POTION_COLORS.put((MobEffect)MobEffects.WITHER.value(), new Color(53, 42, 39));
      POTION_COLORS.put((MobEffect)MobEffects.HEALTH_BOOST.value(), new Color(248, 125, 35));
      POTION_COLORS.put((MobEffect)MobEffects.ABSORPTION.value(), new Color(37, 82, 165));
      POTION_COLORS.put((MobEffect)MobEffects.SATURATION.value(), new Color(248, 36, 35));
      POTION_COLORS.put((MobEffect)MobEffects.GLOWING.value(), new Color(148, 160, 97));
      POTION_COLORS.put((MobEffect)MobEffects.LEVITATION.value(), new Color(206, 255, 255));
      POTION_COLORS.put((MobEffect)MobEffects.LUCK.value(), new Color(51, 153, 0));
      POTION_COLORS.put((MobEffect)MobEffects.UNLUCK.value(), new Color(192, 164, 77));
   }

   public static enum SpeedUnit {
      METERS,
      KILOMETERS;
   }
}
