package night.utils.minecraft;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.inventory.ShulkerBoxScreen;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import night.Night;
import night.mixins.accessors.ClientPlayerInteractionManagerAccessor;
import night.pingbypass.PingBypassFlags;
import night.pingbypass.protocol.PbCustomPayload;
import night.pingbypass.protocol.packets.S2CSlotSyncPacket;
import night.pingbypass.protocol.packets.S2CWindowClickPacket;
import night.utils.IMinecraft;

public class InventoryUtils implements IMinecraft {
   public static String[] SWITCH_MODES = new String[]{"None", "Normal", "Silent", "AltPickup", "AltSwap"};
   public static String[] SWAP_MODES = new String[]{"Pickup", "Swap"};
   public static int HOTBAR_START = 0;
   public static int HOTBAR_END = 8;
   public static int INVENTORY_START = 9;
   public static int INVENTORY_END = 35;
   private static final ArrayDeque<InventoryUtils.Frame> STACK = new ArrayDeque<>();
   private static final Set<Integer> LONG_HOLD = ConcurrentHashMap.newKeySet();
   private static final ThreadLocal<Boolean> PROGRAMMATIC_SWITCH = ThreadLocal.withInitial(() -> false);
   private static final long STALE_FRAME_MS = 30000L;

   public static void markLongHold(int slot) {
      LONG_HOLD.add(slot);
   }

   public static void clearLongHold(int slot) {
      LONG_HOLD.remove(slot);
   }

   public static boolean hasActiveSilentSwitch() {
      synchronized (STACK) {
         for (InventoryUtils.Frame f : STACK) {
            if (!LONG_HOLD.contains(f.key())) {
               return true;
            }
         }

         return false;
      }
   }

   public static boolean isProgrammaticSwitching() {
      return PROGRAMMATIC_SWITCH.get();
   }

   private static int restingSlot() {
      return mc.player == null ? Night.POSITION_MANAGER.getServerSlot() : mc.player.getInventory().getSelectedSlot();
   }

   public static void tickPendingRestore() {
      if (mc.player == null) {
         synchronized (STACK) {
            STACK.clear();
         }

         LONG_HOLD.clear();
      } else {
         boolean using = mc.options.keyUse.isDown() || mc.player.isUsingItem();
         if (using || mc.options.keyAttack.isDown()) {
            flushPendingRestores();
         }

         if (using) {
            send(mc.player.getInventory().getSelectedSlot());
         }

         synchronized (STACK) {
            if (STACK.removeIf(f -> !LONG_HOLD.contains(f.key()) && System.currentTimeMillis() - f.time() >= 30000L)) {
               settle();
            }

            if (!using) {
               settle();
            }
         }
      }
   }

   public static void flushPendingRestores() {
      synchronized (STACK) {
         settle();
      }
   }

   public static void releaseAllBorrows() {
      synchronized (STACK) {
         STACK.removeIf(f -> !LONG_HOLD.contains(f.key()));
         settle();
      }
   }

   private static void settle() {
      InventoryUtils.Frame top = STACK.peek();
      send(top != null ? top.held() : restingSlot());
   }

   private static void send(int target) {
      if (target >= 0 && mc.getConnection() != null) {
         if (target != Night.POSITION_MANAGER.getServerSlot()) {
            boolean was = PROGRAMMATIC_SWITCH.get();
            PROGRAMMATIC_SWITCH.set(true);

            try {
               mc.getConnection().send(new ServerboundSetCarriedItemPacket(target));
            } finally {
               PROGRAMMATIC_SWITCH.set(was);
            }
         }
      }
   }

   private static void push(int key, int held) {
      synchronized (STACK) {
         STACK.push(new InventoryUtils.Frame(key, held, System.currentTimeMillis()));
         send(held);
      }
   }

   private static void release(int key) {
      synchronized (STACK) {
         boolean found = false;
         Iterator<InventoryUtils.Frame> it = STACK.iterator();

         while (it.hasNext()) {
            if (it.next().key() == key) {
               it.remove();
               found = true;
               break;
            }
         }

         if (found) {
            InventoryUtils.Frame top = STACK.peek();
            if (top != null) {
               send(top.held());
            } else {
               settle();
            }
         }
      }
   }

   public static boolean switchSlot(String mode, int slot, int previousSlot) {
      if (mode.equalsIgnoreCase("None")) {
         return true;
      } else if (slot != -1 && previousSlot != -1) {
         PROGRAMMATIC_SWITCH.set(true);

         try {
            if (!mc.isSameThread() && !mode.equalsIgnoreCase("Silent")) {
               if (slot > HOTBAR_END) {
                  return false;
               }

               mode = "Silent";
            }

            switch (mode) {
               case "Normal":
                  mc.player.getInventory().setSelectedSlot(slot);
                  ((ClientPlayerInteractionManagerAccessor)mc.gameMode).invokeSyncSelectedSlot();
                  syncSlotToClientIfProxy(slot);
                  break;
               case "Silent":
                  push(slot, slot);
                  break;
               case "AltPickup":
               case "AltSwap":
                  if (slot <= HOTBAR_END) {
                     push(slot, slot);
                  } else {
                     swap(mode.equals("AltPickup") ? "Pickup" : "Swap", slot, previousSlot);
                     push(slot, previousSlot);
                  }
            }

            return true;
         } finally {
            PROGRAMMATIC_SWITCH.set(false);
         }
      } else {
         return false;
      }
   }

   public static void switchBackNormal(int previousSlot) {
      if (previousSlot != -1 && previousSlot != Night.POSITION_MANAGER.getServerSlot()) {
         PROGRAMMATIC_SWITCH.set(true);

         try {
            mc.player.getInventory().setSelectedSlot(previousSlot);
            ((ClientPlayerInteractionManagerAccessor)mc.gameMode).invokeSyncSelectedSlot();
            syncSlotToClientIfProxy(previousSlot);
         } finally {
            PROGRAMMATIC_SWITCH.set(false);
         }
      }
   }

   private static void syncSlotToClientIfProxy(int slot) {
      if (Night.PINGBYPASS_CONFIG != null && Night.PINGBYPASS_CONFIG.isServer()) {
         if (PingBypassFlags.proxyForwardingActive && Night.PROXY_SERVER != null) {
            ClientboundCustomPayloadPacket packet = new ClientboundCustomPayloadPacket(PbCustomPayload.fromPacket(new S2CSlotSyncPacket(slot)));

            for (Connection conn : Night.PROXY_SERVER.getConnections()) {
               if (conn.isConnected()) {
                  conn.send(packet);
               }
            }
         }
      }
   }

   public static void switchBack(String mode, int slot, int previousSlot) {
      if (!mode.equalsIgnoreCase("None")) {
         if (previousSlot != -1) {
            PROGRAMMATIC_SWITCH.set(true);

            try {
               if ((mode.equals("AltPickup") || mode.equals("AltSwap")) && slot > HOTBAR_END && mc.isSameThread()) {
                  swap(mode.equals("AltPickup") ? "Pickup" : "Swap", slot, previousSlot);
               }

               release(slot);
            } finally {
               PROGRAMMATIC_SWITCH.set(false);
            }
         }
      }
   }

   public static void swapEquipment(int invIndex, int equipmentSlot) {
      if (invIndex >= 0 && invIndex <= 8) {
         click(equipmentSlot, invIndex, ContainerInput.SWAP);
      } else {
         click(indexToSlot(invIndex), 0, ContainerInput.PICKUP);
         click(equipmentSlot, 0, ContainerInput.PICKUP);
         click(indexToSlot(invIndex), 0, ContainerInput.PICKUP);
      }
   }

   public static void swap(String mode, int slot, int targetSlot) {
      switch (mode) {
         case "Pickup":
            click(indexToSlot(slot), 0, ContainerInput.PICKUP);
            click(indexToSlot(targetSlot), 0, ContainerInput.PICKUP);
            click(indexToSlot(slot), 0, ContainerInput.PICKUP);
            break;
         case "Swap":
            click(indexToSlot(slot), targetSlot, ContainerInput.SWAP);
      }
   }

   public static void click(int slotNum, int buttonNum, ContainerInput containerInput) {
      mc.gameMode.handleContainerInput(mc.player.containerMenu.containerId, slotNum, buttonNum, containerInput, mc.player);
      broadcastClickToClientIfProxy(slotNum, buttonNum, containerInput);
   }

   private static void broadcastClickToClientIfProxy(int slotNum, int buttonNum, ContainerInput containerInput) {
      if (Night.PINGBYPASS_CONFIG != null && Night.PINGBYPASS_CONFIG.isServer()) {
         if (PingBypassFlags.proxyForwardingActive && Night.PROXY_SERVER != null) {
            ClientboundCustomPayloadPacket packet = new ClientboundCustomPayloadPacket(
               PbCustomPayload.fromPacket(new S2CWindowClickPacket(mc.player.containerMenu.containerId, slotNum, buttonNum, containerInput))
            );

            for (Connection conn : Night.PROXY_SERVER.getConnections()) {
               if (conn.isConnected()) {
                  conn.send(packet);
               }
            }
         }
      }
   }

   public static int indexToSlot(int index) {
      AbstractContainerMenu menu = mc.player != null ? mc.player.containerMenu : null;
      if (menu != null && mc.player.inventoryMenu != menu && index >= 0 && index <= 35) {
         int playerInvBase = menu.slots.size() - 36;
         if (playerInvBase >= 0) {
            return index <= 8 ? playerInvBase + 27 + index : playerInvBase + (index - 9);
         }
      }

      return index >= 0 && index <= 8 ? 36 + index : index;
   }

   public static int find(Item item) {
      return find(item, HOTBAR_START, INVENTORY_END);
   }

   public static int findHotbar(Item item) {
      return find(item, HOTBAR_START, HOTBAR_END);
   }

   public static int findInventory(Item item) {
      return find(item, INVENTORY_START, INVENTORY_END);
   }

   public static int find(Item item, int start, int end) {
      for (int i = end; i >= start; i--) {
         ItemStack stack = mc.player.getInventory().getItem(i);
         if (stack.getItem() == item) {
            return i;
         }
      }

      return -1;
   }

   public static int find(Class<? extends Item> item) {
      return find(item, HOTBAR_START, INVENTORY_END);
   }

   public static int findHotbar(Class<? extends Item> item) {
      return find(item, HOTBAR_START, HOTBAR_END);
   }

   public static int findInventory(Class<? extends Item> item) {
      return find(item, INVENTORY_START, INVENTORY_END);
   }

   public static int find(Class<? extends Item> item, int start, int end) {
      for (int i = end; i >= start; i--) {
         ItemStack stack = mc.player.getInventory().getItem(i);
         if (stack.getItem().getClass().isAssignableFrom(item)) {
            return i;
         }
      }

      return -1;
   }

   public static int findInventory(Item item, int count) {
      for (int i = INVENTORY_END; i >= INVENTORY_START; i--) {
         ItemStack stack = mc.player.getInventory().getItem(i);
         if (stack.getItem() == item && mc.player.getInventory().getItem(i).getCount() >= count) {
            return i;
         }
      }

      return -1;
   }

   public static int findHardestBlock(int start, int end) {
      float bestHardness = -1.0F;
      int bestSlot = -1;

      for (int i = start; i <= end; i++) {
         if (mc.player.getInventory().getItem(i).getItem() instanceof BlockItem item) {
            float hardness = item.getBlock().defaultDestroyTime();
            if (hardness == -1.0F) {
               return i;
            }

            if (hardness > bestHardness) {
               bestHardness = hardness;
               bestSlot = i;
            }
         }
      }

      return bestSlot;
   }

   public static int findFastestItem(BlockState blockState, int start, int end) {
      double bestScore = -1.0;
      int bestSlot = -1;

      for (int i = start; i <= end; i++) {
         double score = mc.player.getInventory().getItem(i).getItem().getDestroySpeed(mc.player.getInventory().getItem(i), blockState);
         if (score > bestScore) {
            bestScore = score;
            bestSlot = i;
         }
      }

      return bestSlot;
   }

   public static int findBestSword(int start, int end) {
      int netheriteSlot = -1;
      int diamondSlot = -1;
      int ironSlot = -1;
      int goldenSlot = -1;
      int stoneSlot = -1;
      int woodenSlot = -1;

      for (int i = end; i >= start; i--) {
         ItemStack stack = mc.player.getInventory().getItem(i);
         if (stack.getItem() == Items.NETHERITE_SWORD) {
            netheriteSlot = i;
         }

         if (stack.getItem() == Items.DIAMOND_SWORD) {
            diamondSlot = i;
         }

         if (stack.getItem() == Items.IRON_SWORD) {
            ironSlot = i;
         }

         if (stack.getItem() == Items.GOLDEN_SWORD) {
            goldenSlot = i;
         }

         if (stack.getItem() == Items.STONE_SWORD) {
            stoneSlot = i;
         }

         if (stack.getItem() == Items.WOODEN_SWORD) {
            woodenSlot = i;
         }
      }

      if (netheriteSlot != -1) {
         return netheriteSlot;
      } else if (diamondSlot != -1) {
         return diamondSlot;
      } else if (ironSlot != -1) {
         return ironSlot;
      } else if (goldenSlot != -1) {
         return goldenSlot;
      } else {
         return stoneSlot != -1 ? stoneSlot : woodenSlot;
      }
   }

   public static int findEmptySlot(int start, int end) {
      for (int i = end; i >= start; i--) {
         ItemStack stack = mc.player.getInventory().getItem(i);
         if (stack.isEmpty()) {
            return i;
         }
      }

      return -1;
   }

   public static boolean inInventoryScreen() {
      return mc.gui.screen() instanceof InventoryScreen
         || mc.gui.screen() instanceof CreativeModeInventoryScreen
         || mc.gui.screen() instanceof ContainerScreen
         || mc.gui.screen() instanceof ShulkerBoxScreen;
   }

   private record Frame(int key, int held, long time) {
   }
}
