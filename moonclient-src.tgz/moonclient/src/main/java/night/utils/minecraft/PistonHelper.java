package night.utils.minecraft;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import night.Night;
import night.utils.IMinecraft;
import night.utils.rotations.RotationUtils;

public class PistonHelper implements IMinecraft {
   public static final CopyOnWriteArrayList<BlockPos> placeList = new CopyOnWriteArrayList<>();

   public static boolean isGrimDirection(BlockPos pos, Direction direction) {
      if (mc.player != null && mc.level != null) {
         AABB combined = getCombinedBox(pos);
         AABB eyeBox = new AABB(mc.player.getX(), mc.player.getY() + 0.4, mc.player.getZ(), mc.player.getX(), mc.player.getY() + 1.62, mc.player.getZ())
            .inflate(2.0E-4);
         if (isIntersected(eyeBox, combined)) {
            return true;
         } else {
            return switch (direction) {
               case NORTH -> eyeBox.minZ <= combined.minZ;
               case SOUTH -> eyeBox.maxZ >= combined.maxZ;
               case EAST -> eyeBox.maxX >= combined.maxX;
               case WEST -> eyeBox.minX <= combined.minX;
               case UP -> eyeBox.maxY >= combined.maxY;
               case DOWN -> eyeBox.minY <= combined.minY;
               default -> throw new MatchException(null, null);
            };
         }
      } else {
         return false;
      }
   }

   public static Direction getClickSideStrict(BlockPos pos) {
      if (mc.player == null) {
         return null;
      } else {
         Direction best = null;
         double minDist = Double.MAX_VALUE;

         for (Direction dir : Direction.values()) {
            if (isGrimDirection(pos, dir)) {
               double dist = mc.player.getEyePosition().distanceToSqr(Vec3.atCenterOf(pos.relative(dir)));
               if (dist < minDist) {
                  minDist = dist;
                  best = dir;
               }
            }
         }

         return best;
      }
   }

   public static Direction getClickSide(BlockPos pos) {
      if (mc.player == null) {
         return null;
      } else {
         double minDist = Double.MAX_VALUE;
         Direction best = null;

         for (Direction dir : Direction.values()) {
            if (canSee(pos, dir)) {
               double dist = mc.player.getEyePosition().distanceToSqr(Vec3.atCenterOf(pos.relative(dir)));
               if (dist < minDist) {
                  minDist = dist;
                  best = dir;
               }
            }
         }

         if (best != null) {
            return best;
         } else {
            minDist = Double.MAX_VALUE;
            best = Direction.UP;

            for (Direction dirx : Direction.values()) {
               if (isGrimDirection(pos, dirx)) {
                  double dist = mc.player.getEyePosition().distanceToSqr(Vec3.atCenterOf(pos.relative(dirx)));
                  if (dist < minDist) {
                     minDist = dist;
                     best = dirx;
                  }
               }
            }

            return best;
         }
      }
   }

   public static Direction getPlaceSide(BlockPos pos, Predicate<Direction> filter) {
      return getPlaceSide(pos, filter, false);
   }

   public static Direction getPlaceSide(BlockPos pos, Predicate<Direction> filter, boolean ignoreSneak) {
      if (pos != null && mc.player != null && mc.level != null) {
         double bestDist = Double.MAX_VALUE;
         Direction best = null;

         for (Direction dir : Direction.values()) {
            if (filter == null || filter.test(dir)) {
               BlockPos neighbor = pos.relative(dir);
               BlockState neighborState = mc.level.getBlockState(neighbor);
               if (canClick(neighbor, ignoreSneak) && !neighborState.canBeReplaced() && isGrimDirection(neighbor, dir.getOpposite())) {
                  Vec3 clickPoint = Vec3.atCenterOf(pos).add(dir.getStepX() * 0.5, dir.getStepY() * 0.5, dir.getStepZ() * 0.5);
                  double dist = mc.player.getEyePosition().distanceToSqr(clickPoint);
                  if (dist < bestDist) {
                     bestDist = dist;
                     best = dir;
                  }
               }
            }
         }

         if (best != null) {
            return best;
         } else {
            for (Direction dirx : Direction.values()) {
               if (filter == null || filter.test(dirx)) {
                  BlockPos neighbor = pos.relative(dirx);
                  BlockState neighborState = mc.level.getBlockState(neighbor);
                  if (canClick(neighbor, ignoreSneak) && !neighborState.canBeReplaced()) {
                     Vec3 clickPoint = Vec3.atCenterOf(pos).add(dirx.getStepX() * 0.5, dirx.getStepY() * 0.5, dirx.getStepZ() * 0.5);
                     double dist = mc.player.getEyePosition().distanceToSqr(clickPoint);
                     if (dist < bestDist) {
                        bestDist = dist;
                        best = dirx;
                     }
                  }
               }
            }

            return best;
         }
      } else {
         return null;
      }
   }

   public static List<Direction> getPlaceSides(BlockPos pos, Predicate<Direction> filter) {
      return getPlaceSides(pos, filter, false);
   }

   public static List<Direction> getPlaceSides(BlockPos pos, Predicate<Direction> filter, boolean ignoreSneak) {
      List<Direction> sides = new ArrayList<>();
      if (pos != null && mc.level != null) {
         for (Direction dir : Direction.values()) {
            if (filter == null || filter.test(dir)) {
               BlockPos neighbor = pos.relative(dir);
               BlockState neighborState = mc.level.getBlockState(neighbor);
               if (canClick(neighbor, ignoreSneak) && !neighborState.canBeReplaced() && isGrimDirection(neighbor, dir.getOpposite())) {
                  sides.add(dir);
               }
            }
         }

         return sides;
      } else {
         return sides;
      }
   }

   public static boolean canClick(BlockPos pos) {
      return canClick(pos, false);
   }

   public static boolean canClick(BlockPos pos, boolean ignoreSneak) {
      if (mc.level != null && mc.player != null) {
         BlockState state = mc.level.getBlockState(pos);
         boolean needsShift = WorldUtils.isInteractable(state);
         return state.isSolid() && (!needsShift || mc.player.isShiftKeyDown() || ignoreSneak);
      } else {
         return false;
      }
   }

   public static boolean canReplace(BlockPos pos) {
      return mc.level != null && pos != null && pos.getY() < 320 && pos.getY() >= -64 ? mc.level.getBlockState(pos).canBeReplaced() : false;
   }

   public static boolean canPlace(BlockPos pos) {
      return canPlace(pos, null, false, false);
   }

   public static boolean canPlace(BlockPos pos, Predicate<Direction> filter) {
      return canPlace(pos, filter, false, false);
   }

   public static boolean canPlace(BlockPos pos, Predicate<Direction> filter, boolean airPlace) {
      return canPlace(pos, filter, airPlace, false);
   }

   public static boolean canPlace(BlockPos pos, Predicate<Direction> filter, boolean airPlace, boolean ignoreCrystal) {
      if (!canReplace(pos)) {
         return false;
      } else if (hasEntity(pos, ignoreCrystal)) {
         return false;
      } else {
         return airPlace ? true : getPlaceSide(pos, filter) != null;
      }
   }

   public static boolean canPlaceCrystal(BlockPos pos) {
      return canPlaceCrystal(pos, false);
   }

   public static boolean canPlaceCrystal(BlockPos pos, boolean airPlace) {
      if (mc.level == null) {
         return false;
      } else if (!mc.level.getBlockState(pos).isAir()) {
         return false;
      } else {
         BlockPos abovePos = pos.above();
         if (!mc.level.getBlockState(abovePos).isAir()) {
            return false;
         } else if (!hasEntityBlockCrystal(pos, false) && !hasEntityBlockCrystal(abovePos, false)) {
            BlockPos basePos = pos.below();
            Block base = mc.level.getBlockState(basePos).getBlock();
            if (base != Blocks.OBSIDIAN && base != Blocks.BEDROCK) {
               return false;
            } else {
               return airPlace ? true : getClickSide(basePos) != null;
            }
         } else {
            return false;
         }
      }
   }

   public static boolean canPlaceCrystalIgnoreHeadroom(BlockPos pos, boolean airPlace) {
      if (mc.level == null) {
         return false;
      } else if (!mc.level.getBlockState(pos).isAir()) {
         return false;
      } else if (hasEntityBlockCrystal(pos, false)) {
         return false;
      } else {
         BlockPos basePos = pos.below();
         Block base = mc.level.getBlockState(basePos).getBlock();
         if (base != Blocks.OBSIDIAN && base != Blocks.BEDROCK) {
            return false;
         } else {
            return airPlace ? true : getClickSide(basePos) != null;
         }
      }
   }

   public static boolean hasEntity(BlockPos pos, boolean ignoreCrystal) {
      if (mc.level == null) {
         return false;
      } else {
         AABB box = new AABB(pos).deflate(0.01);

         for (Entity entity : mc.level.getEntitiesOfClass(Entity.class, box)) {
            if (entity.isAlive()
               && !(entity instanceof ItemEntity)
               && !(entity instanceof ExperienceOrb)
               && !(entity instanceof Projectile)
               && (!ignoreCrystal || !(entity instanceof EndCrystal))) {
               return true;
            }
         }

         return false;
      }
   }

   public static boolean hasEntityBlockCrystal(BlockPos pos, boolean ignoreCrystal) {
      if (mc.level == null) {
         return false;
      } else {
         AABB box = new AABB(pos);

         for (Entity entity : mc.level.getEntitiesOfClass(Entity.class, box)) {
            if (entity.isAlive() && (!ignoreCrystal || !(entity instanceof EndCrystal))) {
               return true;
            }
         }

         return false;
      }
   }

   public static boolean hasCrystal(BlockPos pos) {
      if (mc.level == null) {
         return false;
      } else {
         AABB box = new AABB(pos);

         for (EndCrystal crystal : mc.level.getEntitiesOfClass(EndCrystal.class, box)) {
            if (crystal.isAlive()) {
               return true;
            }
         }

         return false;
      }
   }

   public static boolean hasCrystalAt(BlockPos pos) {
      if (mc.level == null) {
         return false;
      } else {
         AABB box = new AABB(pos);

         for (EndCrystal crystal : mc.level.getEntitiesOfClass(EndCrystal.class, box)) {
            if (crystal.isAlive() && crystal.blockPosition().equals(pos)) {
               return true;
            }
         }

         return false;
      }
   }

   public static void placeBlockDirect(BlockPos pos, Direction side) {
      if (mc.player != null && mc.getConnection() != null) {
         BlockPos neighbor = pos.relative(side);
         Vec3 hitVec = new Vec3(
            neighbor.getX() + 0.5 + side.getOpposite().getStepX() * 0.5,
            neighbor.getY() + 0.5 + side.getOpposite().getStepY() * 0.5,
            neighbor.getZ() + 0.5 + side.getOpposite().getStepZ() * 0.5
         );
         BlockHitResult result = new BlockHitResult(hitVec, side.getOpposite(), neighbor, false);
         NetworkUtils.sendSequencedPacket(seq -> new ServerboundUseItemOnPacket(InteractionHand.MAIN_HAND, result, seq));
         mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
         placeList.add(pos);
      }
   }

   public static void clickBlock(BlockPos pos, Direction face, boolean rotate) {
      if (mc.player != null && mc.getConnection() != null) {
         Vec3 hitVec = new Vec3(pos.getX() + 0.5 + face.getStepX() * 0.5, pos.getY() + 0.5 + face.getStepY() * 0.5, pos.getZ() + 0.5 + face.getStepZ() * 0.5);
         if (rotate) {
            float[] rots = RotationUtils.getRotations(hitVec);
            Night.ROTATION_MANAGER.silentRotate(rots[0], rots[1]);
         }

         BlockHitResult result = new BlockHitResult(hitVec, face, pos, false);
         NetworkUtils.sendSequencedPacket(seq -> new ServerboundUseItemOnPacket(InteractionHand.MAIN_HAND, result, seq));
         mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
         placeList.add(pos);
      }
   }

   public static void placeBlock(BlockPos pos, Direction side, boolean rotate) {
      clickBlock(pos.relative(side), side.getOpposite(), rotate);
   }

   public static boolean canSee(BlockPos pos, Direction side) {
      if (mc.level != null && mc.player != null) {
         Vec3 target = Vec3.atCenterOf(pos).add(side.getStepX() * 0.5, side.getStepY() * 0.5, side.getStepZ() * 0.5);
         BlockHitResult result = mc.level
            .clip(new ClipContext(mc.player.getEyePosition(), target, net.minecraft.world.level.ClipContext.Block.COLLIDER, Fluid.NONE, mc.player));
         return result == null || result.getType() == Type.MISS;
      } else {
         return false;
      }
   }

   public static Vec3 getClosestPointToBox(Vec3 pos, AABB box) {
      return new Vec3(Mth.clamp(pos.x, box.minX, box.maxX), Mth.clamp(pos.y, box.minY, box.maxY), Mth.clamp(pos.z, box.minZ, box.maxZ));
   }

   private static AABB getCombinedBox(BlockPos pos) {
      if (mc.level == null) {
         return new AABB(pos);
      } else {
         AABB combined = new AABB(pos);

         for (AABB box : mc.level.getBlockState(pos).getCollisionShape(mc.level, pos).toAabbs()) {
            AABB offsetBox = box.move(pos.getX(), pos.getY(), pos.getZ());
            double minX = Math.max(offsetBox.minX, combined.minX);
            double minY = Math.max(offsetBox.minY, combined.minY);
            double minZ = Math.max(offsetBox.minZ, combined.minZ);
            double maxX = Math.min(offsetBox.maxX, combined.maxX);
            double maxY = Math.min(offsetBox.maxY, combined.maxY);
            double maxZ = Math.min(offsetBox.maxZ, combined.maxZ);
            combined = new AABB(minX, minY, minZ, maxX, maxY, maxZ);
         }

         return combined;
      }
   }

   private static boolean isIntersected(AABB a, AABB b) {
      return b.maxX - 1.0E-7 > a.minX
         && b.minX + 1.0E-7 < a.maxX
         && b.maxY - 1.0E-7 > a.minY
         && b.minY + 1.0E-7 < a.maxY
         && b.maxZ - 1.0E-7 > a.minZ
         && b.minZ + 1.0E-7 < a.maxZ;
   }
}
