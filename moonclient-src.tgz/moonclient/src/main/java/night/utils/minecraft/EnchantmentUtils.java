package night.utils.minecraft;

import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

public class EnchantmentUtils {
   public static int getEnchantmentLevel(ItemStack stack, ResourceKey<Enchantment> enchantmentKey) {
      if (stack != null && !stack.isEmpty()) {
         ItemEnchantments enchantments = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
         if (enchantments != null && !enchantments.isEmpty()) {
            for (Entry<Holder<Enchantment>> entry : enchantments.entrySet()) {
               Optional<ResourceKey<Enchantment>> keyOptional = ((Holder)entry.getKey()).unwrapKey();
               if (keyOptional.isPresent() && keyOptional.get().equals(enchantmentKey)) {
                  return entry.getIntValue();
               }
            }

            return 0;
         } else {
            return 0;
         }
      } else {
         return 0;
      }
   }
}
