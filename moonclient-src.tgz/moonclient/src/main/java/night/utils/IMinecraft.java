package night.utils;

import net.minecraft.client.Minecraft;

public interface IMinecraft {
   Minecraft mc = Minecraft.getInstance();
}
