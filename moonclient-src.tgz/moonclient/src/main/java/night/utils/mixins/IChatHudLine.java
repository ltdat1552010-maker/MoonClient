package night.utils.mixins;

public interface IChatHudLine {
   boolean night$isClientMessage();

   void night$setClientMessage(boolean var1);

   String night$getClientIdentifier();

   void night$setClientIdentifier(String var1);
}
