package night.utils.mixins;

public final class HandsRenderState {
   public static boolean renderingHands = false;

   private HandsRenderState() {
   }
}
