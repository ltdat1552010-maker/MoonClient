package night.utils.graphics;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import java.awt.Color;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.gui.GuiRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.mixins.accessors.GuiGraphicsExtractorAccessor;
import night.utils.IMinecraft;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

public class Renderer2D implements IMinecraft {
   public static final Matrix4f LAST_PROJECTION_MATRIX = new Matrix4f();
   public static final Matrix4f LAST_MODEL_MATRIX = new Matrix4f();
   public static final Matrix4f LAST_WORLD_MATRIX = new Matrix4f();
   private static final Map<Identifier, RenderType> TEXTURE_TYPES = new HashMap<>();
   private static MethodHandle SCISSOR_GET;
   private static MethodHandle SCISSOR_PEEK;
   private static boolean scissorHandleInitialized = false;

   public static void renderQuad(GuiGraphicsExtractor context, float left, float top, float right, float bottom, Color color) {
      int c = color.getRGB();
      submit(context, new float[]{left, left, right, right}, new float[]{top, bottom, bottom, top}, new int[]{c, c, c, c});
   }

   public static void renderGradient(GuiGraphicsExtractor context, float left, float top, float right, float bottom, Color startColor, Color endColor) {
      int s = startColor.getRGB();
      int e = endColor.getRGB();
      submit(context, new float[]{left, left, right, right}, new float[]{top, bottom, bottom, top}, new int[]{s, e, e, s});
   }

   public static void renderSidewaysGradient(GuiGraphicsExtractor context, float left, float top, float right, float bottom, Color startColor, Color endColor) {
      int s = startColor.getRGB();
      int e = endColor.getRGB();
      submit(context, new float[]{left, left, right, right}, new float[]{top, bottom, bottom, top}, new int[]{s, s, e, e});
   }

   public static void renderCheckerboard(GuiGraphicsExtractor context, float left, float top, float right, float bottom, float tileSize, Color c1, Color c2) {
      int color1 = c1.getRGB();
      int color2 = c2.getRGB();
      int cols = (int)Math.ceil((right - left) / tileSize);
      int rows = (int)Math.ceil((bottom - top) / tileSize);
      int quadCount = cols * rows;
      if (quadCount > 0) {
         float[] xs = new float[quadCount * 4];
         float[] ys = new float[quadCount * 4];
         int[] colorArr = new int[quadCount * 4];
         int qi = 0;

         for (int r = 0; r < rows; r++) {
            float y0 = top + r * tileSize;
            float y1 = Math.min(top + (r + 1) * tileSize, bottom);

            for (int c = 0; c < cols; c++) {
               float x0 = left + c * tileSize;
               float x1 = Math.min(left + (c + 1) * tileSize, right);
               int clr = (r + c) % 2 == 0 ? color1 : color2;
               quad(xs, ys, colorArr, qi++, x0, y0, x1, y1, clr);
            }
         }

         submit(context, xs, ys, colorArr);
      }
   }

   public static void renderOutline(GuiGraphicsExtractor context, float left, float top, float right, float bottom, Color color) {
      int c = color.getRGB();
      float[] xs = new float[16];
      float[] ys = new float[16];
      int[] cols = new int[16];
      quad(xs, ys, cols, 0, left, top, left + 0.5F, bottom, c);
      quad(xs, ys, cols, 1, right - 0.5F, top, right, bottom, c);
      quad(xs, ys, cols, 2, left, bottom - 0.5F, right, bottom, c);
      quad(xs, ys, cols, 3, left, top, right, top + 0.5F, c);
      submit(context, xs, ys, cols);
   }

   public static ScreenRectangle peekScissor(GuiGraphicsExtractor context) {
      if (!scissorHandleInitialized) {
         scissorHandleInitialized = true;

         try {
            Field f = GuiGraphicsExtractor.class.getDeclaredField("scissorStack");
            f.setAccessible(true);
            SCISSOR_GET = MethodHandles.lookup().unreflectGetter(f);
            Method m = f.getType().getDeclaredMethod("peek");
            m.setAccessible(true);
            SCISSOR_PEEK = MethodHandles.lookup().unreflect(m);
         } catch (Throwable var4) {
            Night.LOGGER.debug("Could not bind scissorStack handle: {}", var4.getMessage());
         }
      }

      if (SCISSOR_GET != null && SCISSOR_PEEK != null) {
         try {
            Object stack = (Object)SCISSOR_GET.invoke((GuiGraphicsExtractor)context);
            if (stack != null) {
               return (ScreenRectangle)SCISSOR_PEEK.invoke((Object)stack);
            }
         } catch (Throwable var3) {
         }
      }

      return null;
   }

   private static void submit(GuiGraphicsExtractor context, float[] xs, float[] ys, int[] cols) {
      GuiRenderState renderState = ((GuiGraphicsExtractorAccessor)context).night$getGuiRenderState();
      renderState.addGuiElement(new GuiQuadRenderState(new Matrix3x2f(context.pose()), xs, ys, cols, peekScissor(context)));
   }

   private static void quad(float[] xs, float[] ys, int[] cols, int qi, float x0, float y0, float x1, float y1, int c) {
      int b = qi * 4;
      xs[b] = x0;
      ys[b] = y0;
      xs[b + 1] = x0;
      ys[b + 1] = y1;
      xs[b + 2] = x1;
      ys[b + 2] = y1;
      xs[b + 3] = x1;
      ys[b + 3] = y0;
      cols[b] = cols[b + 1] = cols[b + 2] = cols[b + 3] = c;
   }

   public static void renderImmediateQuad(PoseStack matrices, float left, float top, float right, float bottom, Color color) {
      Matrix4f matrix = matrices.last().pose();
      int c = color.getRGB();
      ByteBufferBuilder byteBufferBuilder = ByteBufferBuilder.exactlySized(4 * DefaultVertexFormat.POSITION_COLOR.getVertexSize());

      try {
         BufferBuilder buffer = new BufferBuilder(byteBufferBuilder, PrimitiveTopology.QUADS, DefaultVertexFormat.POSITION_COLOR);
         buffer.addVertex(matrix, left, top, 0.0F).setColor(c);
         buffer.addVertex(matrix, left, bottom, 0.0F).setColor(c);
         buffer.addVertex(matrix, right, bottom, 0.0F).setColor(c);
         buffer.addVertex(matrix, right, top, 0.0F).setColor(c);
         MeshData mesh = buffer.build();
         Renderer3D.draw(RenderTypes.debugQuads(), mesh);
      } catch (Throwable var12) {
         if (byteBufferBuilder != null) {
            try {
               byteBufferBuilder.close();
            } catch (Throwable var11) {
               var12.addSuppressed(var11);
            }
         }

         throw var12;
      }

      if (byteBufferBuilder != null) {
         byteBufferBuilder.close();
      }
   }

   public static void renderCircle(PoseStack matrices, float x, float y, float radius, Color color) {
      Matrix4f matrix = matrices.last().pose();
      int c = color.getRGB();
      ByteBufferBuilder byteBufferBuilder = ByteBufferBuilder.exactlySized(361 * DefaultVertexFormat.POSITION_COLOR.getVertexSize());

      try {
         BufferBuilder buffer = new BufferBuilder(byteBufferBuilder, PrimitiveTopology.TRIANGLE_FAN, DefaultVertexFormat.POSITION_COLOR);

         for (int i = 0; i <= 360; i++) {
            buffer.addVertex(matrix, (float)(x + Math.sin(i * Math.PI / 180.0) * radius), (float)(y + Math.cos(i * Math.PI / 180.0) * radius), 0.0F)
               .setColor(c);
         }

         MeshData mesh = buffer.build();
         Renderer3D.draw(RenderTypes.debugTriangleFan(), mesh);
      } catch (Throwable var11) {
         if (byteBufferBuilder != null) {
            try {
               byteBufferBuilder.close();
            } catch (Throwable var10) {
               var11.addSuppressed(var10);
            }
         }

         throw var11;
      }

      if (byteBufferBuilder != null) {
         byteBufferBuilder.close();
      }
   }

   public static void renderTexture(PoseStack matrices, float left, float top, float right, float bottom, Identifier identifier, Color color) {
      Matrix4f matrix = matrices.last().pose();
      int c = color.getRGB();
      ByteBufferBuilder byteBufferBuilder = ByteBufferBuilder.exactlySized(4 * DefaultVertexFormat.POSITION_TEX_COLOR.getVertexSize());

      try {
         BufferBuilder buffer = new BufferBuilder(byteBufferBuilder, PrimitiveTopology.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
         buffer.addVertex(matrix, left, top, 0.0F).setUv(0.0F, 0.0F).setColor(c);
         buffer.addVertex(matrix, left, bottom, 0.0F).setUv(0.0F, 1.0F).setColor(c);
         buffer.addVertex(matrix, right, bottom, 0.0F).setUv(1.0F, 1.0F).setColor(c);
         buffer.addVertex(matrix, right, top, 0.0F).setUv(1.0F, 0.0F).setColor(c);
         MeshData mesh = buffer.build();
         Renderer3D.draw(texturedType(identifier), mesh);
      } catch (Throwable var13) {
         if (byteBufferBuilder != null) {
            try {
               byteBufferBuilder.close();
            } catch (Throwable var12) {
               var13.addSuppressed(var12);
            }
         }

         throw var13;
      }

      if (byteBufferBuilder != null) {
         byteBufferBuilder.close();
      }
   }

   public static void renderArrow(GuiGraphicsExtractor context, float x, float y, float width, float height, Color color) {
      int c = color.getRGB();
      float notchY = y + height * 0.75F;
      float[] xs = new float[]{x, x - width, x, x, x, x, x + width, x};
      float[] ys = new float[]{y, y + height, notchY, y, y, notchY, y + height, y};
      int[] cols = new int[]{c, c, c, c, c, c, c, c};
      submit(context, xs, ys, cols);
   }

   public static void renderArrowOutline(GuiGraphicsExtractor context, float x, float y, float width, float height, Color color) {
      int c = color.getRGB();
      float notchY = y + height * 0.75F;
      float[] xs = new float[16];
      float[] ys = new float[16];
      int[] cols = new int[16];
      quadLine(xs, ys, cols, 0, x, y, x - width, y + height, 0.5F, c);
      quadLine(xs, ys, cols, 1, x - width, y + height, x, notchY, 0.5F, c);
      quadLine(xs, ys, cols, 2, x, notchY, x + width, y + height, 0.5F, c);
      quadLine(xs, ys, cols, 3, x + width, y + height, x, y, 0.5F, c);
      submit(context, xs, ys, cols);
   }

   private static void quadLine(float[] xs, float[] ys, int[] cols, int qi, float x1, float y1, float x2, float y2, float halfWidth, int c) {
      float dx = x2 - x1;
      float dy = y2 - y1;
      float len = (float)Math.sqrt(dx * dx + dy * dy);
      if (!(len < 1.0E-4F)) {
         float nx = -dy / len * halfWidth;
         float ny = dx / len * halfWidth;
         int b = qi * 4;
         xs[b] = x1 + nx;
         ys[b] = y1 + ny;
         xs[b + 1] = x1 - nx;
         ys[b + 1] = y1 - ny;
         xs[b + 2] = x2 - nx;
         ys[b + 2] = y2 - ny;
         xs[b + 3] = x2 + nx;
         ys[b + 3] = y2 + ny;
         cols[b] = cols[b + 1] = cols[b + 2] = cols[b + 3] = c;
      }
   }

   public static void renderArrow(PoseStack matrices, float x, float y, float width, float height, Color color) {
      Matrix4f matrix = matrices.last().pose();
      int c = color.getRGB();
      ByteBufferBuilder byteBufferBuilder = ByteBufferBuilder.exactlySized(5 * DefaultVertexFormat.POSITION_COLOR.getVertexSize());

      try {
         BufferBuilder buffer = new BufferBuilder(byteBufferBuilder, PrimitiveTopology.TRIANGLE_FAN, DefaultVertexFormat.POSITION_COLOR);
         buffer.addVertex(matrix, x, y, 0.0F).setColor(c);
         buffer.addVertex(matrix, x - width, y + height, 0.0F).setColor(c);
         buffer.addVertex(matrix, x, y + height, 0.0F).setColor(c);
         buffer.addVertex(matrix, x + width, y + height, 0.0F).setColor(c);
         buffer.addVertex(matrix, x, y, 0.0F).setColor(c);
         MeshData mesh = buffer.build();
         Renderer3D.draw(RenderTypes.debugTriangleFan(), mesh);
      } catch (Throwable var12) {
         if (byteBufferBuilder != null) {
            try {
               byteBufferBuilder.close();
            } catch (Throwable var11) {
               var12.addSuppressed(var11);
            }
         }

         throw var12;
      }

      if (byteBufferBuilder != null) {
         byteBufferBuilder.close();
      }
   }

   public static void renderArrowOutline(PoseStack matrices, float x, float y, float width, float height, Color color) {
      Matrix4f matrix = matrices.last().pose();
      int c = color.getRGB();
      float[] px = new float[]{x, x - width, x, x + width, x};
      float[] py = new float[]{y, y + height, y + height, y + height, y};
      ByteBufferBuilder byteBufferBuilder = ByteBufferBuilder.exactlySized((px.length - 1) * 4 * DefaultVertexFormat.POSITION_COLOR.getVertexSize());

      try {
         BufferBuilder buffer = new BufferBuilder(byteBufferBuilder, PrimitiveTopology.QUADS, DefaultVertexFormat.POSITION_COLOR);

         for (int i = 0; i < px.length - 1; i++) {
            segment(buffer, matrix, px[i], py[i], px[i + 1], py[i + 1], 0.5F, c);
         }

         MeshData mesh = buffer.build();
         Renderer3D.draw(RenderTypes.debugQuads(), mesh);
      } catch (Throwable var14) {
         if (byteBufferBuilder != null) {
            try {
               byteBufferBuilder.close();
            } catch (Throwable var13) {
               var14.addSuppressed(var13);
            }
         }

         throw var14;
      }

      if (byteBufferBuilder != null) {
         byteBufferBuilder.close();
      }
   }

   private static void segment(BufferBuilder buffer, Matrix4f matrix, float x1, float y1, float x2, float y2, float w, int c) {
      float dx = x2 - x1;
      float dy = y2 - y1;
      float len = (float)Math.sqrt(dx * dx + dy * dy);
      if (len != 0.0F) {
         float nx = -dy / len * w;
         float ny = dx / len * w;
         buffer.addVertex(matrix, x1 + nx, y1 + ny, 0.0F).setColor(c);
         buffer.addVertex(matrix, x1 - nx, y1 - ny, 0.0F).setColor(c);
         buffer.addVertex(matrix, x2 - nx, y2 - ny, 0.0F).setColor(c);
         buffer.addVertex(matrix, x2 + nx, y2 + ny, 0.0F).setColor(c);
      }
   }

   private static RenderType texturedType(Identifier identifier) {
      return TEXTURE_TYPES.computeIfAbsent(
         identifier,
         id -> RenderType.create("night_textured_" + id, RenderSetup.builder(RenderPipelines.GUI_TEXTURED).withTexture("Sampler0", id).createRenderSetup())
      );
   }

   public static Vec3 project(Vec3 vec3d) {
      Vec3 camera = mc.gameRenderer.mainCamera().position();
      int[] viewport = new int[]{0, 0, mc.getWindow().getWidth(), mc.getWindow().getHeight()};
      Vector3f target = new Vector3f();
      Vector4f transform = new Vector4f((float)(vec3d.x - camera.x), (float)(vec3d.y - camera.y), (float)(vec3d.z - camera.z), 1.0F).mul(LAST_WORLD_MATRIX);
      Matrix4f matrixProj = new Matrix4f(LAST_PROJECTION_MATRIX);
      Matrix4f matrixModel = new Matrix4f(LAST_MODEL_MATRIX);
      matrixProj.mul(matrixModel).project(transform.x(), transform.y(), transform.z(), viewport, target);
      return new Vec3(target.x / mc.getWindow().getGuiScale(), (mc.getWindow().getHeight() - target.y) / mc.getWindow().getGuiScale(), target.z);
   }
}
