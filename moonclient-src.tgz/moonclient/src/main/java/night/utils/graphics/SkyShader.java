package night.utils.graphics;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.DepthStencilState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.CompareOp;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.Optional;
import java.util.OptionalDouble;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.rendertype.OutputTarget;
import net.minecraft.resources.Identifier;
import night.Night;
import night.mixins.accessors.RenderPipelinesAccessor;
import night.modules.impl.visuals.AtmosphereModule;
import night.utils.IMinecraft;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryStack;

public class SkyShader implements IMinecraft {
   private static final Identifier FRAGMENT = Identifier.fromNamespaceAndPath("night", "core/sky");
   private static final BindGroupLayout SKY_SETTINGS_LAYOUT = BindGroupLayout.builder().withUniform("SkySettings", UniformType.UNIFORM_BUFFER).build();
   private static final RenderPipeline SKY_PIPELINE = RenderPipeline.builder(new Snippet[]{RenderPipelinesAccessor.getGlobalsSnippet()})
      .withLocation("night/sky_shader")
      .withVertexShader("core/screenquad")
      .withFragmentShader(FRAGMENT)
      .withBindGroupLayout(SKY_SETTINGS_LAYOUT)
      .withPrimitiveTopology(PrimitiveTopology.TRIANGLES)
      .withCull(false)
      .withDepthStencilState(new DepthStencilState(CompareOp.ALWAYS_PASS, false))
      .build();
   private static final int UBO_SIZE = new Std140SizeCalculator()
      .putVec4()
      .putVec4()
      .putVec4()
      .putVec4()
      .putVec2()
      .putFloat()
      .putFloat()
      .putFloat()
      .putInt()
      .align(16)
      .get();
   private static float time = 0.0F;

   public static void renderSky() {
      if (mc.level != null && mc.player != null) {
         AtmosphereModule atmosphere = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AtmosphereModule.class) : null;
         if (atmosphere != null && atmosphere.isToggled() && atmosphere.modifySky.getValue()) {
            if (atmosphere.skyMode.getValue().equalsIgnoreCase("Custom")) {
               int width = mc.getWindow().getWidth();
               int height = mc.getWindow().getHeight();
               if (width > 0 && height > 0) {
                  float tickDelta = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
                  time = time + tickDelta * 0.05F * atmosphere.speed.getValue().floatValue();
                  int mode = atmosphere.customSkyMode.getValue().equalsIgnoreCase("Smoke") ? 1 : 0;
                  Color tint = atmosphere.skyTint.getColor();
                  float r = tint.getRed() / 255.0F;
                  float g = tint.getGreen() / 255.0F;
                  float b = tint.getBlue() / 255.0F;
                  float a = tint.getAlpha() / 255.0F;
                  Vector4f tintVec = new Vector4f(r, g, b, a);
                  Vector4f color1 = new Vector4f(r * 0.1F, g * 0.1F, b * 0.1F, 1.0F);
                  Vector4f color2 = new Vector4f(r * 0.8F, g * 0.8F, b * 0.8F, 1.0F);
                  float yaw = 0.0F;
                  float pitch = 0.0F;
                  float fov = (float)Math.toRadians(70.0);
                  if (mc.gameRenderer != null && mc.gameRenderer.mainCamera() != null) {
                     Camera camera = mc.gameRenderer.mainCamera();
                     yaw = (float)Math.toRadians(camera.yRot());
                     pitch = (float)Math.toRadians(camera.xRot());
                  }

                  if (mc.options != null) {
                     fov = (float)Math.toRadians(((Integer)mc.options.fov().get()).intValue());
                  }

                  Vector4f cameraAngles = new Vector4f(yaw, pitch, fov, 0.0F);
                  GpuBuffer ubo = RenderSystem.getDevice().createBuffer(() -> "Night Sky shader UBO", 136, UBO_SIZE);
                  MemoryStack stack = MemoryStack.stackPush();

                  try {
                     ByteBuffer data = Std140Builder.onStack(stack, UBO_SIZE)
                        .putVec4(tintVec)
                        .putVec4(color1)
                        .putVec4(color2)
                        .putVec4(cameraAngles)
                        .putVec2(width, height)
                        .putFloat(time)
                        .putFloat(atmosphere.intensity.getValue().floatValue())
                        .putFloat(atmosphere.speed.getValue().floatValue())
                        .putInt(mode)
                        .get();
                     RenderSystem.getDevice().createCommandEncoder().writeToBuffer(ubo.slice(), data);
                  } catch (Throwable var27) {
                     if (stack != null) {
                        try {
                           stack.close();
                        } catch (Throwable var25) {
                           var27.addSuppressed(var25);
                        }
                     }

                     throw var27;
                  }

                  if (stack != null) {
                     stack.close();
                  }

                  RenderTarget renderTarget = OutputTarget.MAIN_TARGET.getRenderTarget();
                  GpuTextureView colorTexture = RenderSystem.outputColorTextureOverride != null
                     ? RenderSystem.outputColorTextureOverride
                     : renderTarget.getColorTextureView();
                  GpuTextureView depthTexture = renderTarget.useDepth
                     ? (RenderSystem.outputDepthTextureOverride != null ? RenderSystem.outputDepthTextureOverride : renderTarget.getDepthTextureView())
                     : null;
                  RenderPass renderPass = RenderSystem.getDevice()
                     .createCommandEncoder()
                     .createRenderPass(() -> "Night Sky shader draw", colorTexture, Optional.empty(), depthTexture, OptionalDouble.empty());

                  try {
                     renderPass.setPipeline(SKY_PIPELINE);
                     renderPass.setUniform("SkySettings", ubo);
                     renderPass.draw(3, 1, 0, 0);
                  } catch (Throwable var26) {
                     if (renderPass != null) {
                        try {
                           renderPass.close();
                        } catch (Throwable var24) {
                           var26.addSuppressed(var24);
                        }
                     }

                     throw var26;
                  }

                  if (renderPass != null) {
                     renderPass.close();
                  }

                  ubo.close();
               }
            }
         }
      }
   }
}
