package night.utils.graphics;

import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.renderer.item.TrackingItemStackRenderState;
import net.minecraft.client.renderer.state.gui.GuiItemRenderState;
import net.minecraft.client.renderer.state.gui.GuiRenderState;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import night.mixins.accessors.GuiGraphicsExtractorAccessor;
import org.joml.Matrix3x2f;

public class HotbarCache {
   private static final HotbarCache.SlotEntry[] SLOTS = new HotbarCache.SlotEntry[10];

   public static void clear() {
      for (HotbarCache.SlotEntry slot : SLOTS) {
         slot.clear();
      }
   }

   public static void extractItem(GuiGraphicsExtractor context, LivingEntity entity, ItemStack stack, int x, int y, int seed) {
      if (!stack.isEmpty()) {
         Minecraft mc = Minecraft.getInstance();
         GuiRenderState renderStateContainer = ((GuiGraphicsExtractorAccessor)context).night$getGuiRenderState();
         int slotIdx = seed >= 1 && seed <= 10 ? seed - 1 : -1;
         TrackingItemStackRenderState trackingState = null;
         if (slotIdx >= 0 && slotIdx < SLOTS.length) {
            HotbarCache.SlotEntry entry = SLOTS[slotIdx];
            if (entry.matches(stack, seed)) {
               trackingState = entry.renderState;
            } else {
               trackingState = new TrackingItemStackRenderState();
               if (mc.getItemModelResolver() != null && entity != null && entity.level() != null) {
                  mc.getItemModelResolver().updateForTopItem(trackingState, stack, ItemDisplayContext.GUI, entity.level(), entity, seed);
               }

               entry.set(stack, seed, trackingState);
            }
         } else {
            trackingState = new TrackingItemStackRenderState();
            if (mc.getItemModelResolver() != null && entity != null && entity.level() != null) {
               mc.getItemModelResolver().updateForTopItem(trackingState, stack, ItemDisplayContext.GUI, entity.level(), entity, seed);
            }
         }

         if (renderStateContainer != null && trackingState != null) {
            Matrix3x2f pose = new Matrix3x2f(context.pose());
            renderStateContainer.addItem(new GuiItemRenderState(pose, trackingState, x, y, (ScreenRectangle)null));
         }
      }
   }

   static {
      for (int i = 0; i < SLOTS.length; i++) {
         SLOTS[i] = new HotbarCache.SlotEntry();
      }
   }

   public static class SlotEntry {
      public Item item;
      public int count;
      public int damage;
      public Object components;
      public int seed;
      public TrackingItemStackRenderState renderState;

      public boolean matches(ItemStack stack, int seed) {
         if (stack == null || stack.isEmpty() || this.renderState == null) {
            return false;
         } else {
            return this.renderState.isAnimated()
               ? false
               : stack.getItem() == this.item
                  && stack.getCount() == this.count
                  && stack.getDamageValue() == this.damage
                  && Objects.equals(stack.getComponents(), this.components)
                  && this.seed == seed;
         }
      }

      public void set(ItemStack stack, int seed, TrackingItemStackRenderState state) {
         this.item = stack.getItem();
         this.count = stack.getCount();
         this.damage = stack.getDamageValue();
         this.components = stack.getComponents();
         this.seed = seed;
         this.renderState = state;
      }

      public void clear() {
         this.item = null;
         this.count = 0;
         this.damage = 0;
         this.components = null;
         this.seed = 0;
         this.renderState = null;
      }
   }
}
