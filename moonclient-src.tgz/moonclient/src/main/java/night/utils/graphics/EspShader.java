package night.utils.graphics;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.DepthStencilState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.CompareOp;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.RenderSystem.AutoStorageIndexBuffer;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.client.renderer.rendertype.OutputTarget;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.mixins.accessors.PostEffectProcessorAccessor;
import night.mixins.accessors.PostPassAccessor;
import night.mixins.accessors.RenderPipelinesAccessor;
import night.modules.impl.core.ColorModule;
import night.modules.impl.visuals.ShadersModule;
import night.utils.IMinecraft;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryStack;

public class EspShader implements IMinecraft {
   public static final String[] MODES = new String[]{
      "None", "Gradient", "Rainbow", "Garmadon", "Nebula", "Blue", "Purple", "Glowing", "Pink", "Neekeri", "Image"
   };
   private static final Identifier FRAGMENT = Identifier.fromNamespaceAndPath("night", "core/esp");
   private static final BindGroupLayout ESP_SETTINGS_LAYOUT = BindGroupLayout.builder().withUniform("EspSettings", UniformType.UNIFORM_BUFFER).build();
   private static final RenderPipeline QUADS_PIPELINE = RenderPipeline.builder(new Snippet[]{RenderPipelinesAccessor.getDebugFilledSnippet()})
      .withLocation("night/esp_shader_quads")
      .withFragmentShader(FRAGMENT)
      .withBindGroupLayout(ESP_SETTINGS_LAYOUT)
      .withCull(false)
      .withDepthStencilState(new DepthStencilState(CompareOp.ALWAYS_PASS, false))
      .build();
   private static final RenderPipeline LINES_PIPELINE = RenderPipeline.builder(new Snippet[]{RenderPipelinesAccessor.getLinesSnippet()})
      .withLocation("night/esp_shader_lines")
      .withFragmentShader(FRAGMENT)
      .withBindGroupLayout(ESP_SETTINGS_LAYOUT)
      .withDepthStencilState(new DepthStencilState(CompareOp.ALWAYS_PASS, false))
      .build();
   private static final int UBO_SIZE = new Std140SizeCalculator()
      .putVec4()
      .putVec4()
      .putVec4()
      .putVec4()
      .putVec2()
      .putFloat()
      .putFloat()
      .putFloat()
      .putFloat()
      .putInt()
      .putVec2()
      .align(16)
      .get();
   private static final String OUTLINE_UNIFORM = "EspSettings";
   private static final int OUTLINE_UBO_SIZE = new Std140SizeCalculator().putVec4().putVec4().putVec4().putVec4().putVec4().putVec4().get();
   private static final String STAR_GLOW_UNIFORM = "StarGlowConfig";
   private static final String STAR_GLOW_UNIFORM_V = "StarGlowConfigV";
   private static final int STAR_GLOW_UBO_SIZE = new Std140SizeCalculator().putVec4().get();
   private static GpuBuffer starGlowUboBuffer;
   private static GpuBuffer starGlowUboBufferV;
   private static final String OUTLINE_GLOW_UNIFORM = "OutlineGlowConfig";
   private static final String OUTLINE_GLOW_UNIFORM_V = "OutlineGlowConfigV";
   private static final int OUTLINE_GLOW_UBO_SIZE = new Std140SizeCalculator().putVec4().putVec4().get();
   private static GpuBuffer outlineGlowUboBuffer;
   private static GpuBuffer outlineGlowUboBufferV;
   private static final String BLOOM_UNIFORM = "BloomConfig";
   private static final int BLOOM_UBO_SIZE = new Std140SizeCalculator().putVec4().putVec4().putVec4().putVec4().get();
   private static GpuBuffer bloomUboBuffer;
   private static GpuBuffer uboBuffer;
   private static GpuBuffer outlineUboBuffer;
   private static EspShader.Settings settings;
   public static final String[] SHADER_ACTIVE_MODES = Arrays.copyOfRange(MODES, 1, MODES.length);

   public static void writeStarGlowSettings(PostChain chain, float intensity) {
      float radius = Math.min(4.0F + intensity * 0.05F, 14.0F);

      for (PostPass pass : ((PostEffectProcessorAccessor)chain).getPasses()) {
         Map<String, GpuBuffer> uniforms = ((PostPassAccessor)pass).night$getCustomUniforms();
         if (uniforms.containsKey("StarGlowConfig")) {
            if (starGlowUboBuffer == null || uniforms.get("StarGlowConfig") != starGlowUboBuffer) {
               starGlowUboBuffer = RenderSystem.getDevice().createBuffer(() -> "Night star glow H shader UBO", 136, STAR_GLOW_UBO_SIZE);
               GpuBuffer displaced = uniforms.put("StarGlowConfig", starGlowUboBuffer);
               if (displaced != null) {
                  displaced.close();
               }
            }

            MemoryStack stack = MemoryStack.stackPush();

            try {
               ByteBuffer data = Std140Builder.onStack(stack, STAR_GLOW_UBO_SIZE).putVec4(intensity, radius, 1.0F, 0.0F).get();
               RenderSystem.getDevice().createCommandEncoder().writeToBuffer(starGlowUboBuffer.slice(), data);
            } catch (Throwable var12) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var10) {
                     var12.addSuppressed(var10);
                  }
               }

               throw var12;
            }

            if (stack != null) {
               stack.close();
            }
         }

         if (uniforms.containsKey("StarGlowConfigV")) {
            if (starGlowUboBufferV == null || uniforms.get("StarGlowConfigV") != starGlowUboBufferV) {
               starGlowUboBufferV = RenderSystem.getDevice().createBuffer(() -> "Night star glow V shader UBO", 136, STAR_GLOW_UBO_SIZE);
               GpuBuffer displaced = uniforms.put("StarGlowConfigV", starGlowUboBufferV);
               if (displaced != null) {
                  displaced.close();
               }
            }

            MemoryStack stack = MemoryStack.stackPush();

            try {
               ByteBuffer data = Std140Builder.onStack(stack, STAR_GLOW_UBO_SIZE).putVec4(intensity, radius, 0.0F, 1.0F).get();
               RenderSystem.getDevice().createCommandEncoder().writeToBuffer(starGlowUboBufferV.slice(), data);
            } catch (Throwable var11) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var9) {
                     var11.addSuppressed(var9);
                  }
               }

               throw var11;
            }

            if (stack != null) {
               stack.close();
            }
         }
      }
   }

   public static int modeIndex(String mode) {
      for (int i = 0; i < MODES.length; i++) {
         if (MODES[i].equalsIgnoreCase(mode)) {
            return i;
         }
      }

      return 0;
   }

   public static void setSettings(EspShader.Settings value) {
      settings = value;
   }

   public static void writeOutlineSettings(PostChain chain, EspShader.Settings settings, float glow) {
      float glowRadius = Math.min(6.0F + glow * 18.0F, 24.0F);

      for (PostPass pass : ((PostEffectProcessorAccessor)chain).getPasses()) {
         Map<String, GpuBuffer> uniforms = ((PostPassAccessor)pass).night$getCustomUniforms();
         if (uniforms.containsKey("BloomConfig")) {
            if (bloomUboBuffer == null || uniforms.get("BloomConfig") != bloomUboBuffer) {
               bloomUboBuffer = RenderSystem.getDevice().createBuffer(() -> "Night outline bloom UBO", 136, BLOOM_UBO_SIZE);
               GpuBuffer displaced = uniforms.put("BloomConfig", bloomUboBuffer);
               if (displaced != null) {
                  displaced.close();
               }
            }

            ShadersModule shaders = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ShadersModule.class) : null;
            float width = shaders != null ? shaders.bloomWidth.getValue().floatValue() : 3.0F;
            float glowInside = shaders != null && shaders.bloomGlowInside.getValue() ? 1.0F : 0.0F;
            float quality = shaders != null ? shaders.bloomGlowQuality.getValue().floatValue() : 1.0F;
            float multiplier = shaders != null ? shaders.bloomGlowMultiplier.getValue().floatValue() : 1.0F;
            float fillAlpha = shaders != null ? shaders.bloomFillAlpha.getValue().floatValue() / 100.0F : 1.0F;
            float outlineAlpha = shaders != null ? shaders.bloomOutlineAlpha.getValue().floatValue() / 100.0F : 1.0F;
            float fillMode = shaders != null ? ShadersModule.getBloomFillModeIndex(shaders.bloomFillMode.getValue()) : 0.0F;
            float gradFactor = shaders != null ? shaders.bloomGradientFactor.getValue().floatValue() : 200.0F;
            Color gradColor = shaders != null ? shaders.bloomGradientColor.getColor() : Color.RED;
            float time = (float)(System.currentTimeMillis() % 2000000L);
            MemoryStack stack = MemoryStack.stackPush();

            try {
               ByteBuffer data = Std140Builder.onStack(stack, BLOOM_UBO_SIZE)
                  .putVec4(width, glowInside, quality, multiplier)
                  .putVec4(fillAlpha, outlineAlpha, fillMode, gradFactor)
                  .putVec4(gradColor.getRed() / 255.0F, gradColor.getGreen() / 255.0F, gradColor.getBlue() / 255.0F, gradColor.getAlpha() / 255.0F)
                  .putVec4(time, 0.0F, mc.getWindow().getWidth(), mc.getWindow().getHeight())
                  .get();
               RenderSystem.getDevice().createCommandEncoder().writeToBuffer(bloomUboBuffer.slice(), data);
            } catch (Throwable var28) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var24) {
                     var28.addSuppressed(var24);
                  }
               }

               throw var28;
            }

            if (stack != null) {
               stack.close();
            }
         }

         if (uniforms.containsKey("OutlineGlowConfig")) {
            if (outlineGlowUboBuffer == null || uniforms.get("OutlineGlowConfig") != outlineGlowUboBuffer) {
               outlineGlowUboBuffer = RenderSystem.getDevice().createBuffer(() -> "Night outline glow H UBO", 136, OUTLINE_GLOW_UBO_SIZE);
               GpuBuffer displaced = uniforms.put("OutlineGlowConfig", outlineGlowUboBuffer);
               if (displaced != null) {
                  displaced.close();
               }
            }

            ShadersModule shaders = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ShadersModule.class) : null;
            Color gColor = shaders != null && shaders.glowColor != null ? shaders.glowColor.getColor() : Color.MAGENTA;
            MemoryStack stack = MemoryStack.stackPush();

            try {
               ByteBuffer data = Std140Builder.onStack(stack, OUTLINE_GLOW_UBO_SIZE)
                  .putVec4(glow, glowRadius, 1.0F, 0.0F)
                  .putVec4(gColor.getRed() / 255.0F, gColor.getGreen() / 255.0F, gColor.getBlue() / 255.0F, gColor.getAlpha() / 255.0F)
                  .get();
               RenderSystem.getDevice().createCommandEncoder().writeToBuffer(outlineGlowUboBuffer.slice(), data);
            } catch (Throwable var27) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var23) {
                     var27.addSuppressed(var23);
                  }
               }

               throw var27;
            }

            if (stack != null) {
               stack.close();
            }
         }

         ShadersModule shaders = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ShadersModule.class) : null;
         ColorModule cm = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ColorModule.class) : null;
         if (uniforms.containsKey("OutlineGlowConfigV")) {
            if (outlineGlowUboBufferV == null || uniforms.get("OutlineGlowConfigV") != outlineGlowUboBufferV) {
               outlineGlowUboBufferV = RenderSystem.getDevice().createBuffer(() -> "Night outline glow V UBO", 136, OUTLINE_GLOW_UBO_SIZE);
               GpuBuffer displaced = uniforms.put("OutlineGlowConfigV", outlineGlowUboBufferV);
               if (displaced != null) {
                  displaced.close();
               }
            }

            Color gColor = shaders != null && shaders.glowColor != null ? shaders.glowColor.getColor() : Color.MAGENTA;
            boolean isGlowRainbow = shaders != null
               && shaders.glowColor != null
               && (shaders.glowColor.isRainbow() || shaders.glowColor.isSync() && cm != null && cm.color.isRainbow());
            MemoryStack stack = MemoryStack.stackPush();

            try {
               ByteBuffer data = Std140Builder.onStack(stack, OUTLINE_GLOW_UBO_SIZE)
                  .putVec4(glow, glowRadius, isGlowRainbow ? 1.0F : 0.0F, 1.0F)
                  .putVec4(gColor.getRed() / 255.0F, gColor.getGreen() / 255.0F, gColor.getBlue() / 255.0F, gColor.getAlpha() / 255.0F)
                  .get();
               RenderSystem.getDevice().createCommandEncoder().writeToBuffer(outlineGlowUboBufferV.slice(), data);
            } catch (Throwable var26) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var22) {
                     var26.addSuppressed(var22);
                  }
               }

               throw var26;
            }

            if (stack != null) {
               stack.close();
            }
         }

         if (uniforms.containsKey("EspSettings")) {
            if (outlineUboBuffer == null || uniforms.get("EspSettings") != outlineUboBuffer) {
               outlineUboBuffer = RenderSystem.getDevice().createBuffer(() -> "Night outline shader UBO", 136, OUTLINE_UBO_SIZE);
               GpuBuffer displaced = uniforms.put("EspSettings", outlineUboBuffer);
               if (displaced != null) {
                  displaced.close();
               }
            }

            boolean isColorRainbow = shaders != null
               && shaders.color != null
               && (shaders.color.isRainbow() || shaders.color.isSync() && cm != null && cm.color.isRainbow());
            float rainbowSat = cm != null ? cm.rainbowSaturation.getValue().floatValue() / 100.0F : 1.0F;
            MemoryStack stack = MemoryStack.stackPush();

            try {
               ByteBuffer data = Std140Builder.onStack(stack, OUTLINE_UBO_SIZE)
                  .putVec4(settings.color0)
                  .putVec4(settings.color1)
                  .putVec4(settings.color2)
                  .putVec4(settings.color3)
                  .putVec4(settings.time, settings.step, settings.distance, settings.effect)
                  .putVec4(settings.alpha, glow, isColorRainbow ? 1.0F : 0.0F, rainbowSat)
                  .get();
               RenderSystem.getDevice().createCommandEncoder().writeToBuffer(outlineUboBuffer.slice(), data);
            } catch (Throwable var25) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var21) {
                     var25.addSuppressed(var21);
                  }
               }

               throw var25;
            }

            if (stack != null) {
               stack.close();
            }
         }
      }
   }

   public static EspShader.Settings createSettings(
      String mode, float opacity, float speed, float step, Color c1, Color c2, Color c3, Color c4, Color glow, Vec3 pos
   ) {
      return createSettings(mode, opacity, speed, step, c1, c2, c3, c4, glow, pos, new Vector2f(0.0F, 0.0F));
   }

   public static EspShader.Settings createSettings(
      String mode, float opacity, float speed, float step, Color c1, Color c2, Color c3, Color c4, Color glow, Vec3 pos, Vector2f offset
   ) {
      int effect = modeIndex(mode);
      if (effect == 0) {
         return null;
      } else {
         float time = (float)(System.currentTimeMillis() % 2000000L) / 1000.0F * speed * (effect == 1 ? step : 1.0F);
         float distance = pos != null && mc.player != null ? (float)Math.sqrt(mc.player.distanceToSqr(pos)) : 1.0F;
         return new EspShader.Settings(effect, time, step, opacity / 100.0F, distance, effect == 7 ? glow : c1, c2, c3, c4, offset);
      }
   }

   public static void draw(List<Renderer3D.VertexCollection> quads, List<Renderer3D.VertexCollection> debugLines) {
      draw(quads, debugLines, settings);
   }

   public static void draw(List<Renderer3D.VertexCollection> quads, List<Renderer3D.VertexCollection> debugLines, EspShader.Settings settings) {
      if (settings != null && (!quads.isEmpty() || !debugLines.isEmpty())) {
         GpuBuffer ubo = RenderSystem.getDevice().createBuffer(() -> "Night ESP shader UBO", 136, UBO_SIZE);
         MemoryStack stack = MemoryStack.stackPush();

         try {
            ByteBuffer data = Std140Builder.onStack(stack, UBO_SIZE)
               .putVec4(settings.color0)
               .putVec4(settings.color1)
               .putVec4(settings.color2)
               .putVec4(settings.color3)
               .putVec2(mc.getWindow().getWidth(), mc.getWindow().getHeight())
               .putFloat(settings.time)
               .putFloat(settings.step)
               .putFloat(settings.alpha)
               .putFloat(settings.distance)
               .putInt(settings.effect)
               .putVec2(settings.offset.x, settings.offset.y)
               .get();
            RenderSystem.getDevice().createCommandEncoder().writeToBuffer(ubo.slice(), data);
         } catch (Throwable var13) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var11) {
                  var13.addSuppressed(var11);
               }
            }

            throw var13;
         }

         if (stack != null) {
            stack.close();
         }

         if (!quads.isEmpty()) {
            int vertexCount = Renderer3D.vertexCount(quads);
            ByteBufferBuilder byteBufferBuilder = ByteBufferBuilder.exactlySized(vertexCount * DefaultVertexFormat.POSITION_COLOR.getVertexSize());

            try {
               BufferBuilder buffer = new BufferBuilder(byteBufferBuilder, PrimitiveTopology.QUADS, DefaultVertexFormat.POSITION_COLOR);

               for (Renderer3D.VertexCollection collection : quads) {
                  collection.quad(buffer);
               }

               submit(QUADS_PIPELINE, buffer.build(), ubo);
            } catch (Throwable var14) {
               if (byteBufferBuilder != null) {
                  try {
                     byteBufferBuilder.close();
                  } catch (Throwable var10) {
                     var14.addSuppressed(var10);
                  }
               }

               throw var14;
            }

            if (byteBufferBuilder != null) {
               byteBufferBuilder.close();
            }
         }

         if (!debugLines.isEmpty()) {
            int vertexCount = Renderer3D.vertexCount(debugLines) * 2;
            ByteBufferBuilder byteBufferBuilder = ByteBufferBuilder.exactlySized(
               vertexCount * DefaultVertexFormat.POSITION_COLOR_NORMAL_LINE_WIDTH.getVertexSize()
            );

            try {
               BufferBuilder buffer = new BufferBuilder(byteBufferBuilder, PrimitiveTopology.LINES, DefaultVertexFormat.POSITION_COLOR_NORMAL_LINE_WIDTH);
               Renderer3D.buildLines(buffer, debugLines);
               submit(LINES_PIPELINE, buffer.build(), ubo);
            } catch (Throwable var12) {
               if (byteBufferBuilder != null) {
                  try {
                     byteBufferBuilder.close();
                  } catch (Throwable var9) {
                     var12.addSuppressed(var9);
                  }
               }

               throw var12;
            }

            if (byteBufferBuilder != null) {
               byteBufferBuilder.close();
            }
         }

         ubo.close();
         quads.clear();
         debugLines.clear();
      } else {
         quads.clear();
         debugLines.clear();
      }
   }

   private static void submit(RenderPipeline pipeline, MeshData mesh, GpuBuffer ubo) {
      if (mesh != null) {
         GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
            .writeTransform(RenderSystem.getModelViewMatrixCopy(), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), new Vector3f(), new Matrix4f());
         MeshData var4 = mesh;

         try {
            GpuBuffer vertices = RenderSystem.getDevice().createBuffer(() -> "Night ESP shader vertices", 32, mesh.vertexBuffer());
            GpuBuffer ownedIndices = null;
            GpuBuffer indices;
            IndexType indexType;
            if (mesh.indexBuffer() == null) {
               AutoStorageIndexBuffer autoIndices = RenderSystem.getSequentialBuffer(mesh.drawState().primitiveTopology());
               indices = autoIndices.getBuffer(mesh.drawState().indexCount());
               indexType = autoIndices.type();
            } else {
               indices = ownedIndices = RenderSystem.getDevice().createBuffer(() -> "Night ESP shader indices", 64, mesh.indexBuffer());
               indexType = mesh.drawState().indexType();
            }

            RenderTarget renderTarget = OutputTarget.MAIN_TARGET.getRenderTarget();
            GpuTextureView colorTexture = RenderSystem.outputColorTextureOverride != null
               ? RenderSystem.outputColorTextureOverride
               : renderTarget.getColorTextureView();
            GpuTextureView depthTexture = renderTarget.useDepth
               ? (RenderSystem.outputDepthTextureOverride != null ? RenderSystem.outputDepthTextureOverride : renderTarget.getDepthTextureView())
               : null;
            RenderPass renderPass = RenderSystem.getDevice()
               .createCommandEncoder()
               .createRenderPass(() -> "Night ESP shader draw", colorTexture, Optional.empty(), depthTexture, OptionalDouble.empty());

            try {
               renderPass.setPipeline(pipeline);
               RenderSystem.bindDefaultUniforms(renderPass);
               renderPass.setUniform("DynamicTransforms", dynamicTransforms);
               renderPass.setUniform("EspSettings", ubo);
               renderPass.setVertexBuffer(0, vertices.slice());
               renderPass.setIndexBuffer(indices, indexType);
               renderPass.drawIndexed(mesh.drawState().indexCount(), 1, 0, 0, 0);
            } catch (Throwable var17) {
               if (renderPass != null) {
                  try {
                     renderPass.close();
                  } catch (Throwable var16) {
                     var17.addSuppressed(var16);
                  }
               }

               throw var17;
            }

            if (renderPass != null) {
               renderPass.close();
            }

            vertices.close();
            if (ownedIndices != null) {
               ownedIndices.close();
            }
         } catch (Throwable var18) {
            if (mesh != null) {
               try {
                  var4.close();
               } catch (Throwable var15) {
                  var18.addSuppressed(var15);
               }
            }

            throw var18;
         }

         if (mesh != null) {
            mesh.close();
         }
      }
   }

   public static class Settings {
      public final int effect;
      public final float time;
      public final float step;
      public final float alpha;
      public final float distance;
      public final Vector4f color0;
      public final Vector4f color1;
      public final Vector4f color2;
      public final Vector4f color3;
      public final Vector2f offset;

      public Settings(int effect, float time, float step, float alpha, float distance, Color c0, Color c1, Color c2, Color c3) {
         this(effect, time, step, alpha, distance, c0, c1, c2, c3, new Vector2f(0.0F, 0.0F));
      }

      public Settings(int effect, float time, float step, float alpha, float distance, Color c0, Color c1, Color c2, Color c3, Vector2f offset) {
         this.effect = effect;
         this.time = time;
         this.step = step;
         this.alpha = alpha;
         this.distance = distance;
         this.color0 = toVector(c0);
         this.color1 = toVector(c1);
         this.color2 = toVector(c2);
         this.color3 = toVector(c3);
         this.offset = offset != null ? offset : new Vector2f(0.0F, 0.0F);
      }

      private static Vector4f toVector(Color color) {
         return new Vector4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
      }
   }
}
