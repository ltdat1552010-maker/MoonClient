package night.utils.graphics;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.LevelTargetBundle;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.Identifier;
import night.mixins.accessors.PostEffectProcessorAccessor;
import night.mixins.accessors.PostPassAccessor;
import org.lwjgl.system.MemoryStack;

public class ClickGuiBackground {
   private static final Identifier CHAIN_ID = Identifier.fromNamespaceAndPath("night", "clickgui_bg");
   private static final Identifier TARGET_ID = Identifier.withDefaultNamespace("clickgui_bg_target");
   private static final Identifier TEXTURE_ID = Identifier.fromNamespaceAndPath("night", "clickgui_bg_texture");
   private static final String UNIFORM_NAME = "ClickGuiBgConfig";
   private static final int UBO_SIZE = new Std140SizeCalculator().putVec4().putVec4().align(16).get();
   private static PostChain chain;
   private static GpuBuffer uboBuffer;
   private static long lastProcessedAtMs = -1L;
   private static ClickGuiBackground.BgTexture texture;
   private static float phaseSeconds = 0.0F;
   private static long lastPhaseUpdateMs = -1L;

   private static void ensureProcessed(int modeIndex, float speed, float opacity, Color themeColor, boolean isRainbow) {
      long now = System.currentTimeMillis();
      if (now - lastProcessedAtMs >= 8L) {
         lastProcessedAtMs = now;
         PostChain freshChain = Minecraft.getInstance().getShaderManager().getPostChain(CHAIN_ID, LevelTargetBundle.MAIN_TARGETS);
         if (freshChain != chain) {
            chain = freshChain;
            uboBuffer = null;
         }

         if (chain != null) {
            writeUniforms(modeIndex, speed, opacity, themeColor, isRainbow);
            chain.process(Minecraft.getInstance().gameRenderer.mainRenderTarget(), GraphicsResourceAllocator.UNPOOLED);
            RenderTarget target = ((PostEffectProcessorAccessor)chain).getPersistentTargets().get(TARGET_ID);
            if (target != null && target.getColorTextureView() != null) {
               if (texture == null || !texture.wraps(target.getColorTextureView())) {
                  if (texture != null) {
                     Minecraft.getInstance().getTextureManager().release(TEXTURE_ID);
                  }

                  texture = new ClickGuiBackground.BgTexture(target.getColorTexture(), target.getColorTextureView());
                  Minecraft.getInstance().getTextureManager().register(TEXTURE_ID, texture);
               }
            }
         }
      }
   }

   private static void writeUniforms(int modeIndex, float speed, float opacity, Color themeColor, boolean isRainbow) {
      for (PostPass pass : ((PostEffectProcessorAccessor)chain).getPasses()) {
         Map<String, GpuBuffer> uniforms = ((PostPassAccessor)pass).night$getCustomUniforms();
         if (uniforms.containsKey("ClickGuiBgConfig")) {
            if (uboBuffer == null || uniforms.get("ClickGuiBgConfig") != uboBuffer) {
               uboBuffer = RenderSystem.getDevice().createBuffer(() -> "Night ClickGUI BG UBO", 136, UBO_SIZE);
               GpuBuffer displaced = uniforms.put("ClickGuiBgConfig", uboBuffer);
               if (displaced != null) {
                  displaced.close();
               }
            }

            long now = System.currentTimeMillis();
            if (lastPhaseUpdateMs >= 0L) {
               phaseSeconds = phaseSeconds + (float)(now - lastPhaseUpdateMs) / 1000.0F * speed;
            }

            lastPhaseUpdateMs = now;
            float r = themeColor.getRed() / 255.0F;
            float g = themeColor.getGreen() / 255.0F;
            float b = themeColor.getBlue() / 255.0F;
            float rainbowFlag = isRainbow ? 1.0F : 0.0F;
            MemoryStack stack = MemoryStack.stackPush();

            try {
               ByteBuffer data = Std140Builder.onStack(stack, UBO_SIZE).putVec4(phaseSeconds, modeIndex, opacity, speed).putVec4(r, g, b, rainbowFlag).get();
               RenderSystem.getDevice().createCommandEncoder().writeToBuffer(uboBuffer.slice(), data);
            } catch (Throwable var18) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var17) {
                     var18.addSuppressed(var17);
                  }
               }

               throw var18;
            }

            if (stack != null) {
               stack.close();
            }
         }
      }
   }

   public static void renderBackground(
      GuiGraphicsExtractor context, int screenW, int screenH, int modeIndex, float speed, float opacity, Color themeColor, boolean isRainbow
   ) {
      if (!(opacity <= 0.001F) && modeIndex >= 0) {
         ensureProcessed(modeIndex, speed, opacity, themeColor, isRainbow);
         if (texture != null) {
            int alpha = Math.min(255, Math.max(0, Math.round(opacity * 255.0F)));
            int colorMask = alpha << 24 | 16777215;
            context.blit(RenderPipelines.GUI_TEXTURED, TEXTURE_ID, 0, 0, 0.0F, 0.0F, screenW, screenH, screenW, screenH, screenW, screenH, colorMask);
         }
      }
   }

   private static class BgTexture extends AbstractTexture {
      BgTexture(GpuTexture texture, GpuTextureView view) {
         this.texture = texture;
         this.textureView = view;
      }

      boolean wraps(GpuTextureView view) {
         return this.textureView == view;
      }

      public void close() {
      }
   }
}
