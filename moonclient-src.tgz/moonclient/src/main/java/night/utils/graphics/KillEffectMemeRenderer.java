package night.utils.graphics;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.DepthStencilState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.CompareOp;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderSetup.OutlineProperty;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import night.mixins.accessors.RenderPipelinesAccessor;
import night.utils.IMinecraft;
import org.joml.Vector3f;

public class KillEffectMemeRenderer implements IMinecraft {
   public static final KillEffectMemeRenderer INSTANCE = new KillEffectMemeRenderer();
   private static final Identifier CIRCLE_TEXTURE_ID = Identifier.fromNamespaceAndPath("night", "textures/effect/meme_circle.png");
   private static final Identifier ARROW_TEXTURE_ID = Identifier.fromNamespaceAndPath("night", "textures/effect/meme_arrow.png");
   private static final int BLINK_COUNT = 3;
   private static final float BLINK_ON_SEC = 0.18F;
   private static final float BLINK_OFF_SEC = 0.12F;
   private static final float CYCLE_SEC = 0.3F;
   private static RenderType circleLayer;
   private static RenderType arrowLayer;
   private static final RenderPipeline NO_DEPTH_MEME_PIPELINE = RenderPipeline.builder(new Snippet[]{RenderPipelinesAccessor.getEntitySnippet()})
      .withLocation("night/no_depth_meme")
      .withShaderDefine("ALPHA_CUTOUT", 0.1F)
      .withBindGroupLayout(BindGroupLayouts.SAMPLER0_SAMPLER1_SAMPLER2)
      .withCull(false)
      .withDepthStencilState(new DepthStencilState(CompareOp.ALWAYS_PASS, false))
      .withColorTargetState(new ColorTargetState(BlendFunction.TRANSLUCENT))
      .build();
   private final List<KillEffectMemeRenderer.MemeInstance> instances = new ArrayList<>();
   private long lastNanos = 0L;

   private static RenderType buildLayer(String name, Identifier texture) {
      return RenderType.create(
         "night_" + name,
         RenderSetup.builder(NO_DEPTH_MEME_PIPELINE)
            .withTexture("Sampler0", texture)
            .useLightmap()
            .useOverlay()
            .affectsCrumbling()
            .sortOnUpload()
            .setOutline(OutlineProperty.NONE)
            .createRenderSetup()
      );
   }

   private static RenderType getCircleLayer() {
      if (circleLayer != null) {
         return circleLayer;
      } else {
         circleLayer = buildLayer("kill_effect_meme_circle", CIRCLE_TEXTURE_ID);
         return circleLayer;
      }
   }

   private static RenderType getArrowLayer() {
      if (arrowLayer != null) {
         return arrowLayer;
      } else {
         arrowLayer = buildLayer("kill_effect_meme_arrow", ARROW_TEXTURE_ID);
         return arrowLayer;
      }
   }

   public void spawn(Vector3f worldPos, float size) {
      KillEffectMemeRenderer.MemeInstance inst = new KillEffectMemeRenderer.MemeInstance();
      inst.pos.set(worldPos);
      inst.size = size;
      this.instances.add(inst);
   }

   public void render(PoseStack matrices) {
      if (this.instances.isEmpty()) {
         this.lastNanos = 0L;
      } else if (mc.player != null && mc.level != null) {
         long now = System.nanoTime();
         float dt = this.lastNanos == 0L ? 0.0F : Math.min((float)(now - this.lastNanos) / 1.0E9F, 0.1F);
         this.lastNanos = now;
         float totalLife = 0.90000004F;
         Iterator<KillEffectMemeRenderer.MemeInstance> it = this.instances.iterator();

         while (it.hasNext()) {
            KillEffectMemeRenderer.MemeInstance inst = it.next();
            inst.age += dt;
            if (inst.age >= totalLife) {
               it.remove();
            }
         }

         if (!this.instances.isEmpty()) {
            Pose pose = matrices.last();
            Camera camera = mc.gameRenderer.mainCamera();
            Vector3f camUp = new Vector3f(camera.upVector());
            Vector3f camLeft = new Vector3f(camera.leftVector());
            Vec3 camPosD = camera.position();
            Vector3f camPos = new Vector3f((float)camPosD.x, (float)camPosD.y, (float)camPosD.z);
            Vector3f rel = new Vector3f();
            RenderType circleType = getCircleLayer();
            ByteBufferBuilder circleBytes = new ByteBufferBuilder(1024);

            try {
               BufferBuilder circleVc = new BufferBuilder(circleBytes, circleType.primitiveTopology(), circleType.format());

               for (KillEffectMemeRenderer.MemeInstance inst : this.instances) {
                  if (!(inst.age % 0.3F >= 0.18F)) {
                     rel.set(inst.pos).sub(camPos);
                     emitBillboard(circleVc, pose, rel, camUp, camLeft, inst.size, 255);
                  }
               }

               MeshData mesh = circleVc.build();
               if (mesh != null) {
                  Renderer3D.draw(circleType, mesh);
               }
            } catch (Throwable var24) {
               try {
                  circleBytes.close();
               } catch (Throwable var22) {
                  var24.addSuppressed(var22);
               }

               throw var24;
            }

            circleBytes.close();
            Vector3f var26 = new Vector3f();
            RenderType var27 = getArrowLayer();
            ByteBufferBuilder var29 = new ByteBufferBuilder(1024);

            try {
               BufferBuilder arrowVc = new BufferBuilder(var29, var27.primitiveTopology(), var27.format());

               for (KillEffectMemeRenderer.MemeInstance instx : this.instances) {
                  if (!(instx.age % 0.3F >= 0.18F)) {
                     rel.set(instx.pos).sub(camPos);
                     var26.set(camLeft)
                        .mul(-instx.size * 1.1F)
                        .add(camUp.x * instx.size * 1.1F, camUp.y * instx.size * 1.1F, camUp.z * instx.size * 1.1F)
                        .add(rel);
                     emitBillboard(arrowVc, pose, var26, camUp, camLeft, instx.size * 0.8F, 255);
                  }
               }

               MeshData mesh = arrowVc.build();
               if (mesh != null) {
                  Renderer3D.draw(var27, mesh);
               }
            } catch (Throwable var23) {
               try {
                  var29.close();
               } catch (Throwable var21) {
                  var23.addSuppressed(var21);
               }

               throw var23;
            }

            var29.close();
         }
      }
   }

   private static void emitBillboard(BufferBuilder vc, Pose pose, Vector3f c, Vector3f camUp, Vector3f camLeft, float size, int alpha) {
      Vector3f u = new Vector3f(camUp).mul(size);
      Vector3f l = new Vector3f(camLeft).mul(size);
      Vector3f v0 = new Vector3f(c).sub(u).sub(l);
      Vector3f v1 = new Vector3f(c).sub(u).add(l);
      Vector3f v2 = new Vector3f(c).add(u).add(l);
      Vector3f v3 = new Vector3f(c).add(u).sub(l);
      int argb = alpha << 24 | 16777215;
      vc.addVertex(pose, v0.x, v0.y, v0.z)
         .setColor(argb)
         .setUv(1.0F, 1.0F)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(pose, 0.0F, 1.0F, 0.0F);
      vc.addVertex(pose, v1.x, v1.y, v1.z)
         .setColor(argb)
         .setUv(0.0F, 1.0F)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(pose, 0.0F, 1.0F, 0.0F);
      vc.addVertex(pose, v2.x, v2.y, v2.z)
         .setColor(argb)
         .setUv(0.0F, 0.0F)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(pose, 0.0F, 1.0F, 0.0F);
      vc.addVertex(pose, v3.x, v3.y, v3.z)
         .setColor(argb)
         .setUv(1.0F, 0.0F)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(pose, 0.0F, 1.0F, 0.0F);
   }

   private static final class MemeInstance {
      final Vector3f pos = new Vector3f();
      float age;
      float size;
   }
}
