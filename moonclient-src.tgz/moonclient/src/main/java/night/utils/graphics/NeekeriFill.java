package night.utils.graphics;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.LevelTargetBundle;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.Identifier;
import night.Night;
import night.mixins.accessors.PostEffectProcessorAccessor;
import night.mixins.accessors.PostPassAccessor;
import night.modules.impl.core.ClickGuiModule;
import org.lwjgl.system.MemoryStack;

public class NeekeriFill {
   private static final Identifier CHAIN_ID = Identifier.fromNamespaceAndPath("night", "neekeri_ui");
   private static final Identifier PATTERN_TARGET_ID = Identifier.withDefaultNamespace("pattern");
   private static final Identifier TEXTURE_ID = Identifier.fromNamespaceAndPath("night", "neekeri_ui_pattern");
   private static final String UNIFORM_NAME = "NeekeriConfig";
   private static final int UBO_SIZE = new Std140SizeCalculator().putVec4().get();
   private static PostChain chain;
   private static GpuBuffer uboBuffer;
   private static long lastProcessedAtMs = -1L;
   private static NeekeriFill.PatternTexture texture;
   private static float phaseSeconds = 0.0F;
   private static long lastPhaseUpdateMs = -1L;

   private static void ensureProcessed() {
      long now = System.currentTimeMillis();
      if (now - lastProcessedAtMs >= 10L) {
         lastProcessedAtMs = now;
         PostChain freshChain = Minecraft.getInstance().getShaderManager().getPostChain(CHAIN_ID, LevelTargetBundle.MAIN_TARGETS);
         if (freshChain != chain) {
            chain = freshChain;
            uboBuffer = null;
         }

         if (chain != null) {
            try {
               writeTime();
               chain.process(Minecraft.getInstance().gameRenderer.mainRenderTarget(), GraphicsResourceAllocator.UNPOOLED);
            } catch (IllegalStateException var4) {
               return;
            }

            RenderTarget pattern = ((PostEffectProcessorAccessor)chain).getPersistentTargets().get(PATTERN_TARGET_ID);
            if (pattern != null && pattern.getColorTextureView() != null) {
               if (texture == null || !texture.wraps(pattern.getColorTextureView())) {
                  if (texture != null) {
                     Minecraft.getInstance().getTextureManager().release(TEXTURE_ID);
                  }

                  texture = new NeekeriFill.PatternTexture(pattern.getColorTexture(), pattern.getColorTextureView());
                  Minecraft.getInstance().getTextureManager().register(TEXTURE_ID, texture);
               }
            }
         }
      }
   }

   private static void writeTime() {
      for (PostPass pass : ((PostEffectProcessorAccessor)chain).getPasses()) {
         Map<String, GpuBuffer> uniforms = ((PostPassAccessor)pass).night$getCustomUniforms();
         if (uniforms.containsKey("NeekeriConfig")) {
            if (uboBuffer == null || uniforms.get("NeekeriConfig") != uboBuffer) {
               uboBuffer = RenderSystem.getDevice().createBuffer(() -> "Night neekeri fill UBO", 136, UBO_SIZE);
               GpuBuffer displaced = uniforms.put("NeekeriConfig", uboBuffer);
               if (displaced != null) {
                  displaced.close();
               }
            }

            ClickGuiModule clickGui = Night.MODULE_MANAGER.getModule(ClickGuiModule.class);
            long now = System.currentTimeMillis();
            float speed = clickGui.neekeriSpeed.getValue().floatValue();
            if (lastPhaseUpdateMs >= 0L) {
               phaseSeconds = phaseSeconds + (float)(now - lastPhaseUpdateMs) / 1000.0F * speed;
            }

            lastPhaseUpdateMs = now;
            int effect = Arrays.asList(EspShader.MODES).indexOf(clickGui.fillMode.getValue());
            if (effect <= 0) {
               effect = EspShader.MODES.length - 1;
            }

            MemoryStack stack = MemoryStack.stackPush();

            try {
               ByteBuffer data = Std140Builder.onStack(stack, UBO_SIZE).putVec4(phaseSeconds, effect, 0.0F, 0.0F).get();
               RenderSystem.getDevice().createCommandEncoder().writeToBuffer(uboBuffer.slice(), data);
            } catch (Throwable var12) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var11) {
                     var12.addSuppressed(var11);
                  }
               }

               throw var12;
            }

            if (stack != null) {
               stack.close();
            }
         }
      }
   }

   public static void fill(GuiGraphicsExtractor context, int x, int y, int width, int height, int alpha) {
      ensureProcessed();
      if (texture != null) {
         int screenW = Minecraft.getInstance().getWindow().getGuiScaledWidth();
         int screenH = Minecraft.getInstance().getWindow().getGuiScaledHeight();
         context.blit(RenderPipelines.GUI_TEXTURED, TEXTURE_ID, x, y, x, y, width, height, width, height, screenW, screenH, alpha << 24 | 16777215);
      }
   }

   private static class PatternTexture extends AbstractTexture {
      PatternTexture(GpuTexture texture, GpuTextureView view) {
         this.texture = texture;
         this.textureView = view;
      }

      boolean wraps(GpuTextureView view) {
         return this.textureView == view;
      }

      public void close() {
      }
   }
}
