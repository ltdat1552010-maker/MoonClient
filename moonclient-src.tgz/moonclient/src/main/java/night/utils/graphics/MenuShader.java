package night.utils.graphics;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.LevelTargetBundle;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.Identifier;
import night.mixins.accessors.PostEffectProcessorAccessor;
import night.mixins.accessors.PostPassAccessor;
import night.utils.IMinecraft;
import org.lwjgl.system.MemoryStack;

public class MenuShader implements IMinecraft {
   private static final Identifier CHAIN_ID = Identifier.fromNamespaceAndPath("night", "menu_bg");
   private static final Identifier TARGET_ID = Identifier.withDefaultNamespace("menu_bg_target");
   private static final Identifier TEXTURE_ID = Identifier.fromNamespaceAndPath("night", "menu_bg_texture");
   private static final String UNIFORM_NAME = "MenuBgConfig";
   private static final int UBO_SIZE = new Std140SizeCalculator().putVec4().align(16).get();
   private static PostChain chain;
   private static GpuBuffer uboBuffer;
   private static long lastProcessedAtMs = -1L;
   private static MenuShader.MenuTexture texture;
   private static final long START_TIME = System.currentTimeMillis();
   private static final Identifier STATIC_BG = Identifier.fromNamespaceAndPath("night", "textures/gui/moonlight_bg.png");

   private static void ensureProcessed(float alpha, float transitionProgress, boolean resourcesReady) {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && mc.getShaderManager() != null && mc.gameRenderer != null && mc.gameRenderer.mainRenderTarget() != null) {
         if (resourcesReady) {
            try {
               PostChain freshChain = mc.getShaderManager().getPostChain(CHAIN_ID, LevelTargetBundle.MAIN_TARGETS);
               if (freshChain != chain) {
                  chain = freshChain;
                  uboBuffer = null;
               }

               if (chain == null) {
                  return;
               }

               writeUniforms(alpha, transitionProgress);
               chain.process(mc.gameRenderer.mainRenderTarget(), GraphicsResourceAllocator.UNPOOLED);
               RenderTarget target = ((PostEffectProcessorAccessor)chain).getPersistentTargets().get(TARGET_ID);
               if (target == null || target.getColorTextureView() == null) {
                  return;
               }

               if (texture == null || !texture.wraps(target.getColorTextureView())) {
                  if (texture != null) {
                     mc.getTextureManager().release(TEXTURE_ID);
                  }

                  texture = new MenuShader.MenuTexture(target.getColorTexture(), target.getColorTextureView());
                  mc.getTextureManager().register(TEXTURE_ID, texture);
               }
            } catch (Throwable var6) {
            }
         }
      }
   }

   private static void writeUniforms(float alpha, float transitionProgress) {
      if (chain != null) {
         for (PostPass pass : ((PostEffectProcessorAccessor)chain).getPasses()) {
            Map<String, GpuBuffer> uniforms = ((PostPassAccessor)pass).night$getCustomUniforms();
            if (uniforms.containsKey("MenuBgConfig")) {
               if (uboBuffer == null || uniforms.get("MenuBgConfig") != uboBuffer) {
                  uboBuffer = RenderSystem.getDevice().createBuffer(() -> "Night Menu BG UBO", 136, UBO_SIZE);
                  GpuBuffer displaced = uniforms.put("MenuBgConfig", uboBuffer);
                  if (displaced != null) {
                     displaced.close();
                  }
               }

               float time = (float)(System.currentTimeMillis() - START_TIME) / 1000.0F;
               MemoryStack stack = MemoryStack.stackPush();

               try {
                  ByteBuffer data = Std140Builder.onStack(stack, UBO_SIZE).putVec4(time, alpha, transitionProgress, 0.0F).get();
                  RenderSystem.getDevice().createCommandEncoder().writeToBuffer(uboBuffer.slice(), data);
               } catch (Throwable var10) {
                  if (stack != null) {
                     try {
                        stack.close();
                     } catch (Throwable var9) {
                        var10.addSuppressed(var9);
                     }
                  }

                  throw var10;
               }

               if (stack != null) {
                  stack.close();
               }
            }
         }
      }
   }

   public static void render(GuiGraphicsExtractor context, int screenW, int screenH, float alpha, float transitionProgress) {
      render(context, screenW, screenH, alpha, transitionProgress, true);
   }

   public static void render(GuiGraphicsExtractor context, int screenW, int screenH, float alpha, float transitionProgress, boolean resourcesReady) {
      try {
         ensureProcessed(alpha, transitionProgress, resourcesReady);
         int a = Math.min(255, Math.max(0, Math.round(alpha * 255.0F)));
         int colorMask = a << 24 | 16777215;
         if (texture != null) {
            context.blit(RenderPipelines.GUI_TEXTURED, TEXTURE_ID, 0, 0, 0.0F, 0.0F, screenW, screenH, screenW, screenH, screenW, screenH, colorMask);
         } else {
            context.blit(RenderPipelines.GUI_TEXTURED, STATIC_BG, 0, 0, 0.0F, 0.0F, screenW, screenH, screenW, screenH, screenW, screenH, colorMask);
         }
      } catch (Throwable var8) {
         Renderer2D.renderQuad(context, 0.0F, 0.0F, screenW, screenH, new Color(8, 8, 12, (int)(255.0F * alpha)));
      }
   }

   public static void render(GuiGraphicsExtractor context, int screenW, int screenH, float alpha) {
      render(context, screenW, screenH, alpha, 1.0F);
   }

   private static class MenuTexture extends AbstractTexture {
      MenuTexture(GpuTexture texture, GpuTextureView view) {
         this.texture = texture;
         this.textureView = view;
      }

      boolean wraps(GpuTextureView view) {
         return this.textureView == view;
      }

      public void close() {
      }
   }
}
