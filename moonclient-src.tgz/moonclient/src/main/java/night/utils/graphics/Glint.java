package night.utils.graphics;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.DepthStencilState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.BlendFactor;
import com.mojang.blaze3d.platform.CompareOp;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import night.mixins.accessors.RenderPipelinesAccessor;
import org.joml.Matrix4f;

public class Glint {
   private static final Identifier GLINT_TEXTURE = Identifier.fromNamespaceAndPath("night", "textures/glint.png");
   private static final RenderType NO_DEPTH_GLINT_QUADS = RenderType.create(
      "night_no_depth_glint",
      RenderSetup.builder(
            RenderPipeline.builder(new Snippet[]{RenderPipelinesAccessor.getGuiTexturedSnippet()})
               .withLocation("night/no_depth_glint")
               .withCull(false)
               .withDepthStencilState(new DepthStencilState(CompareOp.ALWAYS_PASS, false))
               .withColorTargetState(new ColorTargetState(new BlendFunction(BlendFactor.SRC_ALPHA, BlendFactor.ONE)))
               .build()
         )
         .withTexture("Sampler0", GLINT_TEXTURE)
         .sortOnUpload()
         .createRenderSetup()
   );
   public static List<Glint.TexturedVertexCollection> QUADS = new ArrayList<>();
   public static final Glint.GlintParams ENTITY = new Glint.GlintParams();
   public static final Glint.GlintParams CRYSTAL = new Glint.GlintParams();
   private static long lastMs = 0L;

   public static void tick() {
      long nowMs = System.currentTimeMillis();
      if (lastMs == 0L) {
         lastMs = nowMs;
      }

      float delta = (float)(nowMs - lastMs) / 1000.0F;
      lastMs = nowMs;
      ENTITY.tick(delta);
      CRYSTAL.tick(delta);
   }

   public static void draw() {
      if (!QUADS.isEmpty()) {
         int vertexCount = 0;

         for (Glint.TexturedVertexCollection collection : QUADS) {
            vertexCount += collection.vertices().length;
         }

         ByteBufferBuilder byteBufferBuilder = ByteBufferBuilder.exactlySized(vertexCount * DefaultVertexFormat.POSITION_TEX_COLOR.getVertexSize());

         try {
            BufferBuilder buffer = new BufferBuilder(byteBufferBuilder, PrimitiveTopology.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);

            for (Glint.TexturedVertexCollection collection : QUADS) {
               collection.vertex(buffer);
            }

            MeshData mesh = buffer.build();
            Renderer3D.draw(NO_DEPTH_GLINT_QUADS, mesh);
         } catch (Throwable var6) {
            if (byteBufferBuilder != null) {
               try {
                  byteBufferBuilder.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (byteBufferBuilder != null) {
            byteBufferBuilder.close();
         }

         QUADS.clear();
      }
   }

   public static class GlintParams {
      public float speedU = 0.25F;
      public float speedV = 0.1F;
      public float scale = 1.0F;
      public String direction = "Diagonal";
      public float scrollU = 0.0F;
      public float scrollV = 0.0F;

      public void tick(float delta) {
         this.scrollU = (this.scrollU + this.speedU * delta) % 1.0F;
         this.scrollV = (this.scrollV + this.speedV * delta) % 1.0F;
         if (this.scrollU < 0.0F) {
            this.scrollU++;
         }

         if (this.scrollV < 0.0F) {
            this.scrollV++;
         }
      }

      public float[] getGlintUV(float x, float y, float z) {
         float s = this.scale * 0.06F;
         String var7 = this.direction;
         float u;
         float v;
         switch (var7) {
            case "Horizontal":
               u = (x + z * 0.5F) * s;
               v = y * s;
               break;
            case "Vertical":
               u = y * s;
               v = (x + z * 0.5F) * s;
               break;
            default:
               u = x * s + z * s * 0.5F;
               v = y * s + z * s * 0.5F;
         }

         u += this.scrollU;
         v += this.scrollV;
         return new float[]{u, v};
      }
   }

   public record TexturedVertex(Matrix4f matrix, float x, float y, float z, float u, float v, int color) {
   }

   public record TexturedVertexCollection(Glint.TexturedVertex... vertices) {
      public void vertex(BufferBuilder buffer) {
         for (Glint.TexturedVertex vertex : this.vertices) {
            buffer.addVertex(vertex.matrix, vertex.x, vertex.y, vertex.z).setUv(vertex.u, vertex.v).setColor(vertex.color);
         }
      }
   }
}
