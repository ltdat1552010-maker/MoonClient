package night.utils.input;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.glfw.GLFW;

public class KeyboardUtils {
   public static String getKeyName(int key) {
      return switch (key) {
         case -5 -> "Button 4";
         case -4 -> "Button 3";
         case -3 -> "Middle Click";
         case -2 -> "Right Click";
         case -1 -> "Unknown";
         case 0 -> "None";
         case 32 -> "Space";
         case 39 -> "Apostrophe";
         case 96 -> "Grave Accent";
         case 161 -> "World 1";
         case 162 -> "World 2";
         case 256 -> "Esc";
         case 257 -> "Enter";
         case 258 -> "Tab";
         case 259 -> "Backspace";
         case 260 -> "Insert";
         case 261 -> "Delete";
         case 262 -> "Arrow Right";
         case 263 -> "Arrow Left";
         case 264 -> "Arrow Down";
         case 265 -> "Arrow Up";
         case 266 -> "Page Up";
         case 267 -> "Page Down";
         case 268 -> "Home";
         case 269 -> "End";
         case 280 -> "Caps Lock";
         case 282 -> "Num Lock";
         case 283 -> "Print Screen";
         case 284 -> "Pause";
         case 290 -> "F1";
         case 291 -> "F2";
         case 292 -> "F3";
         case 293 -> "F4";
         case 294 -> "F5";
         case 295 -> "F6";
         case 296 -> "F7";
         case 297 -> "F8";
         case 298 -> "F9";
         case 299 -> "F10";
         case 300 -> "F11";
         case 301 -> "F12";
         case 302 -> "F13";
         case 303 -> "F14";
         case 304 -> "F15";
         case 305 -> "F16";
         case 306 -> "F17";
         case 307 -> "F18";
         case 308 -> "F19";
         case 309 -> "F20";
         case 310 -> "F21";
         case 311 -> "F22";
         case 312 -> "F23";
         case 313 -> "F24";
         case 314 -> "F25";
         case 335 -> "Numpad Enter";
         case 340 -> "Left Shift";
         case 341 -> "Left Control";
         case 342 -> "Left Alt";
         case 343 -> "Left Super";
         case 344 -> "Right Shift";
         case 345 -> "Right Control";
         case 346 -> "Right Alt";
         case 347 -> "Right Super";
         case 348 -> "Menu";
         default -> {
            String keyName = GLFW.glfwGetKeyName(key, 0);
            yield keyName == null ? "Unknown" : StringUtils.capitalize(keyName);
         }
      };
   }

   public static int getKeyNumber(String name) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.OutOfMemoryError: Java heap space
      //   at java.base/java.util.Arrays.copyOf(Arrays.java:3541)
      //   at java.base/java.lang.AbstractStringBuilder.ensureCapacityInternal(AbstractStringBuilder.java:242)
      //   at java.base/java.lang.AbstractStringBuilder.append(AbstractStringBuilder.java:587)
      //   at java.base/java.lang.StringBuilder.append(StringBuilder.java:179)
      //   at org.jetbrains.java.decompiler.util.TextBuffer.append(TextBuffer.java:64)
      //   at org.jetbrains.java.decompiler.util.TextBuffer.appendIndent(TextBuffer.java:85)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.SwitchExprent.toJava(SwitchExprent.java:82)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:1014)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement.toJava(CatchStatement.java:191)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.SwitchExprent.toJava(SwitchExprent.java:167)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:1014)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement.toJava(CatchStatement.java:191)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.SwitchExprent.toJava(SwitchExprent.java:167)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:1014)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement.toJava(CatchStatement.java:191)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //
      // Bytecode:
      // 000: aload 0
      // 001: invokevirtual java/lang/String.toLowerCase ()Ljava/lang/String;
      // 004: astore 1
      // 005: bipush -1
      // 006: istore 2
      // 007: aload 1
      // 008: invokevirtual java/lang/String.hashCode ()I
      // 00b: lookupswitch 1464 63 -2000208463 972 -1883398382 957 -1335458389 612 -1183792455 597 -1093611626 762 -1093217649 912 -1079639749 1403 -990290151 657 -979651536 569 -936493994 1387 -921836720 777 -921442743 927 -782084385 541 -782084384 555 -50927732 882 3211 1002 3212 1017 3213 1032 3214 1047 3215 1062 3216 1077 3217 1092 3218 1107 3219 1122 3739 792 99589 1137 99590 1152 99591 1167 99592 1182 99593 1197 99594 1212 99595 1227 99596 1243 99597 1259 99598 1275 99620 1291 99621 1307 99622 1323 99623 1339 99624 1355 99625 1371 100571 672 100725 513 114581 687 3089570 807 3208415 627 3314109 732 3317767 822 3347807 897 3387192 1451 3439314 642 3492855 747 96667352 942 98615813 527 102804695 702 106440182 583 108345821 717 108511772 837 109637894 987 138429999 852 241352513 1419 241352514 1435 1353507967 867
      // 20c: aload 1
      // 20d: ldc "esc"
      // 20f: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 212: ifeq 5c3
      // 215: bipush 0
      // 216: istore 2
      // 217: goto 5c3
      // 21a: aload 1
      // 21b: ldc "grave"
      // 21d: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 220: ifeq 5c3
      // 223: bipush 1
      // 224: istore 2
      // 225: goto 5c3
      // 228: aload 1
      // 229: ldc "world1"
      // 22b: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 22e: ifeq 5c3
      // 231: bipush 2
      // 232: istore 2
      // 233: goto 5c3
      // 236: aload 1
      // 237: ldc "world2"
      // 239: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 23c: ifeq 5c3
      // 23f: bipush 3
      // 240: istore 2
      // 241: goto 5c3
      // 244: aload 1
      // 245: ldc "prtscr"
      // 247: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 24a: ifeq 5c3
      // 24d: bipush 4
      // 24e: istore 2
      // 24f: goto 5c3
      // 252: aload 1
      // 253: ldc "pause"
      // 255: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 258: ifeq 5c3
      // 25b: bipush 5
      // 25c: istore 2
      // 25d: goto 5c3
      // 260: aload 1
      // 261: ldc "insert"
      // 263: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 266: ifeq 5c3
      // 269: bipush 6
      // 26b: istore 2
      // 26c: goto 5c3
      // 26f: aload 1
      // 270: ldc "delete"
      // 272: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 275: ifeq 5c3
      // 278: bipush 7
      // 27a: istore 2
      // 27b: goto 5c3
      // 27e: aload 1
      // 27f: ldc "home"
      // 281: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 284: ifeq 5c3
      // 287: bipush 8
      // 289: istore 2
      // 28a: goto 5c3
      // 28d: aload 1
      // 28e: ldc "pgup"
      // 290: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 293: ifeq 5c3
      // 296: bipush 9
      // 298: istore 2
      // 299: goto 5c3
      // 29c: aload 1
      // 29d: ldc "pgdown"
      // 29f: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 2a2: ifeq 5c3
      // 2a5: bipush 10
      // 2a7: istore 2
      // 2a8: goto 5c3
      // 2ab: aload 1
      // 2ac: ldc "end"
      // 2ae: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 2b1: ifeq 5c3
      // 2b4: bipush 11
      // 2b6: istore 2
      // 2b7: goto 5c3
      // 2ba: aload 1
      // 2bb: ldc "tab"
      // 2bd: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 2c0: ifeq 5c3
      // 2c3: bipush 12
      // 2c5: istore 2
      // 2c6: goto 5c3
      // 2c9: aload 1
      // 2ca: ldc "lctrl"
      // 2cc: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 2cf: ifeq 5c3
      // 2d2: bipush 13
      // 2d4: istore 2
      // 2d5: goto 5c3
      // 2d8: aload 1
      // 2d9: ldc "rctrl"
      // 2db: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 2de: ifeq 5c3
      // 2e1: bipush 14
      // 2e3: istore 2
      // 2e4: goto 5c3
      // 2e7: aload 1
      // 2e8: ldc "lalt"
      // 2ea: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 2ed: ifeq 5c3
      // 2f0: bipush 15
      // 2f2: istore 2
      // 2f3: goto 5c3
      // 2f6: aload 1
      // 2f7: ldc "ralt"
      // 2f9: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 2fc: ifeq 5c3
      // 2ff: bipush 16
      // 301: istore 2
      // 302: goto 5c3
      // 305: aload 1
      // 306: ldc "lshift"
      // 308: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 30b: ifeq 5c3
      // 30e: bipush 17
      // 310: istore 2
      // 311: goto 5c3
      // 314: aload 1
      // 315: ldc "rshift"
      // 317: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 31a: ifeq 5c3
      // 31d: bipush 18
      // 31f: istore 2
      // 320: goto 5c3
      // 323: aload 1
      // 324: ldc "up"
      // 326: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 329: ifeq 5c3
      // 32c: bipush 19
      // 32e: istore 2
      // 32f: goto 5c3
      // 332: aload 1
      // 333: ldc "down"
      // 335: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 338: ifeq 5c3
      // 33b: bipush 20
      // 33d: istore 2
      // 33e: goto 5c3
      // 341: aload 1
      // 342: ldc "left"
      // 344: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 347: ifeq 5c3
      // 34a: bipush 21
      // 34c: istore 2
      // 34d: goto 5c3
      // 350: aload 1
      // 351: ldc "right"
      // 353: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 356: ifeq 5c3
      // 359: bipush 22
      // 35b: istore 2
      // 35c: goto 5c3
      // 35f: aload 1
      // 360: ldc "apostrophe"
      // 362: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 365: ifeq 5c3
      // 368: bipush 23
      // 36a: istore 2
      // 36b: goto 5c3
      // 36e: aload 1
      // 36f: ldc "backspace"
      // 371: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 374: ifeq 5c3
      // 377: bipush 24
      // 379: istore 2
      // 37a: goto 5c3
      // 37d: aload 1
      // 37e: ldc "capslock"
      // 380: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 383: ifeq 5c3
      // 386: bipush 25
      // 388: istore 2
      // 389: goto 5c3
      // 38c: aload 1
      // 38d: ldc "menu"
      // 38f: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 392: ifeq 5c3
      // 395: bipush 26
      // 397: istore 2
      // 398: goto 5c3
      // 39b: aload 1
      // 39c: ldc "lsuper"
      // 39e: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 3a1: ifeq 5c3
      // 3a4: bipush 27
      // 3a6: istore 2
      // 3a7: goto 5c3
      // 3aa: aload 1
      // 3ab: ldc "rsuper"
      // 3ad: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 3b0: ifeq 5c3
      // 3b3: bipush 28
      // 3b5: istore 2
      // 3b6: goto 5c3
      // 3b9: aload 1
      // 3ba: ldc "enter"
      // 3bc: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 3bf: ifeq 5c3
      // 3c2: bipush 29
      // 3c4: istore 2
      // 3c5: goto 5c3
      // 3c8: aload 1
      // 3c9: ldc "numenter"
      // 3cb: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 3ce: ifeq 5c3
      // 3d1: bipush 30
      // 3d3: istore 2
      // 3d4: goto 5c3
      // 3d7: aload 1
      // 3d8: ldc "numlock"
      // 3da: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 3dd: ifeq 5c3
      // 3e0: bipush 31
      // 3e2: istore 2
      // 3e3: goto 5c3
      // 3e6: aload 1
      // 3e7: ldc "space"
      // 3e9: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 3ec: ifeq 5c3
      // 3ef: bipush 32
      // 3f1: istore 2
      // 3f2: goto 5c3
      // 3f5: aload 1
      // 3f6: ldc "f1"
      // 3f8: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 3fb: ifeq 5c3
      // 3fe: bipush 33
      // 400: istore 2
      // 401: goto 5c3
      // 404: aload 1
      // 405: ldc "f2"
      // 407: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 40a: ifeq 5c3
      // 40d: bipush 34
      // 40f: istore 2
      // 410: goto 5c3
      // 413: aload 1
      // 414: ldc "f3"
      // 416: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 419: ifeq 5c3
      // 41c: bipush 35
      // 41e: istore 2
      // 41f: goto 5c3
      // 422: aload 1
      // 423: ldc "f4"
      // 425: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 428: ifeq 5c3
      // 42b: bipush 36
      // 42d: istore 2
      // 42e: goto 5c3
      // 431: aload 1
      // 432: ldc "f5"
      // 434: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 437: ifeq 5c3
      // 43a: bipush 37
      // 43c: istore 2
      // 43d: goto 5c3
      // 440: aload 1
      // 441: ldc "f6"
      // 443: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 446: ifeq 5c3
      // 449: bipush 38
      // 44b: istore 2
      // 44c: goto 5c3
      // 44f: aload 1
      // 450: ldc "f7"
      // 452: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 455: ifeq 5c3
      // 458: bipush 39
      // 45a: istore 2
      // 45b: goto 5c3
      // 45e: aload 1
      // 45f: ldc "f8"
      // 461: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 464: ifeq 5c3
      // 467: bipush 40
      // 469: istore 2
      // 46a: goto 5c3
      // 46d: aload 1
      // 46e: ldc "f9"
      // 470: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 473: ifeq 5c3
      // 476: bipush 41
      // 478: istore 2
      // 479: goto 5c3
      // 47c: aload 1
      // 47d: ldc "f10"
      // 47f: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 482: ifeq 5c3
      // 485: bipush 42
      // 487: istore 2
      // 488: goto 5c3
      // 48b: aload 1
      // 48c: ldc "f11"
      // 48e: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 491: ifeq 5c3
      // 494: bipush 43
      // 496: istore 2
      // 497: goto 5c3
      // 49a: aload 1
      // 49b: ldc "f12"
      // 49d: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 4a0: ifeq 5c3
      // 4a3: bipush 44
      // 4a5: istore 2
      // 4a6: goto 5c3
      // 4a9: aload 1
      // 4aa: ldc "f13"
      // 4ac: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 4af: ifeq 5c3
      // 4b2: bipush 45
      // 4b4: istore 2
      // 4b5: goto 5c3
      // 4b8: aload 1
      // 4b9: ldc "f14"
      // 4bb: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 4be: ifeq 5c3
      // 4c1: bipush 46
      // 4c3: istore 2
      // 4c4: goto 5c3
      // 4c7: aload 1
      // 4c8: ldc "f15"
      // 4ca: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 4cd: ifeq 5c3
      // 4d0: bipush 47
      // 4d2: istore 2
      // 4d3: goto 5c3
      // 4d6: aload 1
      // 4d7: ldc_w "f16"
      // 4da: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 4dd: ifeq 5c3
      // 4e0: bipush 48
      // 4e2: istore 2
      // 4e3: goto 5c3
      // 4e6: aload 1
      // 4e7: ldc_w "f17"
      // 4ea: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 4ed: ifeq 5c3
      // 4f0: bipush 49
      // 4f2: istore 2
      // 4f3: goto 5c3
      // 4f6: aload 1
      // 4f7: ldc_w "f18"
      // 4fa: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 4fd: ifeq 5c3
      // 500: bipush 50
      // 502: istore 2
      // 503: goto 5c3
      // 506: aload 1
      // 507: ldc_w "f19"
      // 50a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 50d: ifeq 5c3
      // 510: bipush 51
      // 512: istore 2
      // 513: goto 5c3
      // 516: aload 1
      // 517: ldc_w "f20"
      // 51a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 51d: ifeq 5c3
      // 520: bipush 52
      // 522: istore 2
      // 523: goto 5c3
      // 526: aload 1
      // 527: ldc_w "f21"
      // 52a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 52d: ifeq 5c3
      // 530: bipush 53
      // 532: istore 2
      // 533: goto 5c3
      // 536: aload 1
      // 537: ldc_w "f22"
      // 53a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 53d: ifeq 5c3
      // 540: bipush 54
      // 542: istore 2
      // 543: goto 5c3
      // 546: aload 1
      // 547: ldc_w "f23"
      // 54a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 54d: ifeq 5c3
      // 550: bipush 55
      // 552: istore 2
      // 553: goto 5c3
      // 556: aload 1
      // 557: ldc_w "f24"
      // 55a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 55d: ifeq 5c3
      // 560: bipush 56
      // 562: istore 2
      // 563: goto 5c3
      // 566: aload 1
      // 567: ldc_w "f25"
      // 56a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 56d: ifeq 5c3
      // 570: bipush 57
      // 572: istore 2
      // 573: goto 5c3
      // 576: aload 1
      // 577: ldc_w "rclick"
      // 57a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 57d: ifeq 5c3
      // 580: bipush 58
      // 582: istore 2
      // 583: goto 5c3
      // 586: aload 1
      // 587: ldc_w "mclick"
      // 58a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 58d: ifeq 5c3
      // 590: bipush 59
      // 592: istore 2
      // 593: goto 5c3
      // 596: aload 1
      // 597: ldc_w "button3"
      // 59a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 59d: ifeq 5c3
      // 5a0: bipush 60
      // 5a2: istore 2
      // 5a3: goto 5c3
      // 5a6: aload 1
      // 5a7: ldc_w "button4"
      // 5aa: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 5ad: ifeq 5c3
      // 5b0: bipush 61
      // 5b2: istore 2
      // 5b3: goto 5c3
      // 5b6: aload 1
      // 5b7: ldc_w "none"
      // 5ba: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 5bd: ifeq 5c3
      // 5c0: bipush 62
      // 5c2: istore 2
      // 5c3: iload 2
      // 5c4: tableswitch 763 0 62 268 276 283 291 299 307 315 323 331 339 347 355 363 371 379 387 395 403 411 419 427 435 443 451 458 466 474 482 490 498 506 514 522 529 537 545 553 561 569 577 585 593 601 609 617 625 633 641 649 657 665 673 681 689 697 705 713 721 729 736 743 750 757
      // 6d0: sipush 256
      // 6d3: istore 3
      // 6d4: iload 3
      // 6d5: goto 8d8
      // 6d8: bipush 96
      // 6da: istore 3
      // 6db: iload 3
      // 6dc: goto 8d8
      // 6df: sipush 161
      // 6e2: istore 3
      // 6e3: iload 3
      // 6e4: goto 8d8
      // 6e7: sipush 162
      // 6ea: istore 3
      // 6eb: iload 3
      // 6ec: goto 8d8
      // 6ef: sipush 283
      // 6f2: istore 3
      // 6f3: iload 3
      // 6f4: goto 8d8
      // 6f7: sipush 284
      // 6fa: istore 3
      // 6fb: iload 3
      // 6fc: goto 8d8
      // 6ff: sipush 260
      // 702: istore 3
      // 703: iload 3
      // 704: goto 8d8
      // 707: sipush 261
      // 70a: istore 3
      // 70b: iload 3
      // 70c: goto 8d8
      // 70f: sipush 268
      // 712: istore 3
      // 713: iload 3
      // 714: goto 8d8
      // 717: sipush 266
      // 71a: istore 3
      // 71b: iload 3
      // 71c: goto 8d8
      // 71f: sipush 267
      // 722: istore 3
      // 723: iload 3
      // 724: goto 8d8
      // 727: sipush 269
      // 72a: istore 3
      // 72b: iload 3
      // 72c: goto 8d8
      // 72f: sipush 258
      // 732: istore 3
      // 733: iload 3
      // 734: goto 8d8
      // 737: sipush 341
      // 73a: istore 3
      // 73b: iload 3
      // 73c: goto 8d8
      // 73f: sipush 345
      // 742: istore 3
      // 743: iload 3
      // 744: goto 8d8
      // 747: sipush 342
      // 74a: istore 3
      // 74b: iload 3
      // 74c: goto 8d8
      // 74f: sipush 346
      // 752: istore 3
      // 753: iload 3
      // 754: goto 8d8
      // 757: sipush 340
      // 75a: istore 3
      // 75b: iload 3
      // 75c: goto 8d8
      // 75f: sipush 344
      // 762: istore 3
      // 763: iload 3
      // 764: goto 8d8
      // 767: sipush 265
      // 76a: istore 3
      // 76b: iload 3
      // 76c: goto 8d8
      // 76f: sipush 264
      // 772: istore 3
      // 773: iload 3
      // 774: goto 8d8
      // 777: sipush 263
      // 77a: istore 3
      // 77b: iload 3
      // 77c: goto 8d8
      // 77f: sipush 262
      // 782: istore 3
      // 783: iload 3
      // 784: goto 8d8
      // 787: bipush 39
      // 789: istore 3
      // 78a: iload 3
      // 78b: goto 8d8
      // 78e: sipush 259
      // 791: istore 3
      // 792: iload 3
      // 793: goto 8d8
      // 796: sipush 280
      // 799: istore 3
      // 79a: iload 3
      // 79b: goto 8d8
      // 79e: sipush 348
      // 7a1: istore 3
      // 7a2: iload 3
      // 7a3: goto 8d8
      // 7a6: sipush 343
      // 7a9: istore 3
      // 7aa: iload 3
      // 7ab: goto 8d8
      // 7ae: sipush 347
      // 7b1: istore 3
      // 7b2: iload 3
      // 7b3: goto 8d8
      // 7b6: sipush 257
      // 7b9: istore 3
      // 7ba: iload 3
      // 7bb: goto 8d8
      // 7be: sipush 335
      // 7c1: istore 3
      // 7c2: iload 3
      // 7c3: goto 8d8
      // 7c6: sipush 282
      // 7c9: istore 3
      // 7ca: iload 3
      // 7cb: goto 8d8
      // 7ce: bipush 32
      // 7d0: istore 3
      // 7d1: iload 3
      // 7d2: goto 8d8
      // 7d5: sipush 290
      // 7d8: istore 3
      // 7d9: iload 3
      // 7da: goto 8d8
      // 7dd: sipush 291
      // 7e0: istore 3
      // 7e1: iload 3
      // 7e2: goto 8d8
      // 7e5: sipush 292
      // 7e8: istore 3
      // 7e9: iload 3
      // 7ea: goto 8d8
      // 7ed: sipush 293
      // 7f0: istore 3
      // 7f1: iload 3
      // 7f2: goto 8d8
      // 7f5: sipush 294
      // 7f8: istore 3
      // 7f9: iload 3
      // 7fa: goto 8d8
      // 7fd: sipush 295
      // 800: istore 3
      // 801: iload 3
      // 802: goto 8d8
      // 805: sipush 296
      // 808: istore 3
      // 809: iload 3
      // 80a: goto 8d8
      // 80d: sipush 297
      // 810: istore 3
      // 811: iload 3
      // 812: goto 8d8
      // 815: sipush 298
      // 818: istore 3
      // 819: iload 3
      // 81a: goto 8d8
      // 81d: sipush 299
      // 820: istore 3
      // 821: iload 3
      // 822: goto 8d8
      // 825: sipush 300
      // 828: istore 3
      // 829: iload 3
      // 82a: goto 8d8
      // 82d: sipush 301
      // 830: istore 3
      // 831: iload 3
      // 832: goto 8d8
      // 835: sipush 302
      // 838: istore 3
      // 839: iload 3
      // 83a: goto 8d8
      // 83d: sipush 303
      // 840: istore 3
      // 841: iload 3
      // 842: goto 8d8
      // 845: sipush 304
      // 848: istore 3
      // 849: iload 3
      // 84a: goto 8d8
      // 84d: sipush 305
      // 850: istore 3
      // 851: iload 3
      // 852: goto 8d8
      // 855: sipush 306
      // 858: istore 3
      // 859: iload 3
      // 85a: goto 8d8
      // 85d: sipush 307
      // 860: istore 3
      // 861: iload 3
      // 862: goto 8d8
      // 865: sipush 308
      // 868: istore 3
      // 869: iload 3
      // 86a: goto 8d8
      // 86d: sipush 309
      // 870: istore 3
      // 871: iload 3
      // 872: goto 8d8
      // 875: sipush 310
      // 878: istore 3
      // 879: iload 3
      // 87a: goto 8d8
      // 87d: sipush 311
      // 880: istore 3
      // 881: iload 3
      // 882: goto 8d8
      // 885: sipush 312
      // 888: istore 3
      // 889: iload 3
      // 88a: goto 8d8
      // 88d: sipush 313
      // 890: istore 3
      // 891: iload 3
      // 892: goto 8d8
      // 895: sipush 314
      // 898: istore 3
      // 899: iload 3
      // 89a: goto 8d8
      // 89d: bipush -2
      // 89f: istore 3
      // 8a0: iload 3
      // 8a1: goto 8d8
      // 8a4: bipush -3
      // 8a6: istore 3
      // 8a7: iload 3
      // 8a8: goto 8d8
      // 8ab: bipush -4
      // 8ad: istore 3
      // 8ae: iload 3
      // 8af: goto 8d8
      // 8b2: bipush -5
      // 8b4: istore 3
      // 8b5: iload 3
      // 8b6: goto 8d8
      // 8b9: bipush 0
      // 8ba: istore 3
      // 8bb: iload 3
      // 8bc: goto 8d8
      // 8bf: aload 0
      // 8c0: invokedynamic makeConcatWithConstants (Ljava/lang/String;)Ljava/lang/String; bsm=java/lang/invoke/StringConcatFactory.makeConcatWithConstants (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/invoke/CallSite; args=[ "key.keyboard.\u0001" ]
      // 8c5: invokestatic com/mojang/blaze3d/platform/InputConstants.getKey (Ljava/lang/String;)Lcom/mojang/blaze3d/platform/InputConstants$Key;
      // 8c8: invokevirtual com/mojang/blaze3d/platform/InputConstants$Key.getValue ()I
      // 8cb: istore 3
      // 8cc: iload 3
      // 8cd: goto 8d8
      // 8d0: astore 4
      // 8d2: bipush 0
      // 8d3: istore 3
      // 8d4: iload 3
      // 8d5: goto 8d8
      // 8d8: ireturn
   }

   public static boolean isBindDown(int bind) {
      if (bind == 0) {
         return false;
      } else {
         Minecraft mc = Minecraft.getInstance();
         if (mc.gui != null && mc.gui.screen() != null) {
            return false;
         } else if (mc.getWindow() == null) {
            return false;
         } else if (bind >= 0) {
            return InputConstants.isKeyDown(mc.getWindow(), bind);
         } else {
            int button = -bind - 1;
            return GLFW.glfwGetMouseButton(mc.getWindow().handle(), button) == 1;
         }
      }
   }
}
