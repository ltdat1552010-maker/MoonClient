package night.utils.animations;

import net.minecraft.util.Mth;

public class Easing {
   public static float ease(float x, Easing.Method method) {
      return switch (method) {
         case EASE_IN_SINE -> easeInSine(x);
         case EASE_OUT_SINE -> easeOutSine(x);
         case EASE_IN_CUBIC -> easeInCubic(x);
         case EASE_OUT_CUBIC -> easeOutCubic(x);
         case EASE_IN_QUAD -> easeInQuad(x);
         case EASE_OUT_QUAD -> easeOutQuad(x);
         case EASE_IN_QUART -> easeInQuart(x);
         case EASE_OUT_QUART -> easeOutQuart(x);
         case EASE_IN_OUT_SINE -> easeInOutSine(x);
         case EASE_IN_OUT_QUAD -> easeInOutQuad(x);
         case EASE_IN_OUT_CUBIC -> easeInOutCubic(x);
         case EASE_IN_OUT_QUART -> easeInOutQuart(x);
         case EASE_IN_ELASTIC -> easeInElastic(x);
         case EASE_OUT_ELASTIC -> easeOutElastic(x);
         case EASE_IN_OUT_ELASTIC -> easeInOutElastic(x);
         default -> linear(x);
      };
   }

   public static float toDelta(long start, int length) {
      return Mth.clamp((float)toDelta(start) / length, 0.0F, 1.0F);
   }

   public static long toDelta(long start) {
      return System.currentTimeMillis() - start;
   }

   private static float linear(float x) {
      return x;
   }

   private static float easeInSine(float x) {
      return (float)(1.0 - Math.cos(x * Math.PI / 2.0));
   }

   private static float easeOutSine(float x) {
      return (float)Math.sin(x * Math.PI / 2.0);
   }

   private static float easeInCubic(float x) {
      return x * x * x;
   }

   private static float easeOutCubic(float x) {
      return (float)(1.0 - Math.pow(1.0F - x, 3.0));
   }

   private static float easeInQuad(float x) {
      return x * x;
   }

   private static float easeOutQuad(float x) {
      return 1.0F - (1.0F - x) * (1.0F - x);
   }

   private static float easeInQuart(float x) {
      return x * x * x * x;
   }

   private static float easeOutQuart(float x) {
      return (float)(1.0 - Math.pow(1.0F - x, 4.0));
   }

   private static float easeInOutSine(float x) {
      return (float)(-(Math.cos(Math.PI * x) - 1.0) / 2.0);
   }

   private static float easeInOutQuad(float x) {
      return x < 0.5F ? 2.0F * x * x : (float)(1.0 - Math.pow(-2.0F * x + 2.0F, 2.0) / 2.0);
   }

   private static float easeInOutCubic(float x) {
      return x < 0.5F ? 4.0F * x * x * x : (float)(1.0 - Math.pow(-2.0F * x + 2.0F, 3.0) / 2.0);
   }

   private static float easeInOutQuart(float x) {
      return x < 0.5F ? 8.0F * x * x * x * x : (float)(1.0 - Math.pow(-2.0F * x + 2.0F, 4.0) / 2.0);
   }

   private static float easeInElastic(float x) {
      float c4 = (float) (Math.PI * 2.0 / 3.0);
      return x == 0.0F ? 0.0F : (float)(x == 1.0F ? 1.0 : -Math.pow(2.0, 10.0F * x - 10.0F) * Math.sin((x * 10.0F - 10.75) * c4));
   }

   private static float easeOutElastic(float x) {
      float c4 = (float) (Math.PI * 2.0 / 3.0);
      return x == 0.0F ? 0.0F : (float)(x == 1.0F ? 1.0 : Math.pow(2.0, -10.0F * x) * Math.sin((x * 10.0F - 0.75) * c4) + 1.0);
   }

   private static float easeInOutElastic(float x) {
      float c5 = (float) Math.PI * 4.0F / 9.0F;
      return x == 0.0F
         ? 0.0F
         : (float)(
            x == 1.0F
               ? 1.0
               : (
                  x < 0.5
                     ? -(Math.pow(2.0, 20.0F * x - 10.0F) * Math.sin((20.0F * x - 11.125) * c5)) / 2.0
                     : Math.pow(2.0, -20.0F * x + 10.0F) * Math.sin((20.0F * x - 11.125) * c5) / 2.0 + 1.0
               )
         );
   }

   public static enum Method {
      LINEAR,
      EASE_IN_SINE,
      EASE_OUT_SINE,
      EASE_IN_CUBIC,
      EASE_OUT_CUBIC,
      EASE_IN_QUAD,
      EASE_OUT_QUAD,
      EASE_IN_QUART,
      EASE_OUT_QUART,
      EASE_IN_OUT_SINE,
      EASE_IN_OUT_QUAD,
      EASE_IN_OUT_CUBIC,
      EASE_IN_OUT_QUART,
      EASE_IN_ELASTIC,
      EASE_OUT_ELASTIC,
      EASE_IN_OUT_ELASTIC;
   }
}
