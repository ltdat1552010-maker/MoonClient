package night.utils.animations;

import lombok.Generated;
import net.minecraft.util.Mth;

public class Animation {
   private static final int MIN_DURATION_MS = 40;
   private float current;
   private float prev;
   private long startTime;
   private Easing.Method easing;
   private final int duration;
   private int activeDuration;

   public Animation(int duration, Easing.Method easing) {
      this(0.0F, 0.0F, duration, easing);
   }

   public Animation(float prev, float current, int duration, Easing.Method easing) {
      this.prev = prev;
      this.current = current;
      this.duration = duration;
      this.activeDuration = duration;
      this.easing = easing;
      this.startTime = System.currentTimeMillis();
   }

   public float value() {
      return this.activeDuration <= 0
         ? this.current
         : Mth.lerp(Easing.ease(Easing.toDelta(this.startTime, this.activeDuration), this.easing), this.prev, this.current);
   }

   public boolean isFinished() {
      return this.activeDuration <= 0 || Easing.toDelta(this.startTime, this.activeDuration) >= 1.0F;
   }

   public float get() {
      return this.value();
   }

   public float get(float target) {
      float value = this.value();
      if (this.current != target) {
         float remaining = Math.abs(target - value);
         float previousLeg = Math.abs(this.current - this.prev);
         float reference = Math.max(previousLeg, remaining);
         int scaled = reference <= 1.0E-4F ? this.duration : Math.round(this.duration * Mth.clamp(remaining / reference, 0.0F, 1.0F));
         this.prev = value;
         this.current = target;
         this.activeDuration = Math.max(40, scaled);
         this.startTime = System.currentTimeMillis();
      }

      return value;
   }

   public void setEasing(Easing.Method easing) {
      if (this.easing != easing) {
         float value = this.value();
         int elapsed = (int)Math.min(Easing.toDelta(this.startTime), 2147483647L);
         int remaining = Math.max(0, this.activeDuration - elapsed);
         this.prev = value;
         this.activeDuration = remaining;
         this.startTime = System.currentTimeMillis();
         this.easing = easing;
      }
   }

   @Generated
   public float getCurrent() {
      return this.current;
   }

   @Generated
   public float getPrev() {
      return this.prev;
   }

   @Generated
   public long getStartTime() {
      return this.startTime;
   }

   @Generated
   public Easing.Method getEasing() {
      return this.easing;
   }

   @Generated
   public int getDuration() {
      return this.duration;
   }

   @Generated
   public int getActiveDuration() {
      return this.activeDuration;
   }

   @Generated
   public void setCurrent(float current) {
      this.current = current;
   }

   @Generated
   public void setPrev(float prev) {
      this.prev = prev;
   }

   @Generated
   public void setStartTime(long startTime) {
      this.startTime = startTime;
   }

   @Generated
   public void setActiveDuration(int activeDuration) {
      this.activeDuration = activeDuration;
   }
}
