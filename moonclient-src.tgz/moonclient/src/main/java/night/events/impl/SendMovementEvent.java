package night.events.impl;

import night.events.Event;

public class SendMovementEvent extends Event {
}
