package night.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.SwingAnimation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.impl.ConsumeItemEvent;
import night.events.impl.PlayerJumpEvent;
import night.managers.RotationManager;
import night.mixins.accessors.EntityAccessor;
import night.modules.api.IFastClimbModule;
import night.modules.api.IHoleSnapModule;
import night.modules.api.INoJumpDelayModule;
import night.modules.api.ISprintModule;
import night.modules.impl.combat.AutoMaceModule;
import night.modules.impl.movement.ElytraFlyModule;
import night.modules.impl.movement.StepModule;
import night.modules.impl.player.SwingModule;
import night.utils.IMinecraft;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LivingEntity.class})
public abstract class LivingEntityMixin extends Entity implements IMinecraft {
   @Shadow
   @Final
   private static AttributeModifier SPEED_MODIFIER_SPRINTING;
   @Shadow
   private int noJumpDelay;
   @Shadow
   protected ItemStack useItem;
   @Unique
   private float night$grimYaw0;
   @Unique
   private boolean night$grimSwapped;

   @Shadow
   @Nullable
   public abstract AttributeInstance getAttribute(Holder<Attribute> var1);

   public LivingEntityMixin(EntityType<?> type, Level world) {
      super(type, world);
   }

   @WrapMethod(
      method = {"maxUpStep"}
   )
   private float getStepHeight(Operation<Float> original) {
      IHoleSnapModule holeSnap = Night.MODULE_MANAGER != null ? (IHoleSnapModule)Night.MODULE_MANAGER.getModule("HoleSnap") : null;
      return this != mc.player
            || Night.MODULE_MANAGER == null
            || (!Night.MODULE_MANAGER.getModule(StepModule.class).isToggled() || !mc.player.onGround())
               && (holeSnap == null || !holeSnap.isToggled() || !holeSnap.isStepEnabled())
         ? (Float)original.call(new Object[0])
         : Night.MODULE_MANAGER.getModule(StepModule.class).height.getValue().floatValue();
   }

   @Inject(
      method = {"aiStep"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/util/profiling/ProfilerFiller;pop()V",
         ordinal = 2,
         shift = Shift.BEFORE
      )}
   )
   private void doItemUse(CallbackInfo info) {
      INoJumpDelayModule noJumpDelayModule = Night.MODULE_MANAGER != null ? (INoJumpDelayModule)Night.MODULE_MANAGER.getModule("NoJumpDelay") : null;
      if (noJumpDelayModule != null && noJumpDelayModule.isToggled() && this.noJumpDelay == 10) {
         this.noJumpDelay = noJumpDelayModule.getTicksValue();
      }
   }

   @Inject(
      method = {"aiStep"},
      at = {@At("RETURN")}
   )
   private void night$bounceNoJumpDelay(CallbackInfo ci) {
      if (this == mc.player && Night.MODULE_MANAGER != null) {
         ElytraFlyModule ef = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class);
         if (ef != null && ef.isBounceActive()) {
            this.noJumpDelay = 0;
         }
      }
   }

   @WrapOperation(
      method = {"getCurrentSwingDuration"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/item/component/SwingAnimation;duration()I"
      )}
   )
   private int getHandSwingDuration(SwingAnimation instance, Operation<Integer> original) {
      int constant = (Integer)original.call(new Object[]{instance});
      if (this != mc.player) {
         return constant;
      } else {
         return Night.MODULE_MANAGER.getModule(SwingModule.class).isToggled()
               && Night.MODULE_MANAGER.getModule(SwingModule.class).modifySpeed.getValue()
               && mc.options.getCameraType().isFirstPerson()
            ? 21 - Night.MODULE_MANAGER.getModule(SwingModule.class).speed.getValue().intValue()
            : constant;
      }
   }

   @Inject(
      method = {"completeUsingItem"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/item/ItemStack;finishUsingItem(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack;",
         shift = Shift.AFTER
      )}
   )
   private void consumeItem(CallbackInfo ci) {
      if (this == mc.player) {
         Night.EVENT_HANDLER.post(new ConsumeItemEvent(this.useItem));
      }
   }

   @Inject(
      method = {"setSprinting"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/entity/Entity;setSprinting(Z)V",
         shift = Shift.AFTER
      )},
      cancellable = true
   )
   private void setSprinting$setSprinting(boolean sprinting, CallbackInfo info) {
      if (this == mc.player) {
         ElytraFlyModule ef = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ElytraFlyModule.class) : null;
         if (ef != null && ef.isToggled() && ef.mode.getValue().equalsIgnoreCase("Bounce")) {
            return;
         }

         ISprintModule sprint = Night.MODULE_MANAGER == null ? null : (ISprintModule)Night.MODULE_MANAGER.getModule("Sprint");
         if (sprint != null && sprint.isToggled()) {
            AttributeInstance entityAttributeInstance = this.getAttribute(Attributes.MOVEMENT_SPEED);
            if (entityAttributeInstance != null) {
               entityAttributeInstance.removeModifier(SPEED_MODIFIER_SPRINTING.id());
               if (sprint.shouldSprint()) {
                  this.setSharedFlag(3, true);
                  entityAttributeInstance.addTransientModifier(SPEED_MODIFIER_SPRINTING);
               } else {
                  this.setSharedFlag(3, false);
               }
            }

            info.cancel();
         }
      }
   }

   @Inject(
      method = {"jumpFromGround"},
      at = {@At("HEAD")}
   )
   private void jump$HEAD(CallbackInfo info) {
      if (this == mc.player) {
         Night.EVENT_HANDLER.post(new PlayerJumpEvent());
      }
   }

   @Inject(
      method = {"jumpFromGround"},
      at = {@At("RETURN")}
   )
   private void jump$RETURN(CallbackInfo info) {
      if (this == mc.player) {
         Night.EVENT_HANDLER.post(new PlayerJumpEvent.Post());
      }
   }

   @Inject(
      method = {"onClimbable"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$fastClimbIgnore(CallbackInfoReturnable<Boolean> cir) {
      if (this == mc.player) {
         IFastClimbModule fastClimb = (IFastClimbModule)Night.MODULE_MANAGER.getModule("FastClimb");
         if (fastClimb.isToggled() && fastClimb.getSpeedValue() == 0.0F) {
            cir.setReturnValue(false);
         }
      }
   }

   @ModifyConstant(
      method = {"handleOnClimbable"},
      constant = {@Constant(
         floatValue = 0.15F
      )},
      require = 0
   )
   private float night$fastClimbScale(float constant) {
      return this.night$fastClimbFactor(constant);
   }

   @Unique
   private float night$fastClimbFactor(float constant) {
      if (this != mc.player) {
         return constant;
      } else {
         IFastClimbModule fastClimb = (IFastClimbModule)Night.MODULE_MANAGER.getModule("FastClimb");
         if (!fastClimb.isToggled()) {
            return constant;
         } else {
            float factor = fastClimb.getSpeedValue();
            return !(factor <= 0.0F) && !(factor >= 1.0F) ? constant * factor : constant;
         }
      }
   }

   @Inject(
      method = {"getItemBySlot"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$hideElytraSwap(EquipmentSlot slot, CallbackInfoReturnable<ItemStack> cir) {
      if (slot == EquipmentSlot.CHEST && this == mc.player && Night.MODULE_MANAGER != null) {
         ItemStack parked = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class).getGrimHiddenElytra();
         if (parked != null) {
            cir.setReturnValue(parked);
         }
      }
   }

   @Inject(
      method = {"isFallFlying"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$pinBounceAndControlRocketGlide(CallbackInfoReturnable<Boolean> cir) {
      if (this == mc.player && Night.MODULE_MANAGER != null) {
         ElytraFlyModule ef = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class);
         if (ef != null && ef.isToggled()) {
            if (ef.isBounceActive() && ef.isGliding()) {
               cir.setReturnValue(true);
               return;
            }

            if (ef.shouldPinFallFlying()) {
               cir.setReturnValue(true);
               return;
            }
         }

         AutoMaceModule am = Night.MODULE_MANAGER.getModule(AutoMaceModule.class);
         if (am != null && am.shouldPinFallFlying()) {
            cir.setReturnValue(true);
         }
      }
   }

   @WrapOperation(
      method = {"updateFallFlyingMovement"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/entity/LivingEntity;getXRot()F"
      )}
   )
   private float wrapFallFlyingPitch(LivingEntity instance, Operation<Float> original) {
      if (this == mc.player && Night.MODULE_MANAGER != null) {
         ElytraFlyModule ef = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class);
         if (ef != null && ef.isBounceAutoPitch()) {
            return ef.getBouncePitch();
         }
      }

      return (Float)original.call(new Object[]{instance});
   }

   @WrapOperation(
      method = {"updateFallFlyingMovement"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/entity/LivingEntity;getLookAngle()Lnet/minecraft/world/phys/Vec3;"
      )}
   )
   private Vec3 wrapFallFlyingLookAngle(LivingEntity instance, Operation<Vec3> original) {
      if (this == mc.player && Night.MODULE_MANAGER != null) {
         ElytraFlyModule ef = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class);
         if (ef != null && ef.isBounceAutoPitch()) {
            return Vec3.directionFromRotation(ef.getBouncePitch(), instance.getYRot());
         }
      }

      return (Vec3)original.call(new Object[]{instance});
   }

   @Inject(
      method = {"travel"},
      at = {@At("HEAD")}
   )
   private void travel$grimHead(Vec3 movementInput, CallbackInfo info) {
      this.night$grimSwapped = false;
      if (this == mc.player && this.night$shouldSpoofRotation()) {
         this.night$grimYaw0 = ((EntityAccessor)this).getRawYRot();
         ((EntityAccessor)this).setRawYRot(this.night$spoofYaw());
         RotationManager.swapActive = true;
         this.night$grimSwapped = true;
      }
   }

   @Inject(
      method = {"travel"},
      at = {@At("RETURN")}
   )
   private void travel$grimReturn(Vec3 movementInput, CallbackInfo info) {
      if (this.night$grimSwapped) {
         this.night$grimSwapped = false;
         RotationManager.swapActive = false;
         ((EntityAccessor)this).setRawYRot(this.night$grimYaw0);
      }
   }

   @ModifyExpressionValue(
      method = {"jumpFromGround"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/entity/LivingEntity;getYRot()F"
      )}
   )
   private float jumpFromGround$grimYaw(float original) {
      return this == mc.player && this.night$shouldSpoofRotation() ? this.night$spoofYaw() : original;
   }

   @Unique
   private boolean night$grimCompensating() {
      if (Night.MODULE_MANAGER == null) {
         return false;
      } else {
         ISprintModule sprint = (ISprintModule)Night.MODULE_MANAGER.getModule("Sprint");
         return sprint != null && sprint.isGrimCompensating();
      }
   }

   @Unique
   private boolean night$shouldSpoofRotation() {
      return this.night$grimCompensating();
   }

   @Unique
   private float night$spoofYaw() {
      return ((ISprintModule)Night.MODULE_MANAGER.getModule("Sprint")).getGrimYaw();
   }
}
