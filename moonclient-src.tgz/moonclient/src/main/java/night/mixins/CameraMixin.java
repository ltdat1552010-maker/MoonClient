package night.mixins;

import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.world.level.material.FogType;
import night.Night;
import night.modules.api.IFOVModifierModule;
import night.modules.api.IFreecamModule;
import night.modules.api.IMotionCameraModule;
import night.modules.api.IViewClipModule;
import night.modules.impl.combat.AutoMaceModule;
import night.modules.impl.movement.ElytraFlyModule;
import night.modules.impl.player.RotationLockModule;
import night.modules.impl.visuals.NoRenderModule;
import night.utils.IMinecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({Camera.class})
public abstract class CameraMixin implements IMinecraft {
   @Shadow
   private boolean detached;

   @Shadow
   protected abstract void move(float var1, float var2, float var3);

   @Shadow
   protected abstract float getMaxZoom(float var1);

   @ModifyArgs(
      method = {"alignWithEntity"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/Camera;getMaxZoom(F)F"
      )
   )
   private void update(Args args) {
      IMotionCameraModule motionCamera = Night.MODULE_MANAGER != null ? (IMotionCameraModule)Night.MODULE_MANAGER.getModule("MotionCamera") : null;
      if (motionCamera != null && motionCamera.isToggled() && motionCamera.isSmoothPerspective()) {
         args.set(0, (float)motionCamera.getDistance());
      } else {
         IViewClipModule viewClip = Night.MODULE_MANAGER != null ? (IViewClipModule)Night.MODULE_MANAGER.getModule("ViewClip") : null;
         if (viewClip != null && viewClip.isToggled() && viewClip.isExtend()) {
            args.set(0, viewClip.getDistanceValue());
         }
      }
   }

   @Inject(
      method = {"getMaxZoom"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void clipToSpace(float cameraDist, CallbackInfoReturnable<Float> info) {
      IViewClipModule viewClip = Night.MODULE_MANAGER != null ? (IViewClipModule)Night.MODULE_MANAGER.getModule("ViewClip") : null;
      if (viewClip != null && viewClip.isToggled()) {
         info.setReturnValue(cameraDist);
      }
   }

   @Inject(
      method = {"getFluidInCamera"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void getSubmersionType(CallbackInfoReturnable<FogType> info) {
      if (Night.MODULE_MANAGER != null
         && Night.MODULE_MANAGER.getModule(NoRenderModule.class).isToggled()
         && Night.MODULE_MANAGER.getModule(NoRenderModule.class).liquidOverlay.getValue()) {
         info.setReturnValue(FogType.NONE);
      }
   }

   @Inject(
      method = {"update"},
      at = {@At("TAIL")}
   )
   private void update$TAIL(DeltaTracker deltaTracker, CallbackInfo info) {
      if (Night.MODULE_MANAGER != null) {
         if (((IFreecamModule)Night.MODULE_MANAGER.getModule("Freecam")).isToggled()) {
            this.detached = true;
         } else {
            IMotionCameraModule motionCamera = (IMotionCameraModule)Night.MODULE_MANAGER.getModule("MotionCamera");
            if (motionCamera != null && motionCamera.isToggled() && motionCamera.isSmoothPerspective() && motionCamera.shouldBeDetached()) {
               this.detached = true;
               if (mc.options != null && mc.options.getCameraType().isFirstPerson()) {
                  float dist = (float)motionCamera.getDistance();
                  if (dist > 0.001F) {
                     this.move(-this.getMaxZoom(dist), 0.0F, 0.0F);
                  }
               }
            }
         }
      }
   }

   @ModifyArgs(
      method = {"alignWithEntity"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/Camera;setRotation(FF)V"
      )
   )
   private void update$setRotation(Args args) {
      if (Night.MODULE_MANAGER != null) {
         IFreecamModule freecam = (IFreecamModule)Night.MODULE_MANAGER.getModule("Freecam");
         if (freecam != null && freecam.isToggled()) {
            args.setAll(new Object[]{freecam.getFreeYaw(), freecam.getFreePitch()});
            return;
         }

         ElytraFlyModule elytraFly = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class);
         if (elytraFly != null && elytraFly.isFreeLookActive()) {
            boolean mirrored = mc.options != null && mc.options.getCameraType().isMirrored();
            float yaw = elytraFly.getFreeYaw();
            float pitch = elytraFly.getFreePitch();
            if (mirrored) {
               yaw += 180.0F;
               pitch = -pitch;
            }

            args.setAll(new Object[]{yaw, pitch});
            return;
         }

         AutoMaceModule autoMace = Night.MODULE_MANAGER.getModule(AutoMaceModule.class);
         if (autoMace != null && autoMace.isFreeLookActive()) {
            boolean mirrored = mc.options != null && mc.options.getCameraType().isMirrored();
            float yaw = autoMace.getFreeYaw();
            float pitch = autoMace.getFreePitch();
            if (mirrored) {
               yaw += 180.0F;
               pitch = -pitch;
            }

            args.setAll(new Object[]{yaw, pitch});
            return;
         }

         RotationLockModule lock = Night.MODULE_MANAGER.getModule(RotationLockModule.class);
         if (lock != null && lock.isToggled() && lock.custom.getValue()) {
            float yawOffset = lock.getShakeYawOffset();
            float pitchOffset = lock.getShakePitchOffset();
            if (yawOffset != 0.0F || pitchOffset != 0.0F) {
               args.setAll(new Object[]{(Float)args.get(0) + yawOffset, (Float)args.get(1) + pitchOffset});
            }
         }
      }
   }

   @ModifyArgs(
      method = {"alignWithEntity"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/Camera;setPosition(DDD)V"
      )
   )
   private void update$setPos(Args args) {
      if (Night.MODULE_MANAGER != null) {
         IFreecamModule fc = (IFreecamModule)Night.MODULE_MANAGER.getModule("Freecam");
         if (fc.isToggled()) {
            args.setAll(new Object[]{fc.getFreeX(), fc.getFreeY(), fc.getFreeZ()});
         } else {
            IMotionCameraModule motionCamera = (IMotionCameraModule)Night.MODULE_MANAGER.getModule("MotionCamera");
            if (motionCamera != null && motionCamera.isToggled() && motionCamera.on()) {
               args.setAll(new Object[]{motionCamera.getFakeX(), motionCamera.getFakeY(), motionCamera.getFakeZ()});
            }
         }
      }
   }

   @Inject(
      method = {"calculateFov"},
      at = {@At("TAIL")},
      cancellable = true
   )
   private void getFOV(float partialTicks, CallbackInfoReturnable<Float> info) {
      if (Night.MODULE_MANAGER != null) {
         IFOVModifierModule module = (IFOVModifierModule)Night.MODULE_MANAGER.getModule("FOVModifier");
         if (module.isToggled()) {
            info.setReturnValue(module.getFovValue());
         }
      }
   }
}
