package night.mixins;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CraftingScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import night.Night;
import night.modules.impl.core.NoMiddleClickModule;
import night.modules.impl.miscellaneous.ShulkerInfoModule;
import night.modules.impl.movement.ElytraFlyModule;
import night.modules.impl.movement.InventoryControlModule;
import night.modules.impl.player.ChestStealerModule;
import night.utils.IMinecraft;
import night.utils.minecraft.InventoryUtils;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({AbstractContainerScreen.class})
public abstract class HandledScreenMixin extends Screen implements IMinecraft {
   @Shadow
   @Nullable
   protected Slot hoveredSlot;
   @Shadow
   protected AbstractContainerMenu menu;
   @Shadow
   protected int leftPos;
   @Shadow
   protected int topPos;
   @Shadow
   protected int imageWidth;
   private Slot night$lastDragSlot = null;

   @Shadow
   protected abstract void slotClicked(Slot var1, int var2, int var3, ContainerInput var4);

   protected HandledScreenMixin(Component title) {
      super(title);
   }

   @Inject(
      method = {"getTooltipFromContainerItem"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void night$trimShulkerName(ItemStack itemStack, CallbackInfoReturnable<List<Component>> cir) {
      ShulkerInfoModule shulkerInfoModule = Night.MODULE_MANAGER.getModule(ShulkerInfoModule.class);
      if (shulkerInfoModule != null && shulkerInfoModule.isToggled() && shulkerInfoModule.hasItems(itemStack)) {
         List<Component> lines = (List<Component>)cir.getReturnValue();
         if (lines != null && lines.size() > 1) {
            cir.setReturnValue(new ArrayList<>(lines.subList(1, lines.size())));
         }
      }
   }

   @ModifyArgs(
      method = {"extractTooltip"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;setTooltipForNextFrame(Lnet/minecraft/client/gui/Font;Ljava/util/List;Ljava/util/Optional;IILnet/minecraft/resources/Identifier;)V"
      )
   )
   private void night$pushVanillaTooltipBelowShulkerInfo(Args args) {
      ShulkerInfoModule shulkerInfoModule = Night.MODULE_MANAGER.getModule(ShulkerInfoModule.class);
      if (shulkerInfoModule != null && shulkerInfoModule.isToggled()) {
         if (this.hoveredSlot != null && !this.hoveredSlot.getItem().isEmpty() && shulkerInfoModule.hasItems(this.hoveredSlot.getItem())) {
            int mouseY = (Integer)args.get(4);
            args.set(4, mouseY + 20);
         }
      }
   }

   @Inject(
      method = {"mouseDragged"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$dragClick(MouseButtonEvent event, double dragX, double dragY, CallbackInfoReturnable<Boolean> info) {
      InventoryControlModule module = Night.MODULE_MANAGER.getModule(InventoryControlModule.class);
      if (module.isToggled() && module.dragClick.getValue()) {
         boolean shiftDown = InputConstants.isKeyDown(mc.getWindow(), 340) || InputConstants.isKeyDown(mc.getWindow(), 344);
         if (event.button() == 0 && shiftDown) {
            if (this.hoveredSlot != null && !this.hoveredSlot.getItem().isEmpty() && this.hoveredSlot != this.night$lastDragSlot) {
               this.night$lastDragSlot = this.hoveredSlot;
               this.slotClicked(this.hoveredSlot, this.hoveredSlot.index, 0, ContainerInput.QUICK_MOVE);
               info.setReturnValue(true);
               info.cancel();
            }
         }
      }
   }

   @Inject(
      method = {"mouseReleased"},
      at = {@At("HEAD")}
   )
   private void night$dragClickReset(MouseButtonEvent event, CallbackInfoReturnable<Boolean> info) {
      this.night$lastDragSlot = null;
   }

   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void night$chestStealerButtons(CallbackInfo ci) {
      if (Night.MODULE_MANAGER != null) {
         ChestStealerModule module = Night.MODULE_MANAGER.getModule(ChestStealerModule.class);
         if (module != null && module.isToggled() && module.buttonMode.getValue()) {
            boolean isInventoryScreen = this instanceof InventoryScreen;
            boolean isCraftingScreen = this instanceof CraftingScreen;
            if (isInventoryScreen) {
               int x = this.leftPos + this.imageWidth - 60;
               int y = this.topPos - 22;
               this.addRenderableWidget(Button.builder(Component.literal("Drop"), b -> module.triggerDrop()).bounds(x, y, 60, 18).build());
            } else if (isCraftingScreen) {
               int btnW = 46;
               int btnH = 18;
               int gap = 3;
               int x = this.leftPos + this.imageWidth - btnW;
               int y = this.topPos - 22;
               this.addRenderableWidget(Button.builder(Component.literal("Drop"), b -> module.triggerDrop()).bounds(x, y, btnW, btnH).build());
               x -= btnW + gap;
               this.addRenderableWidget(Button.builder(Component.literal("Dump"), b -> module.triggerDump()).bounds(x, y, btnW, btnH).build());
               x -= btnW + gap;
               this.addRenderableWidget(Button.builder(Component.literal("Steal"), b -> module.triggerSteal()).bounds(x, y, btnW, btnH).build());
            } else {
               int x = this.leftPos + this.imageWidth + 4;
               int y = this.topPos;
               this.addRenderableWidget(Button.builder(Component.literal("Steal"), b -> module.triggerSteal()).bounds(x, y, 60, 20).build());
               this.addRenderableWidget(Button.builder(Component.literal("Dump"), b -> module.triggerDump()).bounds(x, y + 22, 60, 20).build());
               this.addRenderableWidget(Button.builder(Component.literal("Drop"), b -> module.triggerDrop()).bounds(x, y + 44, 60, 20).build());
            }
         }
      }
   }

   @Redirect(
      method = {"extractSlot"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/inventory/Slot;getItem()Lnet/minecraft/world/item/ItemStack;"
      )
   )
   private ItemStack night$grimSwapVisual(Slot slot) {
      ItemStack real = slot.getItem();
      if (Night.MODULE_MANAGER == null) {
         return real;
      } else {
         ElytraFlyModule elytraFly = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class);
         int parkedSlot = elytraFly.getGrimParkedSlot();
         if (parkedSlot == -1) {
            return real;
         } else {
            if (slot.index == 6) {
               ItemStack elytra = elytraFly.getGrimHiddenElytra();
               if (elytra != null) {
                  return elytra;
               }
            }

            return slot.index == InventoryUtils.indexToSlot(parkedSlot) ? elytraFly.getGrimParkedDisplaced() : real;
         }
      }
   }

   @Inject(
      method = {"slotClicked"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$onSlotClicked(Slot slot, int slotId, int mouseButton, ContainerInput type, CallbackInfo info) {
      if (type == ContainerInput.CLONE && Night.MODULE_MANAGER != null) {
         NoMiddleClickModule module = Night.MODULE_MANAGER.getModule(NoMiddleClickModule.class);
         if (module != null && module.isToggled()) {
            info.cancel();
         }
      }
   }
}
