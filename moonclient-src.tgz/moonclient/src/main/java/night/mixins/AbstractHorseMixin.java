package night.mixins;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import night.Night;
import night.modules.impl.movement.EntityControlModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AbstractHorse.class})
public abstract class AbstractHorseMixin {
   @Inject(
      method = {"getControllingPassenger"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$onGetControllingPassenger(CallbackInfoReturnable<LivingEntity> cir) {
      if (Night.MODULE_MANAGER != null) {
         EntityControlModule entityControl = Night.MODULE_MANAGER.getModule(EntityControlModule.class);
         if (entityControl != null
            && entityControl.isToggled()
            && entityControl.control.getValue()
            && ((AbstractHorse)this).getFirstPassenger() instanceof LivingEntity living) {
            cir.setReturnValue(living);
         }
      }
   }

   @Inject(
      method = {"isTamed"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$onIsTamed(CallbackInfoReturnable<Boolean> cir) {
      if (Night.MODULE_MANAGER != null) {
         EntityControlModule entityControl = Night.MODULE_MANAGER.getModule(EntityControlModule.class);
         if (entityControl != null && entityControl.isToggled() && entityControl.control.getValue()) {
            cir.setReturnValue(true);
         }
      }
   }
}
