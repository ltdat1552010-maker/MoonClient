package night.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerInputPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.phys.BlockHitResult;
import night.Night;
import night.events.impl.AttackBlockEvent;
import night.events.impl.AttackEntityEvent;
import night.events.impl.BreakBlockEvent;
import night.mixins.accessors.ClientPlayerEntityAccessor;
import night.modules.impl.core.NoMiddleClickModule;
import night.modules.impl.movement.InventoryControlModule;
import night.modules.impl.player.NoBreakDelayModule;
import night.modules.impl.player.NoInteractModule;
import night.pingbypass.PingBypassFlags;
import night.utils.minecraft.WorldUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({MultiPlayerGameMode.class})
public class ClientPlayerInteractionManagerMixin {
   @Shadow
   @Final
   private Minecraft minecraft;
   @Shadow
   private int destroyDelay;
   @Unique
   private boolean night$stoppedSprintForClick = false;

   @Inject(
      method = {"handleContainerInput"},
      at = {@At("HEAD")}
   )
   private void beforeContainerClick(int containerId, int slotNum, int buttonNum, ContainerInput containerInput, Player player, CallbackInfo info) {
      this.night$stoppedSprintForClick = false;
      InventoryControlModule module = Night.MODULE_MANAGER.getModule(InventoryControlModule.class);
      if (module.isToggled() && module.grimV2.getValue()) {
         if (this.minecraft.player != null && this.minecraft.getConnection() != null) {
            Input real = this.minecraft.player.input.keyPresses;
            if (real.forward() || real.backward() || real.left() || real.right() || real.jump()) {
               Input fake = new Input(false, false, false, false, false, real.shift(), real.sprint());
               this.minecraft.getConnection().send(new ServerboundPlayerInputPacket(fake));
               ((ClientPlayerEntityAccessor)this.minecraft.player).setLastSentInput(fake);
            }

            if (this.minecraft.player.isSprinting()) {
               this.minecraft.getConnection().send(new ServerboundPlayerCommandPacket(this.minecraft.player, Action.STOP_SPRINTING));
               this.night$stoppedSprintForClick = true;
            }
         }
      }
   }

   @Inject(
      method = {"handleContainerInput"},
      at = {@At("TAIL")}
   )
   private void afterContainerClick(int containerId, int slotNum, int buttonNum, ContainerInput containerInput, Player player, CallbackInfo info) {
      if (this.night$stoppedSprintForClick) {
         this.night$stoppedSprintForClick = false;
         if (this.minecraft.player != null && this.minecraft.getConnection() != null) {
            this.minecraft.getConnection().send(new ServerboundPlayerCommandPacket(this.minecraft.player, Action.START_SPRINTING));
         }
      }
   }

   @Inject(
      method = {"ensureHasSentCarriedItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void syncSelectedSlot(CallbackInfo info) {
      if (PingBypassFlags.proxyForwardingActive && Night.PINGBYPASS_CONFIG != null && Night.PINGBYPASS_CONFIG.isServer()) {
         info.cancel();
      }
   }

   @Inject(
      method = {"releaseUsingItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void stopUsingItem(CallbackInfo info) {
      if (PingBypassFlags.proxyForwardingActive && Night.PINGBYPASS_CONFIG != null && Night.PINGBYPASS_CONFIG.isServer()) {
         info.cancel();
      }
   }

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void onTick(CallbackInfo ci) {
      if (Night.MODULE_MANAGER != null) {
         NoBreakDelayModule module = Night.MODULE_MANAGER.getModule(NoBreakDelayModule.class);
         if (module != null && module.isToggled() && this.destroyDelay > module.delay.getValue().intValue()) {
            this.destroyDelay = module.delay.getValue().intValue();
         }
      }
   }

   @Inject(
      method = {"continueDestroyBlock"},
      at = {@At("HEAD")}
   )
   private void onContinueDestroyBlock(BlockPos pos, Direction direction, CallbackInfoReturnable<Boolean> cir) {
      if (Night.MODULE_MANAGER != null) {
         NoBreakDelayModule module = Night.MODULE_MANAGER.getModule(NoBreakDelayModule.class);
         if (module != null && module.isToggled() && this.destroyDelay > module.delay.getValue().intValue()) {
            this.destroyDelay = module.delay.getValue().intValue();
         }
      }
   }

   @Inject(
      method = {"startDestroyBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void attackBlock(BlockPos pos, Direction direction, CallbackInfoReturnable<Boolean> info) {
      if (Night.MODULE_MANAGER != null) {
         NoBreakDelayModule module = Night.MODULE_MANAGER.getModule(NoBreakDelayModule.class);
         if (module != null && module.isToggled() && this.destroyDelay > module.delay.getValue().intValue()) {
            this.destroyDelay = module.delay.getValue().intValue();
         }
      }

      AttackBlockEvent event = new AttackBlockEvent(pos, direction);
      Night.EVENT_HANDLER.post(event);
      if (event.isCancelled()) {
         info.setReturnValue(false);
      }
   }

   @Inject(
      method = {"useItemOn"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void interactBlock(LocalPlayer player, InteractionHand hand, BlockHitResult hitResult, CallbackInfoReturnable<InteractionResult> info) {
      NoInteractModule noInteractModule = Night.MODULE_MANAGER.getModule(NoInteractModule.class);
      if (noInteractModule.isToggled()
         && noInteractModule.shouldNoInteract()
         && noInteractModule.mode.getValue().equalsIgnoreCase("Disable")
         && WorldUtils.RIGHT_CLICKABLE_BLOCKS.contains(this.minecraft.level.getBlockState(hitResult.getBlockPos()).getBlock())) {
         info.setReturnValue(InteractionResult.FAIL);
      }
   }

   @Inject(
      method = {"useItemOn"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;startPrediction(Lnet/minecraft/client/multiplayer/ClientLevel;Lnet/minecraft/client/multiplayer/prediction/PredictiveAction;)V"
      )}
   )
   private void interactBlock$BEFORE(LocalPlayer player, InteractionHand hand, BlockHitResult hitResult, CallbackInfoReturnable<InteractionResult> cir) {
      NoInteractModule noInteractModule = Night.MODULE_MANAGER.getModule(NoInteractModule.class);
      if (!this.minecraft.player.isShiftKeyDown()
         && noInteractModule.isToggled()
         && noInteractModule.shouldNoInteract()
         && noInteractModule.mode.getValue().equalsIgnoreCase("Sneak")
         && WorldUtils.RIGHT_CLICKABLE_BLOCKS.contains(this.minecraft.level.getBlockState(hitResult.getBlockPos()).getBlock())) {
         this.minecraft.player.connection.send(new ServerboundPlayerInputPacket(new Input(false, false, false, false, false, true, false)));
      }
   }

   @Inject(
      method = {"useItemOn"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;startPrediction(Lnet/minecraft/client/multiplayer/ClientLevel;Lnet/minecraft/client/multiplayer/prediction/PredictiveAction;)V",
         shift = Shift.AFTER
      )}
   )
   private void interactBlock$AFTER(LocalPlayer player, InteractionHand hand, BlockHitResult hitResult, CallbackInfoReturnable<InteractionResult> info) {
      NoInteractModule noInteractModule = Night.MODULE_MANAGER.getModule(NoInteractModule.class);
      if (!this.minecraft.player.isShiftKeyDown()
         && noInteractModule.isToggled()
         && noInteractModule.shouldNoInteract()
         && noInteractModule.mode.getValue().equalsIgnoreCase("Sneak")
         && WorldUtils.RIGHT_CLICKABLE_BLOCKS.contains(this.minecraft.level.getBlockState(hitResult.getBlockPos()).getBlock())) {
         this.minecraft.player.connection.send(new ServerboundPlayerInputPacket(new Input(false, false, false, false, false, false, false)));
      }
   }

   @Inject(
      method = {"attack"},
      at = {@At("HEAD")}
   )
   private void attackEntity(Player player, Entity target, CallbackInfo ci) {
      Night.EVENT_HANDLER.post(new AttackEntityEvent(player, target));
   }

   @Inject(
      method = {"destroyBlock"},
      at = {@At("HEAD")}
   )
   private void breakBlock(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
      Night.EVENT_HANDLER.post(new BreakBlockEvent(pos));
   }

   @Inject(
      method = {"destroyBlock"},
      at = {@At("TAIL")}
   )
   private void afterBreakBlock(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
      if (Night.MODULE_MANAGER != null) {
         NoBreakDelayModule module = Night.MODULE_MANAGER.getModule(NoBreakDelayModule.class);
         if (module != null && module.isToggled() && this.destroyDelay > module.delay.getValue().intValue()) {
            this.destroyDelay = module.delay.getValue().intValue();
         }
      }
   }

   @Inject(
      method = {"handlePickItemFromBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onPickBlock(BlockPos pos, boolean includeData, CallbackInfo info) {
      if (Night.MODULE_MANAGER != null) {
         NoMiddleClickModule module = Night.MODULE_MANAGER.getModule(NoMiddleClickModule.class);
         if (module != null && module.isToggled()) {
            info.cancel();
         }
      }
   }

   @Inject(
      method = {"handlePickItemFromEntity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onPickEntity(Entity entity, boolean includeData, CallbackInfo info) {
      if (Night.MODULE_MANAGER != null) {
         NoMiddleClickModule module = Night.MODULE_MANAGER.getModule(NoMiddleClickModule.class);
         if (module != null && module.isToggled()) {
            info.cancel();
         }
      }
   }
}
