package night.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import night.Night;
import night.events.impl.MouseInputEvent;
import night.events.impl.UnfilteredMouseInputEvent;
import night.modules.impl.combat.MainhandModule;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MouseHandler.class})
public class MouseMixin {
   @Shadow
   @Final
   private Minecraft minecraft;

   @Inject(
      method = {"onButton"},
      at = {@At("HEAD")}
   )
   private void onMouseButton(long window, MouseButtonInfo buttonInfo, int action, CallbackInfo info) {
      int button = buttonInfo.button();
      int mods = buttonInfo.modifiers();
      Night.EVENT_HANDLER.post(new UnfilteredMouseInputEvent(button, action, mods));
      if (window == this.minecraft.getWindow().handle() && action == 1 && this.minecraft.gui.screen() == null) {
         Night.EVENT_HANDLER.post(new MouseInputEvent(button));
      }
   }

   @Inject(
      method = {"onScroll"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$onScroll(long window, double xoffset, double yoffset, CallbackInfo info) {
      if (this.minecraft.gui.screen() == null && window == this.minecraft.getWindow().handle() && Night.MODULE_MANAGER != null) {
         MainhandModule mainhand = Night.MODULE_MANAGER.getModule(MainhandModule.class);
         if (mainhand != null && mainhand.shouldLockSlot()) {
            info.cancel();
         }
      }
   }
}
