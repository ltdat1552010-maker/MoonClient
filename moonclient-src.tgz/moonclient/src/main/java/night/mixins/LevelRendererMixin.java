package night.mixins;

import net.minecraft.client.renderer.LevelRenderer;
import night.Night;
import night.modules.impl.visuals.NoRenderModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LevelRenderer.class})
public class LevelRendererMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void night$resetItemCounter(CallbackInfo info) {
      NoRenderModule noRender = Night.MODULE_MANAGER.getModule(NoRenderModule.class);
      if (noRender != null) {
         noRender.resetItemCounter();
      }
   }
}
