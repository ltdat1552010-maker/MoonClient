package night.mixins;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractButton;
import night.Night;
import night.modules.impl.core.ClickGuiModule;
import night.utils.graphics.NeekeriFill;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({AbstractButton.class})
public abstract class ButtonWidgetMixin {
   @Inject(
      method = {"extractDefaultSprite"},
      at = {@At("TAIL")}
   )
   private void night$neekeriFill(GuiGraphicsExtractor graphics, CallbackInfo ci) {
      ClickGuiModule clickGui = Night.MODULE_MANAGER.getModule(ClickGuiModule.class);
      if (!clickGui.fillMode.getValue().equalsIgnoreCase("Default")) {
         AbstractButton self = (AbstractButton)this;
         int alpha = Math.round(clickGui.neekeriOpacity.getValue().floatValue() / 100.0F * 255.0F);
         NeekeriFill.fill(graphics, self.getX(), self.getY(), self.getWidth(), self.getHeight(), alpha);
      }
   }
}
