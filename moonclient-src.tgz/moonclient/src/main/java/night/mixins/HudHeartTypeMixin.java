package night.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import night.Night;
import night.modules.impl.visuals.NoRenderModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(
   targets = {"net.minecraft.client.gui.Hud$HeartType"}
)
public class HudHeartTypeMixin {
   @ModifyExpressionValue(
      method = {"forPlayer"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/entity/player/Player;hasEffect(Lnet/minecraft/core/Holder;)Z",
         ordinal = 1
      )}
   )
   private static boolean night$hideWitherHeart(boolean original) {
      if (original && Night.MODULE_MANAGER != null) {
         NoRenderModule noRender = Night.MODULE_MANAGER.getModule(NoRenderModule.class);
         if (noRender.isToggled() && noRender.wither.getValue()) {
            return false;
         }
      }

      return original;
   }
}
