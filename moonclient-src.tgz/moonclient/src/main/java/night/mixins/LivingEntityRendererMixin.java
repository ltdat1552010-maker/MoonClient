package night.mixins;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import night.Night;
import night.modules.impl.movement.ElytraFlyModule;
import night.modules.impl.visuals.NoRenderModule;
import night.utils.IMinecraft;
import night.utils.mixins.ISelfState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LivingEntityRenderer.class})
public abstract class LivingEntityRendererMixin<T extends LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>>
   extends EntityRenderer<T, S>
   implements IMinecraft {
   private static final double SAME_SPOT_RANGE_SQ = 1.0;

   public LivingEntityRendererMixin(Context context) {
      super(context);
   }

   @Inject(
      method = {"submit"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void submit(S state, PoseStack poseStack, SubmitNodeCollector submitNodeCollector, CameraRenderState camera, CallbackInfo info) {
      NoRenderModule noRender = Night.MODULE_MANAGER.getModule(NoRenderModule.class);
      if (noRender.isToggled()) {
         if (noRender.corpses.getValue() && state.deathTime > 0.0F) {
            info.cancel();
         } else {
            if (noRender.player.getValue() && state instanceof AvatarRenderState && !((ISelfState)state).night$isSelf() && mc.player != null) {
               double dx = state.x - mc.player.getX();
               double dz = state.z - mc.player.getZ();
               if (dx * dx + dz * dz <= 1.0) {
                  info.cancel();
               }
            }
         }
      }
   }

   @Inject(
      method = {"extractRenderState"},
      at = {@At("TAIL")}
   )
   private void night$extractRenderState(T entity, S state, float partialTicks, CallbackInfo info) {
      ((ISelfState)state).night$setSelf(entity == mc.player);
      if (entity == mc.player && Night.ROTATION_MANAGER.inRenderTime()) {
         state.bodyRot = Night.ROTATION_MANAGER.getRenderRotations()[0];
         state.yRot = Mth.wrapDegrees(Night.ROTATION_MANAGER.getRenderRotations()[0] - state.bodyRot);
         state.xRot = Night.ROTATION_MANAGER.getRenderRotations()[1];
      } else {
         if (entity == mc.player && Night.MODULE_MANAGER != null) {
            ElytraFlyModule ef = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class);
            if (ef != null && ef.isToggled() && ef.mode.getValue().equalsIgnoreCase("Bounce") && ef.bounceAutoPitch.getValue()) {
               state.xRot = ef.bouncePitch.getValue().floatValue();
            }
         }
      }
   }
}
