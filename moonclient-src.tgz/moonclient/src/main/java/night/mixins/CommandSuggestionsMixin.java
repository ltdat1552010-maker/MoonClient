package night.mixins;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.suggestion.Suggestions;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.gui.components.CommandSuggestions;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.CommandSuggestions.SuggestionsList;
import net.minecraft.client.multiplayer.ClientSuggestionProvider;
import night.Night;
import night.commands.CommandManager;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({CommandSuggestions.class})
public abstract class CommandSuggestionsMixin {
   @Shadow
   @Nullable
   private ParseResults<ClientSuggestionProvider> currentParse;
   @Shadow
   @Nullable
   private CompletableFuture<Suggestions> pendingSuggestions;
   @Shadow
   private SuggestionsList suggestions;
   @Shadow
   private boolean keepSuggestions;
   @Shadow
   @Final
   private EditBox input;

   @Shadow
   private void updateUsageInfo(ParseResults<ClientSuggestionProvider> parseResults, Suggestions suggestionResult) {
   }

   @Inject(
      method = {"updateCommandInfo"},
      at = {@At("RETURN")}
   )
   private void night$updateCommandInfo(CallbackInfo ci) {
      String raw = this.input.getValue();
      String prefix = Night.COMMAND_MANAGER.getPrefix();
      if (raw.startsWith(prefix)) {
         StringReader reader = new StringReader(raw);
         reader.setCursor(prefix.length());
         CommandDispatcher<CommandManager> dispatcher = Night.COMMAND_MANAGER.getDispatcher();
         ParseResults<CommandManager> parse = dispatcher.parse(reader, Night.COMMAND_MANAGER);
         this.currentParse = parse;
         if (this.suggestions == null || !this.keepSuggestions) {
            CompletableFuture<Suggestions> future = dispatcher.getCompletionSuggestions(parse, this.input.getCursorPosition());
            this.pendingSuggestions = future;
            future.thenRun(() -> {
               if (future.isDone()) {
                  this.updateUsageInfo(this.currentParse, future.join());
               }
            });
         }
      }
   }
}
