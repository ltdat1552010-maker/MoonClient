package night.mixins;

import net.minecraft.client.renderer.Projection;
import night.Night;
import night.modules.impl.visuals.AspectRatioModule;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({Projection.class})
public class ProjectionMixin {
   @Shadow
   private boolean isMatrixDirty;

   @Inject(
      method = {"getMatrix"},
      at = {@At("HEAD")}
   )
   private void getMatrix$forceDirty(Matrix4f dest, CallbackInfoReturnable<Matrix4f> info) {
      this.isMatrixDirty = true;
   }

   @ModifyArgs(
      method = {"getMatrix"},
      at = @At(
         value = "INVOKE",
         target = "Lorg/joml/Matrix4f;setPerspective(FFFFZ)Lorg/joml/Matrix4f;"
      )
   )
   private void getMatrix$aspectRatio(Args args) {
      if (Night.MODULE_MANAGER != null) {
         AspectRatioModule module = Night.MODULE_MANAGER.getModule(AspectRatioModule.class);
         if (module != null && module.isToggled()) {
            args.set(1, module.ratio.getValue().floatValue());
         }
      }
   }
}
