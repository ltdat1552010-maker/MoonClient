package night.mixins;

import com.mojang.blaze3d.opengl.GlDebug;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GlDebug.class})
public class GlDebugMixin {
   @Inject(
      method = {"printDebugLog"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$silenceFramebufferSpam(int source, int type, int id, int severity, int length, long message, long userParam, CallbackInfo ci) {
      if (id == 1286) {
         ci.cancel();
      }
   }
}
