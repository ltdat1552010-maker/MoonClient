package night.mixins;

import net.minecraft.client.gui.components.toasts.AdvancementToast;
import net.minecraft.client.gui.components.toasts.Toast;
import net.minecraft.client.gui.components.toasts.ToastManager;
import night.Night;
import night.modules.impl.visuals.NoRenderModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ToastManager.class})
public class ToastManagerMixin {
   @Inject(
      method = {"addToast"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$noAdvancementToast(Toast toast, CallbackInfo info) {
      if (toast instanceof AdvancementToast && Night.MODULE_MANAGER != null) {
         NoRenderModule noRender = Night.MODULE_MANAGER.getModule(NoRenderModule.class);
         if (noRender.isToggled() && noRender.advancements.getValue()) {
            info.cancel();
         }
      }
   }
}
