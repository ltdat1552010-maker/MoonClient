package night.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import night.gui.PeekScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MultiPlayerGameMode.class})
public class MultiPlayerGameModeMixin {
   @Inject(
      method = {"handleContainerInput"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$blockPeekClicks(int containerId, int slotId, int button, ContainerInput type, Player player, CallbackInfo ci) {
      if (Minecraft.getInstance().gui.screen() instanceof PeekScreen) {
         ci.cancel();
      }
   }
}
