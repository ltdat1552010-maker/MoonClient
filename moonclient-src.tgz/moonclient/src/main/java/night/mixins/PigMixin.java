package night.mixins;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.pig.Pig;
import night.Night;
import night.modules.impl.movement.EntityControlModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Pig.class})
public abstract class PigMixin {
   @Inject(
      method = {"getControllingPassenger"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$onGetControllingPassenger(CallbackInfoReturnable<LivingEntity> cir) {
      if (Night.MODULE_MANAGER != null) {
         EntityControlModule entityControl = Night.MODULE_MANAGER.getModule(EntityControlModule.class);
         if (entityControl != null
            && entityControl.isToggled()
            && entityControl.control.getValue()
            && ((Pig)this).getFirstPassenger() instanceof LivingEntity living) {
            cir.setReturnValue(living);
         }
      }
   }
}
