package night.mixins;

import java.util.Map;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EntityRenderDispatcher.class})
public class EntityRenderDispatcherMixin {
   @Shadow
   private Map<EntityType<?>, EntityRenderer<?, ?>> renderers;

   @Inject(
      method = {"shouldRender"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private <T extends Entity> void night$safeShouldRender(T entity, Frustum frustum, double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> cir) {
      if (entity != null && entity.getType() != null) {
         if (!(entity instanceof AbstractClientPlayer) && (this.renderers == null || !this.renderers.containsKey(entity.getType()))) {
            cir.setReturnValue(false);
         }
      } else {
         cir.setReturnValue(false);
      }
   }
}
