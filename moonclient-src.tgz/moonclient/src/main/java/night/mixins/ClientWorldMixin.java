package night.mixins;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import night.Night;
import night.events.impl.EntitySpawnEvent;
import night.events.impl.PlayerMineEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientLevel.class})
public class ClientWorldMixin {
   @Inject(
      method = {"addEntity"},
      at = {@At("HEAD")}
   )
   private void addEntity(Entity entity, CallbackInfo info) {
      Night.EVENT_HANDLER.post(new EntitySpawnEvent(entity));
   }

   @Inject(
      method = {"destroyBlockProgress"},
      at = {@At("HEAD")}
   )
   private void destroyBlockProgress(int id, BlockPos pos, int progress, CallbackInfo info) {
      if (progress >= 0 && progress <= 9) {
         Night.EVENT_HANDLER.post(new PlayerMineEvent(id, pos));
      }
   }
}
