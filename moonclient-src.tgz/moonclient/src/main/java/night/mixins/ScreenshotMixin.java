package night.mixins;

import java.util.function.Consumer;
import net.minecraft.client.Screenshot;
import net.minecraft.network.chat.Component;
import night.Night;
import night.modules.impl.miscellaneous.ScreenshotModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({Screenshot.class})
public class ScreenshotMixin {
   @ModifyVariable(
      method = {"grab(Ljava/io/File;Ljava/lang/String;Lcom/mojang/blaze3d/pipeline/RenderTarget;ILjava/util/function/Consumer;)V"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private static Consumer<Component> night$wrapScreenshotConsumer(Consumer<Component> original) {
      return component -> {
         ScreenshotModule module = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ScreenshotModule.class) : null;
         boolean handled = module != null && module.isToggled();
         if (!handled) {
            original.accept(component);
         }

         try {
            if (handled) {
               module.onScreenshotCaptured(component);
            }
         } catch (Throwable var5) {
            Night.LOGGER.error("Failed to process screenshot callback in ScreenshotModule", var5);
         }
      };
   }
}
