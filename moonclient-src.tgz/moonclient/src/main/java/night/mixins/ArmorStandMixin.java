package night.mixins;

import net.minecraft.world.entity.decoration.ArmorStand;
import night.Night;
import night.modules.impl.visuals.NoRenderModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ArmorStand.class})
public abstract class ArmorStandMixin {
   @Inject(
      method = {"isPickable"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$hideFromRaytrace(CallbackInfoReturnable<Boolean> cir) {
      NoRenderModule noRender = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(NoRenderModule.class) : null;
      if (noRender != null && noRender.isToggled() && noRender.armorStand.getValue()) {
         cir.setReturnValue(false);
      }
   }
}
