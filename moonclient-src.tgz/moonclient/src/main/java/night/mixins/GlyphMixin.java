package night.mixins;

import com.mojang.blaze3d.font.GlyphInfo;
import night.Night;
import night.managers.FontManager;
import night.modules.impl.core.FontModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({GlyphInfo.class})
public interface GlyphMixin {
   @Inject(
      method = {"getShadowOffset"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void getShadowOffset(CallbackInfoReturnable<Float> info) {
      if (FontManager.isClientTextRendering()) {
         if (Night.MODULE_MANAGER != null) {
            FontModule module = Night.MODULE_MANAGER.getModule(FontModule.class);
            if (module != null && module.isToggled() && !module.shadowMode.getValue().equalsIgnoreCase("Default")) {
               info.setReturnValue(Night.FONT_MANAGER.getShadowOffset());
            }
         }
      }
   }
}
